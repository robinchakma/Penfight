# Desk Duel: Pen Fight

A tactile 2D physics tabletop game recreating classic classroom pen fighting on a nostalgic wooden school desk with carved doodles. Players drag and flick distinct pen classes across the desk, using off-center spin and momentum to knock their opponent off the edge in Best-of-3 matches.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> All core gameplay and visual directions from your Phase 1 choices are locked into this plan. Review the physics and presentation choices below before approving execution.

- **Confirmed Game Modes**: Solo vs AI (with selectable Easy, Medium, and Hard bot intelligence) and Local 2-Player Pass & Play on the same screen.
- **Confirmed Arena Aesthetic**: Nostalgic warm oak/birch school desk with carved doodles (tic-tac-toe, stars, notebook margin scribbles) and high-contrast drop-off edges.
- **Confirmed Pen Roster**: Four distinct pen classes—Ballpoint Classic, Heavy Brass Fountain, Neon Gel Runner, and Jumbo Felt Marker—each with tuned mass, length, width, surface friction, and restitution.
- **Confirmed Match Format**: Classic Best-of-3 rounds with a pre-match toggle between Clean Desk (pure duel) and Stationery Obstacles (beveled rubber eraser, brass sharpener, and acrylic ruler bank rails).
- **Recommended Control Default**: Drag-from-anywhere-on-your-pen slingshot aiming so grabbing near the tip or cap imparts realistic rotational torque and sweep, while grabbing the center delivers a straight power ram.

---

### 1. Overview & Core Concept

- **What It Does**: Simulates authentic turn-based tabletop pen fighting using 2D rigid-body physics. Each turn, the active player pulls back on any point along their pen to set launch angle, power, and spin torque, then releases to send the pen sliding and spinning across the desk until all motion settles. Knocking the opponent's pen completely off the desk boundary scores a Ring Out round win; first to 2 round wins (Best of 3) claims the match.
- **Target Audience & Context**: Casual arcade players and fans of classic schoolyard tabletop games looking for quick, tactile head-to-head rounds against an AI rival or a friend nearby.
- **Key Value**: Unlike generic circular puck games, true elongated rigid-body collision and off-center torque physics create genuine Pen Fight strategy—sweeping tail whips, angled bank shots off erasers, and heavy center-mass knockouts.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Title & Match Setup Screen**: Full-viewport live wooden desk backdrop featuring resting hero pens and a custom SVG title lockup. Players pick Mode (`Solo vs AI` or `2-Player Local`), AI difficulty (when in Solo), Pen Class for each side, and Arena Layout (`Clean Desk` or `Stationery Obstacles`), then click `Start Match` (or press `Enter`/`Space`).
  2. **Active Tabletop Play**: Top perimeter status bar displays Player 1 and Player 2/AI round pips, active pen class names, current round (`Round 1 · Best of 3`), explicit turn indicator, and `Mute` / `Pause` controls. On a human turn, hovering over your pen highlights interactive grab points; pulling back renders a tension line, power percentage, and curved spin-direction indicator. Releasing launches the physics simulation; AI turns pause briefly (600ms) to telegraph their aim vector before flicking.
  3. **Ring Out & Round Transition**: When a pen's center crosses off the wooden desk edge (or falls completely outside the boundary), it triggers a tumbling fall-off animation into the surrounding floor shadow, awards the round point, and displays a concise Round Summary overlay before resetting positions for the next round.
  4. **Match Victory / Game Over Modal**: Displays match winner, final Best-of-3 score, match highlights (longest flick, hardest collision, total ring-outs), and immediate `Play Again` or `Return to Menu` actions.

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Nostalgic, tactile classroom tabletop—warm sunlit oak desk slab floating over a deep slate-charcoal classroom floor void so desk drop-off boundaries are unmistakable at a glance.
  - *Color Palette & Mood* (60-30-10 discipline):
    - **60% Dominant Arena Surface**: Warm honey-oak wooden desk (`#C89B6E` / `#B58352`) with subtle carved pencil/ink doodle overlays and a generated tabletop grain texture.
    - **30% Structural UI & Classroom Void**: Deep chalkboard-slate floor void (`#141A21`), crisp cream/paper-card HUD surfaces (`#FAF6EE`) with subtle hairline ink borders (`#2A2520/15`).
    - **10% Focal Accents**: Classic Bic-blue ink (`#1D4ED8`) for Player 1, crimson red-pen ink (`#DC2626`) for Player 2/AI, and warm brass-amber (`#D97706`) for power/highlight cues.
  - *Typography & Hierarchy*: Expressive geometric-friendly display face (`Bricolage Grotesque`) paired with crisp readable sans (`Plus Jakarta Sans`) and monospace tabular numerals (`JetBrains Mono` with `tabular-nums`) for scores, power %, and physics stats.
  - *Layout & Viewport Budget*: Full-viewport (`100dvh`) non-scrolling Game Shell. Perimeter HUD and bottom single-line control hint keep over 85% of the playfield completely unobstructed, with `pointer-events: none` on overlay wrappers.

- **Interactive Feedback & Motion**:
  - **Physics Hitstop & Camera Shake**: 35–60ms micro-freeze and decaying camera shake scaled to collision impulse when two pens clash hard.
  - **Tactile Particles & Trails**: Chalk/wood-dust impact sparks at contact points, faint speed streaks on high-velocity flicks, and 3D-feel scale+rotation fall-off animation when knocked off the desk.
  - **Procedural Web Audio Synth**: Oscillator + filtered noise sound effects for wooden pen clacks, rubber eraser thuds, flick whooshes, edge tumble whistles, and round victory chimes—respecting a persistent mute toggle.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: True 2D Elongated Rigid-Body Physics vs. Circular Puck Approximation**
  - *Chosen Approach*: Custom 2D rigid-body capsule/OBB physics engine running at a fixed simulation sub-step inside an isolated `requestAnimationFrame` canvas loop, modeling linear velocity, angular velocity, moment of inertia, off-center torque ($\tau = \vec{r} \times \vec{F}$), and separating-axis / segment-distance collision resolution.
  - *Why*: Pen Fight's signature fun comes from spinning pens like propellers when flicked near the tip or cap, and catching an opponent with a sweeping tail strike. Circular hitboxes destroy that identity.
  - *Alternatives Considered*: Importing a heavy external physics engine or using simple circle colliders; custom fixed-timestep capsule physics gives crisp, predictable tabletop friction and zero React render coupling.

- **Decision 2: AI Shot Planning via Multi-Candidate Simulation**
  - *Chosen Approach*: On AI turns, evaluate candidate shots (direct center strikes, angled tip-sweep spins, and obstacle bank shots) using fast forward kinematics/scoring plus difficulty-based aim variance (`Easy` slight scatter, `Medium` solid aim, `Hard` spin-aware edge sniping) and render a brief 500ms aim telegraph before release.
  - *Why*: Makes the AI feel like a believable tabletop opponent rather than random luck or unfair instant teleports, while keeping turns snappy.

- **Decision 3: Canvas Simulation Isolated from React State**
  - *Chosen Approach*: Store frame-by-frame physics coordinates, velocities, particles, and camera shake in mutable refs read by the `<canvas>` renderer, emitting React state updates only for discrete game-state transitions (turn change, round win, match end, pause).
  - *Why*: Guarantees locked 60fps animation with zero React re-render overhead during flicks and collisions.

---

### 4. Technical Architecture & Data Strategy

- **Architecture & Component Diagram**:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          Game Shell & State Machine                     │
│        ('TITLE_MENU' │ 'PLAYING' │ 'PAUSED' │ 'ROUND_END' │ 'GAME_OVER') │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
┌───────────────┐      ┌────────────────┐      ┌──────────────────┐
│  Title & Setup│      │  Perimeter HUD │      │  Result & Pause  │
│  Overlay      │      │  & Hint Strip  │      │  Modals          │
│               │      │                │      │                  │
│ • Mode Select │      │ • P1/P2 Scores │      │ • KO Breakdown   │
│ • Pen Classes │      │ • Turn Banner  │      │ • Match Stats    │
│ • Obstacles   │      │ • Audio Mute   │      │ • Play Again     │
└───────┬───────┘      └───────┬────────┘      └────────┬─────────┘
        │                      │                        │
        └──────────────────────┼────────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     Isolated Canvas Arena Viewport                      │
│                                                                         │
│  ┌─────────────────────┐   ┌──────────────────┐   ┌──────────────────┐  │
│  │ Input & Slingshot   │──▶│ 2D Rigid-Body    │──▶│ Desk & Pen       │  │
│  │ Controller          │   │ Physics Engine   │   │ Canvas Renderer  │  │
│  │                     │   │                  │   │                  │  │
│  │ • Pointer Grab      │   │ • Capsule OBB    │   │ • Wood Texture   │  │
│  │ • Lever-Arm Torque  │   │ • Impulse & Spin │   │ • Carved Doodles │  │
│  │ • Aim / Spin Guide  │   │ • Friction/Rest  │   │ • Pen Art & FX   │  │
│  └─────────────────────┘   │ • Ring-Out Check │   └────────┬─────────┘  │
│                            └────────┬─────────┘            │            │
│                                     ▼                      ▼            │
│                            ┌──────────────────┐   ┌──────────────────┐  │
│                            │ AI Shot Planner  │   │ Web Audio Synth  │  │
│                            │ (Easy/Med/Hard)  │   │ & Particle Pool  │  │
│                            └──────────────────┘   └──────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Match Configuration**: `mode` (`'ai' | 'local'`), `aiDifficulty` (`'easy' | 'medium' | 'hard'`), `obstaclesEnabled` (`boolean`), `p1PenClass`, `p2PenClass`.
  - **Pen Class Definition**: `id`, `name`, `tagline`, `length`, `radius`, `mass`, `friction`, `restitution`, `powerScale`, `primaryColor`, `accentColor`, `visualStyle` (`'ballpoint' | 'fountain' | 'gel' | 'marker'`).
  - **Pen Rigid Body**: `x`, `y`, `angle`, `vx`, `vy`, `omega`, `mass`, `inertia`, `state` (`'active' | 'falling' | 'out'`), `fallProgress`.
  - **Stationery Obstacle**: `shape` (`'box' | 'circle'`), `kind` (`'eraser' | 'sharpener' | 'ruler'`), `x`, `y`, `width`, `height`, `angle`, `restitution`.
  - **Match Score & Telemetry**: `roundNumber`, `p1Wins`, `p2Wins`, `activeTurn` (`1 | 2`), `turnPhase` (`'aiming' | 'ai_thinking' | 'simulating' | 'resolving'`), `hardestImpact`, `totalFlicks`.

- **Interactive Component & State Mapping**:
  - **Title Setup Controls** -> Mutate Match Configuration state; `Start Match` initializes Round 1 pen spawns, optional stationery obstacle layout, and enters `'PLAYING'` state.
  - **Canvas Pointer Handlers (`pointerdown`, `pointermove`, `pointerup`)** -> Active only when `turnPhase === 'aiming'` and human player owns `activeTurn`. Computes nearest point along the pen's spine for grab offset, clamps pull distance for power cap, supports cancel on zero pull or `Escape`/right-click, and dispatches impulse (`vx`, `vy`, `omega`) on release.
  - **Fixed-Timestep Simulation Loop** -> Advances sub-stepped rigid-body integration (`dt` clamped to `<= 0.05s`), resolves pen-vs-pen and pen-vs-obstacle impulses, detects desk edge ring-outs (both pens falling in same turn awards round to last survivor or triggers sudden-death draw reset), spawns particles/hitstop/audio, and transitions `turnPhase` when all bodies settle below velocity threshold.
  - **AI Controller** -> Triggered automatically when `mode === 'ai' && activeTurn === 2 && turnPhase === 'ai_thinking'`, calculates candidate shot, animates a brief aim telegraph, and fires the shot cleanly with cleanup on pause/reset.
  - **Pause & Result Modals** -> Pause (`Esc` or HUD button) freezes the simulation timer cleanly; `Play Again` resets scores, round count, and rigid-body positions without page reload.
