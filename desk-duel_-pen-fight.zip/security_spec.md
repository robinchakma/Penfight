# Security Specification: Desk Duel Global Leaderboards

## 1. Data Invariants
1. A leaderboard document at `/leaderboards/{userId}` may only be created or updated by the authenticated, email-verified user whose `request.auth.uid` equals both `{userId}` and `request.resource.data.uid`.
2. Zero PII (`email`, `phone`, `address`) is stored in `/leaderboards/{userId}`.
3. `createdAt` is set strictly to `request.time` at creation and remains immutable on every subsequent update. `updatedAt` must always equal `request.time`.
4. Competitive counters (`totalWins`, `totalLosses`, `roundsWon`, `ringOuts`, `tournamentsWon`, `hardestImpact`) may only increase monotonically and are bounded per match write (`+0..1` match win/loss/tournament, `+0..10` rounds/ring-outs).
5. Unknown or shadow fields are rejected on both `create` and `update`.

## 2. Adversarial "Dirty Dozen" Payloads (All Must Return PERMISSION_DENIED)
1. **Unauthenticated Write**: Creating `/leaderboards/userA` with `request.auth == null`.
2. **Unverified Email Write**: Creating `/leaderboards/userA` with `email_verified: false`.
3. **Cross-User Spoof**: User A writing to `/leaderboards/userB` (`userId != request.auth.uid`).
4. **UID Payload Mismatch**: User A writing `uid: "userB"` inside `/leaderboards/userA`.
5. **Path ID Poisoning**: Attempting `get` or `create` on `/leaderboards/invalid$id!` (fails `isValidId`).
6. **Shadow Field Injection (Create)**: Creating `/leaderboards/userA` with extra field `isAdmin: true`.
7. **Shadow Field Injection (Update)**: Updating `/leaderboards/userA` with extra field `verifiedBadge: true`.
8. **DisplayName Buffer Overflow**: Setting `displayName` to a 64-char string (> `maxLength: 32`).
9. **Invalid Pen Class Enum**: Setting `favoritePen: "laser_cannon"` outside allowed enum.
10. **Score Inflation Attack**: Setting `totalWins: 9999` on create or incrementing `totalWins` by `+50` in a single update.
11. **Timestamp Forgery**: Providing a client-side past/future timestamp for `createdAt` or `updatedAt` instead of `serverTimestamp()`.
12. **Immutable Field Tampering**: Attempting to mutate `createdAt` or `uid` during an update, or attempting `delete` on `/leaderboards/userA`.
