import {
  FanWindStatus,
  PenClassId,
  PenClassSpec,
  PenCustomization,
  PenPatternId,
  PenTextureId,
  StationeryObstacle,
  VentilationFan,
} from './types';

export const WORLD_WIDTH = 1200;
export const WORLD_HEIGHT = 720;

export const DESK_BOUNDS = {
  left: 110,
  right: 1090,
  top: 84,
  bottom: 636,
  width: 980,
  height: 552,
  cornerRadius: 18,
};

export const MAX_PULL_DISTANCE = 175;
export const MIN_PULL_DISTANCE = 14;
export const BASE_FLICK_IMPULSE = 1080;
export const FLICK_TORQUE_SCALE = 0.72;
export const STOP_LINEAR_SPEED = 8;
export const STOP_ANGULAR_SPEED = 0.18;
export const BEST_OF_ROUNDS = 3;
export const WINS_NEEDED = 2;
export const ROUND_OPTIONS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] as const;

export function getWinsNeeded(totalRounds: number): number {
  const clamped = Math.max(1, Math.min(10, Math.round(totalRounds)));
  return Math.floor(clamped / 2) + 1;
}

export const DESK_TEXTURE_URL = '/src/assets/images/wooden_school_desk_top_1795237175934.jpg';

export const PLAYER_COLORS = {
  1: {
    name: 'Blue Ink',
    primary: '#1D4ED8',
    secondary: '#93C5FD',
    dark: '#1E3A8A',
    glow: 'rgba(29, 78, 216, 0.32)',
  },
  2: {
    name: 'Red Ink',
    primary: '#DC2626',
    secondary: '#FCA5A5',
    dark: '#7F1D1D',
    glow: 'rgba(220, 38, 38, 0.32)',
  },
} as const;

export interface CustomColorPreset {
  id: string;
  name: string;
  primary: string;
  secondary: string;
  dark: string;
}

export const CUSTOM_PEN_COLORS: CustomColorPreset[] = [
  { id: 'cobalt', name: 'Cobalt', primary: '#1D4ED8', secondary: '#93C5FD', dark: '#1E3A8A' },
  { id: 'crimson', name: 'Crimson', primary: '#DC2626', secondary: '#FCA5A5', dark: '#7F1D1D' },
  { id: 'emerald', name: 'Emerald', primary: '#059669', secondary: '#6EE7B7', dark: '#064E3B' },
  { id: 'amber', name: 'Amber', primary: '#D97706', secondary: '#FDE68A', dark: '#78350F' },
  { id: 'plum', name: 'Plum', primary: '#7C3AED', secondary: '#DDD6FE', dark: '#4C1D95' },
  { id: 'teal', name: 'Teal', primary: '#0D9488', secondary: '#99F6E4', dark: '#115E59' },
  { id: 'rose', name: 'Rose', primary: '#E11D48', secondary: '#FDA4AF', dark: '#881337' },
  { id: 'copper', name: 'Copper', primary: '#C2410C', secondary: '#FDBA74', dark: '#7C2D12' },
  { id: 'ivory', name: 'Ivory', primary: '#E7E5E4', secondary: '#FFFFFF', dark: '#57534E' },
  { id: 'obsidian', name: 'Obsidian', primary: '#1E293B', secondary: '#94A3B8', dark: '#0F172A' },
];

export const PEN_PATTERNS: Array<{ id: PenPatternId; label: string }> = [
  { id: 'solid', label: 'Solid' },
  { id: 'stripes', label: 'Stripes' },
  { id: 'chevron', label: 'Chevron' },
  { id: 'checkered', label: 'Checkered' },
  { id: 'dots', label: 'Dots' },
  { id: 'waves', label: 'Waves' },
  { id: 'rings', label: 'Rings' },
  { id: 'lightning', label: 'Zigzag' },
  { id: 'camo', label: 'Camo' },
];

export const PEN_TEXTURES: Array<{ id: PenTextureId; label: string }> = [
  { id: 'smooth', label: 'Smooth' },
  { id: 'brushed', label: 'Brushed' },
  { id: 'metallic', label: 'Chrome' },
  { id: 'matte', label: 'Matte' },
  { id: 'carbon', label: 'Carbon' },
  { id: 'woodgrain', label: 'Wood' },
];

export const DEFAULT_P1_CUSTOM: PenCustomization = {
  styleMode: 'standard',
  colorId: 'cobalt',
  pattern: 'stripes',
  texture: 'smooth',
};

export const DEFAULT_P2_CUSTOM: PenCustomization = {
  styleMode: 'standard',
  colorId: 'crimson',
  pattern: 'chevron',
  texture: 'brushed',
};

export function getCustomColorPreset(colorId: string): CustomColorPreset {
  return CUSTOM_PEN_COLORS.find((c) => c.id === colorId) ?? CUSTOM_PEN_COLORS[0];
}

const UNLOCKED_STYLES_KEY = 'desk-duel-unlocked-custom-styles';

export function loadUnlockedCustomClasses(): Record<PenClassId, boolean> {
  const base: Record<PenClassId, boolean> = {
    ballpoint: true, // Starter pen class Custom style unlocked
    fountain: false,
    gel: false,
    marker: false,
    mechanical: false,
    rollerball: false,
  };
  try {
    const raw = localStorage.getItem(UNLOCKED_STYLES_KEY);
    if (!raw) return base;
    const parsed = JSON.parse(raw) as Partial<Record<PenClassId, boolean>>;
    return {
      ballpoint: true,
      fountain: Boolean(parsed.fountain),
      gel: Boolean(parsed.gel),
      marker: Boolean(parsed.marker),
      mechanical: Boolean(parsed.mechanical),
      rollerball: Boolean(parsed.rollerball),
    };
  } catch {
    return base;
  }
}

export function saveUnlockedCustomClasses(state: Record<PenClassId, boolean>): void {
  try {
    localStorage.setItem(UNLOCKED_STYLES_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage failures
  }
}

export const PEN_CLASSES: Record<PenClassId, PenClassSpec> = {
  ballpoint: {
    id: 'ballpoint',
    name: 'Ballpoint Classic',
    tagline: 'Crisp balance of speed, spin, and control.',
    length: 148,
    radius: 10,
    mass: 1.0,
    linearDamping: 2.35,
    angularDamping: 2.8,
    restitution: 0.74,
    powerScale: 1.0,
    weightLabel: 'Medium',
    gripLabel: 'Balanced',
    speedLabel: 'Standard',
  },
  fountain: {
    id: 'fountain',
    name: 'Brass Fountain',
    tagline: 'Heavy brass body delivers crushing knockback.',
    length: 160,
    radius: 12,
    mass: 1.65,
    linearDamping: 2.0,
    angularDamping: 2.35,
    restitution: 0.68,
    powerScale: 0.94,
    weightLabel: 'Heavy',
    gripLabel: 'Solid',
    speedLabel: 'Measured',
  },
  gel: {
    id: 'gel',
    name: 'Neon Gel Runner',
    tagline: 'Low-friction barrel built for long glides and spin.',
    length: 140,
    radius: 9,
    mass: 0.78,
    linearDamping: 1.6,
    angularDamping: 2.05,
    restitution: 0.82,
    powerScale: 1.12,
    weightLabel: 'Light',
    gripLabel: 'Slick',
    speedLabel: 'Fast',
  },
  marker: {
    id: 'marker',
    name: 'Jumbo Felt Marker',
    tagline: 'Wide body sweeps opponents and holds the edge.',
    length: 150,
    radius: 15,
    mass: 1.35,
    linearDamping: 2.95,
    angularDamping: 3.1,
    restitution: 0.78,
    powerScale: 1.03,
    weightLabel: 'Stocky',
    gripLabel: 'High',
    speedLabel: 'Steady',
  },
  mechanical: {
    id: 'mechanical',
    name: 'Drafting Pencil',
    tagline: 'Knurled brass grip and eraser tail for crisp spin control.',
    length: 152,
    radius: 9.5,
    mass: 0.92,
    linearDamping: 2.15,
    angularDamping: 2.55,
    restitution: 0.76,
    powerScale: 1.05,
    weightLabel: 'Nimble',
    gripLabel: 'Knurled',
    speedLabel: 'Quick',
  },
  rollerball: {
    id: 'rollerball',
    name: 'Steel Rollerball',
    tagline: 'Balanced metal chassis engineered for bouncy bank shots.',
    length: 156,
    radius: 10.5,
    mass: 1.24,
    linearDamping: 1.88,
    angularDamping: 2.25,
    restitution: 0.85,
    powerScale: 1.02,
    weightLabel: 'Mid-Heavy',
    gripLabel: 'Satin',
    speedLabel: 'Glider',
  },
};

export const PEN_CLASS_LIST: PenClassSpec[] = [
  PEN_CLASSES.ballpoint,
  PEN_CLASSES.fountain,
  PEN_CLASSES.gel,
  PEN_CLASSES.marker,
  PEN_CLASSES.mechanical,
  PEN_CLASSES.rollerball,
];

export function createObstaclesForRound(roundNumber: number): StationeryObstacle[] {
  const layoutIndex = (roundNumber - 1) % 3;

  if (layoutIndex === 0) {
    return [
      {
        id: 'center-eraser',
        kind: 'eraser',
        x: 600,
        y: 360,
        halfW: 44,
        halfH: 22,
        angle: -0.22,
        restitution: 0.92,
        cornerRadius: 5,
        hitFlash: 0,
      },
      {
        id: 'top-sharpener',
        kind: 'sharpener',
        x: 470,
        y: 205,
        halfW: 20,
        halfH: 15,
        angle: 0.35,
        restitution: 0.65,
        cornerRadius: 3,
        hitFlash: 0,
      },
      {
        id: 'bottom-sharpener',
        kind: 'sharpener',
        x: 730,
        y: 515,
        halfW: 20,
        halfH: 15,
        angle: 0.35,
        restitution: 0.65,
        cornerRadius: 3,
        hitFlash: 0,
      },
    ];
  }

  if (layoutIndex === 1) {
    return [
      {
        id: 'center-ruler',
        kind: 'ruler',
        x: 600,
        y: 360,
        halfW: 16,
        halfH: 105,
        angle: 0.18,
        restitution: 0.78,
        cornerRadius: 4,
        hitFlash: 0,
      },
      {
        id: 'left-eraser',
        kind: 'eraser',
        x: 410,
        y: 505,
        halfW: 38,
        halfH: 20,
        angle: 0.42,
        restitution: 0.92,
        cornerRadius: 5,
        hitFlash: 0,
      },
      {
        id: 'right-eraser',
        kind: 'eraser',
        x: 790,
        y: 215,
        halfW: 38,
        halfH: 20,
        angle: 0.42,
        restitution: 0.92,
        cornerRadius: 5,
        hitFlash: 0,
      },
    ];
  }

  return [
    {
      id: 'top-ruler',
      kind: 'ruler',
      x: 600,
      y: 225,
      halfW: 88,
      halfH: 14,
      angle: -0.08,
      restitution: 0.78,
      cornerRadius: 4,
      hitFlash: 0,
    },
    {
      id: 'bottom-ruler',
      kind: 'ruler',
      x: 600,
      y: 495,
      halfW: 88,
      halfH: 14,
      angle: 0.08,
      restitution: 0.78,
      cornerRadius: 4,
      hitFlash: 0,
    },
    {
      id: 'mid-sharpener',
      kind: 'sharpener',
      x: 600,
      y: 360,
      halfW: 22,
      halfH: 16,
      angle: 0.55,
      restitution: 0.7,
      cornerRadius: 3,
      hitFlash: 0,
    },
  ];
}

export function createVentilationFanForRound(roundNumber: number): VentilationFan {
  const slot = (roundNumber - 1) % 4;
  if (slot === 0) {
    // Top rim blowing straight down across center corridor
    return {
      id: 'fan-top-center',
      x: 600,
      y: DESK_BOUNDS.top - 10,
      angle: Math.PI * 0.5,
      range: 495,
      halfWidth: 102,
      strength: 380,
      period: 8.5,
      phaseOffset: 3.1,
      bladeAngle: 0,
    };
  }
  if (slot === 1) {
    // Bottom rim blowing upward across center
    return {
      id: 'fan-bottom-center',
      x: 600,
      y: DESK_BOUNDS.bottom + 10,
      angle: -Math.PI * 0.5,
      range: 495,
      halfWidth: 102,
      strength: 380,
      period: 8.5,
      phaseOffset: 2.9,
      bladeAngle: 0,
    };
  }
  if (slot === 2) {
    // Top-left rim blowing diagonally down-right across midfield
    return {
      id: 'fan-top-diag',
      x: 455,
      y: DESK_BOUNDS.top - 10,
      angle: Math.PI * 0.5 - 0.34,
      range: 520,
      halfWidth: 98,
      strength: 390,
      period: 8.5,
      phaseOffset: 3.0,
      bladeAngle: 0,
    };
  }
  // Bottom-right rim blowing diagonally up-left across midfield
  return {
    id: 'fan-bottom-diag',
    x: 745,
    y: DESK_BOUNDS.bottom + 10,
    angle: -Math.PI * 0.5 - 0.34,
    range: 520,
    halfWidth: 98,
    strength: 390,
    period: 8.5,
    phaseOffset: 3.0,
    bladeAngle: 0,
  };
}

export function getFanWindState(
  fan: VentilationFan,
  fanTime: number
): { status: FanWindStatus; factor: number } {
  const t = ((fanTime + fan.phaseOffset) % fan.period + fan.period) % fan.period;
  // 0..2.8: idle, 2.8..4.1: spin-up telegraph, 4.1..7.6: active gust, 7.6..8.5: spin-down
  if (t < 2.8) {
    return { status: 'idle', factor: 0 };
  }
  if (t < 4.1) {
    const u = (t - 2.8) / 1.3;
    const smooth = u * u * (3 - 2 * u);
    return { status: 'spinup', factor: smooth * 0.14 };
  }
  if (t < 7.6) {
    const u = (t - 4.1) / 3.5;
    const pulse = 0.86 + 0.14 * Math.sin(u * Math.PI * 4);
    return { status: 'gust', factor: pulse };
  }
  const u = 1 - (t - 7.6) / 0.9;
  const smooth = u * u * (3 - 2 * u);
  return { status: 'spindown', factor: smooth * 0.45 };
}

export const DESK_GRAFFITI_QUOTES: readonly string[] = [
  'Gravity 1, your flick 0.',
  'Did you mean to aim for the floor?',
  "Even the rubber eraser wouldn't take that shot.",
  'Carved here in memory of your aim.',
  'Great aerodynamics. Shame about the desk edge.',
  "Physics doesn't accept hall passes.",
  'Bold strategy: donating the round early.',
  'That desk ledge came out of nowhere, huh?',
  'Geometry class called. It wants its angles back.',
  'Left a mark on the floor, not the scoreboard.',
  'The pencil shavings put up a better fight.',
  'Maybe try flicking toward the desk next time.',
  'Watch that first step off the oak.',
  "At least the ink didn't spill on the rug.",
];

export function pickRandomDeskGraffitiQuote(previousQuote?: string): string {
  const pool =
    previousQuote && DESK_GRAFFITI_QUOTES.length > 1
      ? DESK_GRAFFITI_QUOTES.filter((q) => q !== previousQuote)
      : DESK_GRAFFITI_QUOTES;
  const index = Math.floor(Math.random() * pool.length);
  return pool[index] ?? DESK_GRAFFITI_QUOTES[0];
}
