export type GameState =
  | 'TITLE_MENU'
  | 'TOURNAMENT_BRACKET'
  | 'PLAYING'
  | 'PAUSED'
  | 'ROUND_END'
  | 'REPLAYING'
  | 'GAME_OVER';

export type GameMode = 'ai' | 'local' | 'freeplay' | 'tournament';

export type TournamentSize = 4 | 8;

export type AIDifficulty = 'easy' | 'medium' | 'hard';

export type ArenaMode = 'clean' | 'obstacles';

export type PenClassId =
  | 'ballpoint'
  | 'fountain'
  | 'gel'
  | 'marker'
  | 'mechanical'
  | 'rollerball';

export type TurnPhase = 'aiming' | 'ai_thinking' | 'simulating' | 'resolving';

export interface PenClassSpec {
  id: PenClassId;
  name: string;
  tagline: string;
  length: number;
  radius: number;
  mass: number;
  linearDamping: number;
  angularDamping: number;
  restitution: number;
  powerScale: number;
  weightLabel: string;
  gripLabel: string;
  speedLabel: string;
}

export type PenStyleMode = 'standard' | 'custom';
export type PenPatternId =
  | 'solid'
  | 'stripes'
  | 'chevron'
  | 'checkered'
  | 'dots'
  | 'waves'
  | 'camo'
  | 'rings'
  | 'lightning';
export type PenTextureId =
  | 'smooth'
  | 'brushed'
  | 'carbon'
  | 'woodgrain'
  | 'metallic'
  | 'matte';

export interface PenCustomization {
  styleMode: PenStyleMode;
  colorId: string;
  pattern: PenPatternId;
  texture: PenTextureId;
}

export interface PenBody {
  player: 1 | 2;
  spec: PenClassSpec;
  custom: PenCustomization;
  x: number;
  y: number;
  angle: number;
  vx: number;
  vy: number;
  omega: number;
  mass: number;
  inertia: number;
  status: 'active' | 'falling' | 'out';
  fallProgress: number;
  fallVx: number;
  fallVy: number;
  fallSpin: number;
  hitFlash: number;
}

export type ObstacleKind = 'eraser' | 'sharpener' | 'ruler';

export interface StationeryObstacle {
  id: string;
  kind: ObstacleKind;
  x: number;
  y: number;
  halfW: number;
  halfH: number;
  angle: number;
  restitution: number;
  cornerRadius: number;
  hitFlash: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  life: number;
  maxLife: number;
  color: string;
  alpha: number;
}

export interface TrailSegment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  life: number;
  maxLife: number;
  color: string;
  width: number;
}

export type FanWindStatus = 'idle' | 'spinup' | 'gust' | 'spindown';

export interface VentilationFan {
  id: string;
  x: number;
  y: number;
  angle: number;
  range: number;
  halfWidth: number;
  strength: number;
  period: number;
  phaseOffset: number;
  bladeAngle: number;
}

export type DeskDebrisKind = 'shaving' | 'crumb';

export interface DeskDebris {
  id: number;
  kind: DeskDebrisKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  omega: number;
  scale: number;
  rimColor: string;
  woodShade: string;
  landingProgress: number;
  alpha: number;
  fadingOut: boolean;
  fanAngle: number;
  scallops: number;
}

export interface DustMote {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  baseAlpha: number;
  phase: number;
  driftSpeed: number;
  warmth: number;
}

export interface AimDragState {
  active: boolean;
  player: 1 | 2;
  /** Offset along the pen's local axis from center (-halfLen..+halfLen) */
  localGrabOffset: number;
  /** World coords of grab anchor on pen */
  grabX: number;
  grabY: number;
  /** Current pointer world coords */
  dragX: number;
  dragY: number;
  /** Normalized power 0..1 */
  power: number;
  /** Launch velocity vector */
  launchVx: number;
  launchVy: number;
  /** Launch angular velocity */
  launchOmega: number;
  /** Cancel threshold flag (drag too close to grab point) */
  cancelled: boolean;
}

export interface TournamentEntrant {
  id: string;
  seed: number;
  name: string;
  isAI: boolean;
  penClass: PenClassId;
  custom: PenCustomization;
}

export interface TournamentMatchNode {
  id: string;
  roundIndex: number;
  matchIndex: number;
  stageLabel: string;
  entrantAId: string | null;
  entrantBId: string | null;
  winnerId: string | null;
  scoreA: number;
  scoreB: number;
  status: 'pending' | 'ready' | 'completed';
  simulatedByEngine?: boolean;
  summaryNote?: string;
}

export interface TournamentBracketState {
  size: TournamentSize;
  totalRoundsPerMatch: number;
  entrants: TournamentEntrant[];
  matches: TournamentMatchNode[];
  activeMatchId: string | null;
  championId: string | null;
}

export interface MatchConfig {
  mode: GameMode;
  aiDifficulty: AIDifficulty;
  arenaMode: ArenaMode;
  fanEnabled: boolean;
  totalRounds: number;
  p1Pen: PenClassId;
  p2Pen: PenClassId;
  p1Custom: PenCustomization;
  p2Custom: PenCustomization;
  tournamentSize: TournamentSize;
  tournamentEntrants: TournamentEntrant[];
}

export interface MatchStats {
  totalFlicks: number;
  hardestImpact: number;
  p1RingOuts: number;
  p2RingOuts: number;
}

export interface RoundSummary {
  roundNumber: number;
  winner: 1 | 2 | 'draw';
  reason: string;
  p1Wins: number;
  p2Wins: number;
}

export interface DeskGraffitiNote {
  id: number;
  quote: string;
  loserLabel: string;
  roundNumber: number;
  tiltDeg: number;
}

export interface FlickReplayData {
  shooter: 1 | 2;
  pens: PenBody[];
  obstacles: StationeryObstacle[];
  fan: VentilationFan | null;
  fanTime: number;
  localOffset: number;
  grabX: number;
  grabY: number;
  dragX: number;
  dragY: number;
  power: number;
  launchVx: number;
  launchVy: number;
  launchOmega: number;
}

export type RoundEventType = 'Ring Out' | 'Obstacle Hit';

export interface RoundHistoryEntry {
  id: number;
  roundNumber: number;
  winner: 1 | 2 | 'draw';
  eventType: RoundEventType;
  eventDetail: string;
  p1WinsAfter: number;
  p2WinsAfter: number;
}

export type AchievementId =
  | 'double_bank'
  | 'long_ring_out'
  | 'perfect_edge'
  | 'spin_master'
  | 'heavy_clash'
  | 'clean_sweep';

export type AchievementTier = 'gold' | 'silver' | 'bronze';

export interface AchievementDefinition {
  id: AchievementId;
  title: string;
  description: string;
  tier: AchievementTier;
}
