import { AchievementDefinition, AchievementId } from './types';

export const ACHIEVEMENTS: Record<AchievementId, AchievementDefinition> = {
  double_bank: {
    id: 'double_bank',
    title: 'Double Bank Shot',
    description: 'Bounce off 2+ obstacles in one turn to strike or drop a rival.',
    tier: 'gold',
  },
  long_ring_out: {
    id: 'long_ring_out',
    title: 'Long-Distance Ring Out',
    description: 'Knock a rival off the desk from over half a desk away.',
    tier: 'gold',
  },
  perfect_edge: {
    id: 'perfect_edge',
    title: 'Perfect Edge',
    description: 'Survive a turn teetering within 28px of the desk drop-off.',
    tier: 'silver',
  },
  spin_master: {
    id: 'spin_master',
    title: 'Spin Master',
    description: 'Land a high-spin off-center whip strike on your opponent.',
    tier: 'silver',
  },
  heavy_clash: {
    id: 'heavy_clash',
    title: 'Heavy Clash',
    description: 'Deliver a crushing pen-to-pen impact above 620 impulse.',
    tier: 'bronze',
  },
  clean_sweep: {
    id: 'clean_sweep',
    title: 'Clean Sweep',
    description: 'Win a multi-round match without dropping a single round.',
    tier: 'gold',
  },
};

export const ACHIEVEMENT_LIST: AchievementDefinition[] = [
  ACHIEVEMENTS.double_bank,
  ACHIEVEMENTS.long_ring_out,
  ACHIEVEMENTS.perfect_edge,
  ACHIEVEMENTS.spin_master,
  ACHIEVEMENTS.heavy_clash,
  ACHIEVEMENTS.clean_sweep,
];
