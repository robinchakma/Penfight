import { getWinsNeeded, PEN_CLASS_LIST } from './constants';
import {
  PenClassId,
  PenCustomization,
  TournamentBracketState,
  TournamentEntrant,
  TournamentMatchNode,
  TournamentSize,
} from './types';

const AI_RIVAL_NAMES = [
  'Ink Viper',
  'Brass Baron',
  'Gel Dash',
  'Nib Knight',
  'Chalk Shark',
  'Ruler Ace',
  'Desk Phantom',
];

const RIVAL_CUSTOM_PRESETS: PenCustomization[] = [
  { styleMode: 'standard', colorId: 'crimson', pattern: 'chevron', texture: 'brushed' },
  { styleMode: 'custom', colorId: 'amber', pattern: 'waves', texture: 'metallic' },
  { styleMode: 'custom', colorId: 'teal', pattern: 'rings', texture: 'smooth' },
  { styleMode: 'custom', colorId: 'plum', pattern: 'lightning', texture: 'carbon' },
  { styleMode: 'custom', colorId: 'copper', pattern: 'camo', texture: 'matte' },
  { styleMode: 'custom', colorId: 'rose', pattern: 'checkered', texture: 'metallic' },
  { styleMode: 'custom', colorId: 'cobalt', pattern: 'solid', texture: 'woodgrain' },
];

export function createDefaultTournamentEntrants(
  p1Pen: PenClassId,
  p1Custom: PenCustomization
): TournamentEntrant[] {
  const entrants: TournamentEntrant[] = [
    {
      id: 'seed-1',
      seed: 1,
      name: 'Player 1',
      isAI: false,
      penClass: p1Pen,
      custom: { ...p1Custom },
    },
  ];

  for (let i = 1; i < 8; i++) {
    const penSpec = PEN_CLASS_LIST[i % PEN_CLASS_LIST.length];
    entrants.push({
      id: `seed-${i + 1}`,
      seed: i + 1,
      name: AI_RIVAL_NAMES[i - 1] ?? `AI Rival ${i}`,
      isAI: true,
      penClass: penSpec.id,
      custom: { ...(RIVAL_CUSTOM_PRESETS[i - 1] ?? RIVAL_CUSTOM_PRESETS[0]) },
    });
  }

  return entrants;
}

export function applyTournamentPreset(
  entrants: TournamentEntrant[],
  preset: 'solo_ai' | 'all_human'
): TournamentEntrant[] {
  return entrants.map((ent, idx) => {
    if (preset === 'all_human') {
      return {
        ...ent,
        isAI: false,
        name: `Player ${idx + 1}`,
      };
    }
    if (idx === 0) {
      return {
        ...ent,
        isAI: false,
        name: 'Player 1',
      };
    }
    return {
      ...ent,
      isAI: true,
      name: AI_RIVAL_NAMES[idx - 1] ?? `AI Rival ${idx}`,
    };
  });
}

export function createTournamentBracket(
  allEntrants: TournamentEntrant[],
  size: TournamentSize,
  totalRoundsPerMatch: number
): TournamentBracketState {
  const entrants = allEntrants.slice(0, size).map((e, i) => ({
    ...e,
    seed: i + 1,
    name: e.name.trim() || (e.isAI ? `AI Rival ${i + 1}` : `Player ${i + 1}`),
  }));

  const matches: TournamentMatchNode[] = [];

  if (size === 4) {
    // Seed pairings: SF1 (#1 vs #4), SF2 (#2 vs #3) -> Grand Final
    const pairings: Array<[number, number]> = [
      [0, 3],
      [1, 2],
    ];
    pairings.forEach(([aIdx, bIdx], matchIndex) => {
      matches.push({
        id: `r0-m${matchIndex}`,
        roundIndex: 0,
        matchIndex,
        stageLabel: `Semifinal ${matchIndex + 1}`,
        entrantAId: entrants[aIdx].id,
        entrantBId: entrants[bIdx].id,
        winnerId: null,
        scoreA: 0,
        scoreB: 0,
        status: 'ready',
      });
    });

    matches.push({
      id: 'r1-m0',
      roundIndex: 1,
      matchIndex: 0,
      stageLabel: 'Grand Final',
      entrantAId: null,
      entrantBId: null,
      winnerId: null,
      scoreA: 0,
      scoreB: 0,
      status: 'pending',
    });
  } else {
    // 8-player seeded bracket: [1v8, 4v5, 2v7, 3v6] -> [SF1, SF2] -> Grand Final
    const pairings: Array<[number, number]> = [
      [0, 7],
      [3, 4],
      [1, 6],
      [2, 5],
    ];
    pairings.forEach(([aIdx, bIdx], matchIndex) => {
      matches.push({
        id: `r0-m${matchIndex}`,
        roundIndex: 0,
        matchIndex,
        stageLabel: `Quarterfinal ${matchIndex + 1}`,
        entrantAId: entrants[aIdx].id,
        entrantBId: entrants[bIdx].id,
        winnerId: null,
        scoreA: 0,
        scoreB: 0,
        status: 'ready',
      });
    });

    for (let matchIndex = 0; matchIndex < 2; matchIndex++) {
      matches.push({
        id: `r1-m${matchIndex}`,
        roundIndex: 1,
        matchIndex,
        stageLabel: `Semifinal ${matchIndex + 1}`,
        entrantAId: null,
        entrantBId: null,
        winnerId: null,
        scoreA: 0,
        scoreB: 0,
        status: 'pending',
      });
    }

    matches.push({
      id: 'r2-m0',
      roundIndex: 2,
      matchIndex: 0,
      stageLabel: 'Grand Final',
      entrantAId: null,
      entrantBId: null,
      winnerId: null,
      scoreA: 0,
      scoreB: 0,
      status: 'pending',
    });
  }

  return {
    size,
    totalRoundsPerMatch,
    entrants,
    matches,
    activeMatchId: matches[0]?.id ?? null,
    championId: null,
  };
}

export function getTournamentMatchById(
  bracket: TournamentBracketState | null,
  matchId: string | null
): TournamentMatchNode | null {
  if (!bracket || !matchId) return null;
  return bracket.matches.find((m) => m.id === matchId) ?? null;
}

export function getTournamentEntrant(
  bracket: TournamentBracketState | null,
  entrantId: string | null
): TournamentEntrant | null {
  if (!bracket || !entrantId) return null;
  return bracket.entrants.find((e) => e.id === entrantId) ?? null;
}

export function getNextReadyMatch(
  bracket: TournamentBracketState | null
): TournamentMatchNode | null {
  if (!bracket) return null;
  const ready = bracket.matches.filter((m) => m.status === 'ready');
  if (ready.length === 0) return null;
  ready.sort((a, b) => a.roundIndex - b.roundIndex || a.matchIndex - b.matchIndex);
  return ready[0] ?? null;
}

export function recordTournamentMatchResult(
  bracket: TournamentBracketState,
  matchId: string,
  winnerSide: 1 | 2,
  scoreA: number,
  scoreB: number,
  simulatedByEngine = false,
  summaryNote?: string
): TournamentBracketState {
  const target = bracket.matches.find((m) => m.id === matchId);
  if (!target || !target.entrantAId || !target.entrantBId) {
    return bracket;
  }

  const winnerId = winnerSide === 1 ? target.entrantAId : target.entrantBId;
  const maxRoundIndex = bracket.size === 8 ? 2 : 1;
  const nextRoundIndex = target.roundIndex + 1;
  const nextMatchIndex = Math.floor(target.matchIndex / 2);
  const feedsSlotA = target.matchIndex % 2 === 0;

  const updatedMatches = bracket.matches.map((m) => {
    if (m.id === matchId) {
      return {
        ...m,
        winnerId,
        scoreA,
        scoreB,
        status: 'completed' as const,
        simulatedByEngine,
        summaryNote,
      };
    }

    if (
      target.roundIndex < maxRoundIndex &&
      m.roundIndex === nextRoundIndex &&
      m.matchIndex === nextMatchIndex
    ) {
      const nextA = feedsSlotA ? winnerId : m.entrantAId;
      const nextB = !feedsSlotA ? winnerId : m.entrantBId;
      return {
        ...m,
        entrantAId: nextA,
        entrantBId: nextB,
        status: nextA && nextB ? ('ready' as const) : ('pending' as const),
      };
    }

    return m;
  });

  const isFinal = target.roundIndex === maxRoundIndex;
  const nextBracket: TournamentBracketState = {
    ...bracket,
    matches: updatedMatches,
    championId: isFinal ? winnerId : bracket.championId,
    activeMatchId: null,
  };

  if (!isFinal) {
    const nextReady = getNextReadyMatch(nextBracket);
    nextBracket.activeMatchId = nextReady?.id ?? null;
  }

  return nextBracket;
}

const SIM_NOTES = [
  'Ring-out finish',
  'Eraser bank shot',
  'Sharpener deflection',
  'Heavy barrel clash',
  'Edge spin sweep',
];

export function simulateAIMatchResult(
  entrantA: TournamentEntrant,
  entrantB: TournamentEntrant,
  totalRoundsPerMatch: number
): { winnerSide: 1 | 2; scoreA: number; scoreB: number; summaryNote: string } {
  const winsNeeded = getWinsNeeded(totalRoundsPerMatch);
  // Subtle seed advantage + randomness so upsets happen naturally
  const seedEdge = (entrantB.seed - entrantA.seed) * 0.035;
  const probA = Math.max(0.28, Math.min(0.72, 0.5 + seedEdge));

  let scoreA = 0;
  let scoreB = 0;
  while (scoreA < winsNeeded && scoreB < winsNeeded) {
    if (Math.random() < probA) {
      scoreA++;
    } else {
      scoreB++;
    }
  }

  const winnerSide: 1 | 2 = scoreA >= winsNeeded ? 1 : 2;
  const summaryNote = SIM_NOTES[Math.floor(Math.random() * SIM_NOTES.length)] ?? SIM_NOTES[0];
  return { winnerSide, scoreA, scoreB, summaryNote };
}

export function hasHumanAliveInBracket(bracket: TournamentBracketState): boolean {
  const entrantMap = new Map(bracket.entrants.map((e) => [e.id, e]));

  for (const m of bracket.matches) {
    if (m.status === 'ready') {
      const a = m.entrantAId ? entrantMap.get(m.entrantAId) : null;
      const b = m.entrantBId ? entrantMap.get(m.entrantBId) : null;
      if ((a && !a.isAI) || (b && !b.isAI)) {
        return true;
      }
    }
    if (m.status === 'pending') {
      const a = m.entrantAId ? entrantMap.get(m.entrantAId) : null;
      const b = m.entrantBId ? entrantMap.get(m.entrantBId) : null;
      if ((a && !a.isAI) || (b && !b.isAI)) {
        return true;
      }
    }
  }

  return false;
}
