import {
  DESK_BOUNDS,
  DESK_TEXTURE_URL,
  getCustomColorPreset,
  getFanWindState,
  MAX_PULL_DISTANCE,
  PLAYER_COLORS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from './constants';
import {
  AimDragState,
  DeskDebris,
  DustMote,
  Particle,
  PenBody,
  PenCustomization,
  StationeryObstacle,
  TrailSegment,
  VentilationFan,
} from './types';

export interface RenderContextState {
  pens: PenBody[];
  obstacles: StationeryObstacle[];
  particles: Particle[];
  trails: TrailSegment[];
  deskDebris: DeskDebris[];
  dustMotes: DustMote[];
  fan: VentilationFan | null;
  fanTime: number;
  aimDrag: AimDragState | null;
  aiTelegraph: {
    active: boolean;
    grabX: number;
    grabY: number;
    dragX: number;
    dragY: number;
    power: number;
    progress: number;
  } | null;
  activeTurn: 1 | 2;
  showTurnHighlight: boolean;
  hoverGrab: { x: number; y: number } | null;
  shakeX: number;
  shakeY: number;
  time: number;
}

class TabletopRenderer {
  private deskTexture: HTMLImageElement | null = null;
  private textureLoaded = false;
  private cachedDeskCanvas: HTMLCanvasElement | null = null;

  constructor() {
    if (typeof Image !== 'undefined') {
      const img = new Image();
      img.onload = () => {
        this.deskTexture = img;
        this.textureLoaded = true;
        this.cachedDeskCanvas = null; // Rebuild cache with loaded photo texture
      };
      img.src = DESK_TEXTURE_URL;
    }
  }

  private buildDeskCache(): HTMLCanvasElement {
    const off = document.createElement('canvas');
    off.width = WORLD_WIDTH;
    off.height = WORLD_HEIGHT;
    const ctx = off.getContext('2d')!;

    const { left, top, width, height, cornerRadius } = DESK_BOUNDS;

    // 1. Deep classroom floor drop shadow under desk
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.72)';
    ctx.shadowBlur = 42;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 20;
    this.roundedRectPath(ctx, left, top, width, height, cornerRadius);
    ctx.fillStyle = '#5B3A1E';
    ctx.fill();
    ctx.restore();

    // 2. Thick wooden slab front/bottom lip for 2.5D depth
    ctx.save();
    this.roundedRectPath(ctx, left, top + 10, width, height, cornerRadius);
    const lipGrad = ctx.createLinearGradient(0, top, 0, top + height + 10);
    lipGrad.addColorStop(0, '#784E28');
    lipGrad.addColorStop(1, '#4C2E14');
    ctx.fillStyle = lipGrad;
    ctx.fill();
    ctx.restore();

    // 3. Clipped Wooden Desk Top Surface
    ctx.save();
    this.roundedRectPath(ctx, left, top, width, height, cornerRadius);
    ctx.clip();

    if (this.textureLoaded && this.deskTexture) {
      ctx.drawImage(this.deskTexture, left, top, width, height);
      // Warm sunlit honey-oak glaze for cohesive lighting
      const glaze = ctx.createRadialGradient(
        WORLD_WIDTH * 0.5,
        WORLD_HEIGHT * 0.45,
        80,
        WORLD_WIDTH * 0.5,
        WORLD_HEIGHT * 0.5,
        620
      );
      glaze.addColorStop(0, 'rgba(255, 232, 195, 0.08)');
      glaze.addColorStop(1, 'rgba(38, 20, 6, 0.22)');
      ctx.fillStyle = glaze;
      ctx.fillRect(left, top, width, height);
    } else {
      // Procedural warm honey-oak wood grain fallback
      const woodGrad = ctx.createLinearGradient(left, top, left + width, top + height);
      woodGrad.addColorStop(0, '#C99B68');
      woodGrad.addColorStop(0.5, '#BA8855');
      woodGrad.addColorStop(1, '#AE7B48');
      ctx.fillStyle = woodGrad;
      ctx.fillRect(left, top, width, height);

      ctx.strokeStyle = 'rgba(84, 48, 18, 0.14)';
      ctx.lineWidth = 1.5;
      for (let y = top + 12; y < top + height; y += 16) {
        ctx.beginPath();
        ctx.moveTo(left, y);
        ctx.bezierCurveTo(
          left + width * 0.33,
          y + Math.sin(y * 0.05) * 6,
          left + width * 0.66,
          y - Math.cos(y * 0.04) * 6,
          left + width,
          y
        );
        ctx.stroke();
      }
    }

    // 4. Nostalgic Carved Classroom Doodles (etched wood + faded ballpoint ink)
    this.drawCarvedDoodles(ctx);

    // 5. Crisp Desk Drop-Off Edge Trim / Bevel Highlight
    ctx.strokeStyle = 'rgba(255, 240, 210, 0.28)';
    ctx.lineWidth = 3;
    this.roundedRectPath(ctx, left + 1.5, top + 1.5, width - 3, height - 3, cornerRadius - 1);
    ctx.stroke();

    // Subtle danger edge margin indicator (faint wood-burned ruler border 16px inside)
    ctx.strokeStyle = 'rgba(65, 34, 12, 0.18)';
    ctx.lineWidth = 1;
    ctx.setLineDash([8, 8]);
    this.roundedRectPath(ctx, left + 14, top + 14, width - 28, height - 28, cornerRadius - 6);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.restore();

    // Outer crisp border around the desk
    ctx.save();
    this.roundedRectPath(ctx, left, top, width, height, cornerRadius);
    ctx.strokeStyle = '#3E240E';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    return off;
  }

  private drawCarvedDoodles(ctx: CanvasRenderingContext2D): void {
    const { left, right, top, bottom } = DESK_BOUNDS;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Subtle carved tic-tac-toe grid (top-left area)
    ctx.save();
    ctx.translate(left + 95, top + 92);
    ctx.rotate(-0.14);
    ctx.strokeStyle = 'rgba(54, 30, 12, 0.22)';
    ctx.lineWidth = 2.2;
    // Grid lines
    for (const o of [-14, 14]) {
      ctx.beginPath();
      ctx.moveTo(o, -36);
      ctx.lineTo(o, 36);
      ctx.moveTo(-36, o);
      ctx.lineTo(36, o);
      ctx.stroke();
    }
    // Faded blue ink X's & O's
    ctx.strokeStyle = 'rgba(28, 62, 138, 0.2)';
    ctx.lineWidth = 2;
    const drawX = (cx: number, cy: number) => {
      ctx.beginPath();
      ctx.moveTo(cx - 7, cy - 7);
      ctx.lineTo(cx + 7, cy + 7);
      ctx.moveTo(cx + 7, cy - 7);
      ctx.lineTo(cx - 7, cy + 7);
      ctx.stroke();
    };
    const drawO = (cx: number, cy: number) => {
      ctx.beginPath();
      ctx.arc(cx, cy, 7.5, 0, Math.PI * 2);
      ctx.stroke();
    };
    drawX(-26, -26);
    drawO(0, 0);
    drawX(26, 26);
    drawO(26, -26);
    drawX(0, 26);
    ctx.restore();

    // Carved 5-point star + lightning bolt (bottom-left area)
    ctx.save();
    ctx.translate(left + 110, bottom - 82);
    ctx.rotate(0.2);
    ctx.strokeStyle = 'rgba(48, 26, 10, 0.24)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i * 4 * Math.PI) / 5 - Math.PI / 2;
      const sx = Math.cos(a) * 22;
      const sy = Math.sin(a) * 22;
      if (i === 0) ctx.moveTo(sx, sy);
      else ctx.lineTo(sx, sy);
    }
    ctx.closePath();
    ctx.stroke();

    // Lightning bolt nearby
    ctx.translate(52, -10);
    ctx.beginPath();
    ctx.moveTo(4, -18);
    ctx.lineTo(-8, 2);
    ctx.lineTo(1, 2);
    ctx.lineTo(-5, 20);
    ctx.lineTo(10, -2);
    ctx.lineTo(1, -2);
    ctx.closePath();
    ctx.stroke();
    ctx.restore();

    // Isometric doodle cube + paper airplane (bottom-right area)
    ctx.save();
    ctx.translate(right - 108, bottom - 88);
    ctx.rotate(-0.18);
    ctx.strokeStyle = 'rgba(42, 24, 10, 0.21)';
    ctx.lineWidth = 1.9;
    // Cube
    ctx.strokeRect(-14, -14, 24, 24);
    ctx.strokeRect(-4, -24, 24, 24);
    ctx.beginPath();
    ctx.moveTo(-14, -14);
    ctx.lineTo(-4, -24);
    ctx.moveTo(10, -14);
    ctx.lineTo(20, -24);
    ctx.moveTo(-14, 10);
    ctx.lineTo(-4, 0);
    ctx.moveTo(10, 10);
    ctx.lineTo(20, 0);
    ctx.stroke();
    ctx.restore();

    // Paper airplane + dotted flight loop (top-right area)
    ctx.save();
    ctx.translate(right - 120, top + 84);
    ctx.rotate(0.15);
    ctx.strokeStyle = 'rgba(30, 58, 138, 0.18)';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(22, -4);
    ctx.lineTo(-16, -14);
    ctx.lineTo(-8, 0);
    ctx.lineTo(-14, 12);
    ctx.closePath();
    ctx.moveTo(22, -4);
    ctx.lineTo(-8, 0);
    ctx.stroke();

    ctx.setLineDash([4, 5]);
    ctx.beginPath();
    ctx.moveTo(-24, 4);
    ctx.bezierCurveTo(-55, 24, -75, -14, -108, 6);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // Center duel circle etching (subtle classroom chalk/pencil arena ring)
    ctx.save();
    ctx.strokeStyle = 'rgba(54, 30, 12, 0.12)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(WORLD_WIDTH * 0.5, WORLD_HEIGHT * 0.5, 118, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(WORLD_WIDTH * 0.5, WORLD_HEIGHT * 0.5, 5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // Faint tally marks carved near top-center edge
    ctx.save();
    ctx.translate(WORLD_WIDTH * 0.5 - 18, top + 34);
    ctx.strokeStyle = 'rgba(50, 28, 10, 0.2)';
    ctx.lineWidth = 1.8;
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(i * 8, -9);
      ctx.lineTo(i * 8, 9);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.moveTo(-4, 6);
    ctx.lineTo(28, -6);
    ctx.stroke();
    ctx.restore();

    ctx.restore();
  }

  private roundedRectPath(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ): void {
    const radius = Math.min(r, w * 0.5, h * 0.5);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + w - radius, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
    ctx.lineTo(x + w, y + h - radius);
    ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
    ctx.lineTo(x + radius, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  public render(ctx: CanvasRenderingContext2D, state: RenderContextState): void {
    ctx.clearRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

    // 1. Classroom slate floor backdrop
    const bgGrad = ctx.createRadialGradient(
      WORLD_WIDTH * 0.5,
      WORLD_HEIGHT * 0.45,
      140,
      WORLD_WIDTH * 0.5,
      WORLD_HEIGHT * 0.5,
      780
    );
    bgGrad.addColorStop(0, '#1D252E');
    bgGrad.addColorStop(1, '#0E1318');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

    ctx.save();
    ctx.translate(state.shakeX, state.shakeY);

    // 2. Cached Desk Surface + Carved Doodles
    if (!this.cachedDeskCanvas) {
      this.cachedDeskCanvas = this.buildDeskCache();
    }
    ctx.drawImage(this.cachedDeskCanvas, 0, 0);

    // 2.5 Dynamic Desk Debris (pencil shavings & eraser crumbs on the wood)
    for (const item of state.deskDebris) {
      this.drawDeskDebris(ctx, item);
    }

    // 2.7 Localized Ventilation Fan Wind Zone on the Desk
    if (state.fan) {
      this.drawFanWindZone(ctx, state.fan, state.fanTime, state.time);
    }

    // 3. Motion Trails
    for (const trail of state.trails) {
      const alpha = Math.max(0, trail.life / trail.maxLife) * 0.32;
      ctx.save();
      ctx.strokeStyle = trail.color;
      ctx.globalAlpha = alpha;
      ctx.lineWidth = trail.width;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(trail.x1, trail.y1);
      ctx.lineTo(trail.x2, trail.y2);
      ctx.stroke();
      ctx.restore();
    }

    // 4. Stationery Obstacles
    for (const obs of state.obstacles) {
      this.drawObstacle(ctx, obs);
    }

    // 4.5 Desk-Edge Ventilation Fan Hardware
    if (state.fan) {
      this.drawVentilationFan(ctx, state.fan, state.fanTime);
    }

    // 5. Falling Pens (drawn beneath active desk pens if dropping off)
    for (const pen of state.pens) {
      if (pen.status === 'falling') {
        this.drawPen(ctx, pen, false, state.time);
      }
    }

    // 6. Active Pens
    for (const pen of state.pens) {
      if (pen.status === 'active') {
        const isHighlighted = state.showTurnHighlight && pen.player === state.activeTurn;
        this.drawPen(ctx, pen, isHighlighted, state.time);
      }
    }

    // 7. Hover grab affordance on active pen
    if (state.hoverGrab && !state.aimDrag?.active) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(state.hoverGrab.x, state.hoverGrab.y, 9, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
      ctx.fill();
      ctx.strokeStyle = PLAYER_COLORS[state.activeTurn].primary;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }

    // 8. Slingshot Aiming Telegraph (Human or AI)
    if (state.aimDrag?.active) {
      const activePen = state.pens.find((p) => p.player === state.aimDrag!.player);
      if (activePen) {
        this.drawSlingshot(
          ctx,
          activePen,
          state.aimDrag.grabX,
          state.aimDrag.grabY,
          state.aimDrag.dragX,
          state.aimDrag.dragY,
          state.aimDrag.localGrabOffset,
          state.aimDrag.power,
          state.aimDrag.cancelled,
          PLAYER_COLORS[state.aimDrag.player].primary
        );
      }
    } else if (state.aiTelegraph?.active) {
      const aiPen = state.pens.find((p) => p.player === 2);
      if (aiPen) {
        const t = state.aiTelegraph.progress;
        const curDragX =
          state.aiTelegraph.grabX + (state.aiTelegraph.dragX - state.aiTelegraph.grabX) * t;
        const curDragY =
          state.aiTelegraph.grabY + (state.aiTelegraph.dragY - state.aiTelegraph.grabY) * t;
        this.drawSlingshot(
          ctx,
          aiPen,
          state.aiTelegraph.grabX,
          state.aiTelegraph.grabY,
          curDragX,
          curDragY,
          0,
          state.aiTelegraph.power * t,
          false,
          PLAYER_COLORS[2].primary
        );
      }
    }

    // 9. Impact Particles
    for (const pt of state.particles) {
      const ratio = Math.max(0, pt.life / pt.maxLife);
      ctx.save();
      ctx.globalAlpha = pt.alpha * ratio;
      ctx.fillStyle = pt.color;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * (0.4 + 0.6 * ratio), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();

    // 10. Diagonal afternoon classroom sunlight & floating dust motes
    this.drawClassroomLightAndDust(ctx, state.dustMotes, state.time);
  }

  private drawFanWindZone(
    ctx: CanvasRenderingContext2D,
    fan: VentilationFan,
    fanTime: number,
    animTime: number
  ): void {
    const { status, factor } = getFanWindState(fan, fanTime);
    const { left, top, width, height, cornerRadius } = DESK_BOUNDS;

    ctx.save();
    this.roundedRectPath(ctx, left, top, width, height, cornerRadius);
    ctx.clip();

    ctx.translate(fan.x, fan.y);
    ctx.rotate(fan.angle);

    // Subtle corridor outline so players can read the wind boundary even when idle
    const borderAlpha =
      status === 'gust' ? 0.34 : status === 'spinup' ? 0.28 : status === 'spindown' ? 0.2 : 0.1;
    ctx.strokeStyle =
      status === 'spinup'
        ? `rgba(217, 119, 6, ${borderAlpha})`
        : `rgba(224, 242, 254, ${borderAlpha})`;
    ctx.lineWidth = 1.4;
    ctx.setLineDash([8, 8]);
    ctx.beginPath();
    ctx.moveTo(18, -fan.halfWidth);
    ctx.lineTo(fan.range, -fan.halfWidth);
    ctx.moveTo(18, fan.halfWidth);
    ctx.lineTo(fan.range, fan.halfWidth);
    ctx.stroke();
    ctx.setLineDash([]);

    // Soft airflow gradient wash across the localized zone
    const zoneAlpha =
      status === 'spinup' ? 0.08 + 0.05 * Math.sin(animTime * 10) : factor * 0.18;
    if (zoneAlpha > 0.01) {
      const grad = ctx.createLinearGradient(0, 0, fan.range, 0);
      if (status === 'spinup') {
        grad.addColorStop(0, `rgba(254, 243, 199, ${zoneAlpha})`);
        grad.addColorStop(0.7, `rgba(253, 230, 138, ${zoneAlpha * 0.65})`);
        grad.addColorStop(1, 'rgba(253, 230, 138, 0)');
      } else {
        grad.addColorStop(0, `rgba(224, 242, 254, ${zoneAlpha})`);
        grad.addColorStop(0.68, `rgba(186, 230, 253, ${zoneAlpha * 0.7})`);
        grad.addColorStop(1, 'rgba(186, 230, 253, 0)');
      }
      ctx.fillStyle = grad;
      ctx.fillRect(10, -fan.halfWidth, fan.range - 10, fan.halfWidth * 2);
    }

    // Animated directional wind ribbons & chevrons
    if (status === 'spinup') {
      const pulse = 0.22 + 0.18 * Math.sin(animTime * 11);
      ctx.strokeStyle = `rgba(217, 119, 6, ${pulse})`;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      for (let i = 0; i < 4; i++) {
        const cx = 65 + ((animTime * 90 + i * 110) % (fan.range - 80));
        ctx.beginPath();
        ctx.moveTo(cx - 10, -24);
        ctx.lineTo(cx, 0);
        ctx.lineTo(cx - 10, 24);
        ctx.stroke();
      }
    } else if (factor > 0.08) {
      const streamSpeed = 240 + factor * 360;
      const laneOffsets = [-0.68, -0.34, 0, 0.34, 0.68];
      ctx.lineCap = 'round';

      laneOffsets.forEach((laneRatio, idx) => {
        const ly = laneRatio * (fan.halfWidth * 0.85);
        for (let seg = 0; seg < 3; seg++) {
          const travel = (animTime * streamSpeed + idx * 73 + seg * 165) % (fan.range - 30);
          const xStart = 20 + travel;
          const len = 38 + factor * 34;
          const xEnd = Math.min(fan.range, xStart + len);
          const fade = (1 - travel / fan.range) * (1 - Math.abs(laneRatio) * 0.35) * factor;
          if (xEnd <= xStart + 4 || fade <= 0.02) continue;

          ctx.strokeStyle = `rgba(240, 249, 255, ${0.46 * fade})`;
          ctx.lineWidth = 1.8 + factor * 0.8;
          ctx.beginPath();
          ctx.moveTo(xStart, ly + Math.sin(xStart * 0.04 + idx) * 3);
          ctx.quadraticCurveTo(
            (xStart + xEnd) * 0.5,
            ly - Math.cos(xStart * 0.05 + idx) * 4,
            xEnd,
            ly + Math.sin(xEnd * 0.04 + idx) * 3
          );
          ctx.stroke();
        }
      });
    }

    ctx.restore();
  }

  private drawVentilationFan(
    ctx: CanvasRenderingContext2D,
    fan: VentilationFan,
    fanTime: number
  ): void {
    const { status } = getFanWindState(fan, fanTime);

    ctx.save();
    ctx.translate(fan.x, fan.y);
    ctx.rotate(fan.angle);

    // Desk edge C-clamp bracket behind fan housing
    ctx.fillStyle = '#475569';
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 1.6;
    this.roundedRectPath(ctx, -18, -16, 22, 32, 4);
    ctx.fill();
    ctx.stroke();

    // Contact shadow
    ctx.save();
    ctx.translate(3, 5);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.arc(4, 0, 27, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Retro teal-enamel motor cowl & wire safety ring
    ctx.beginPath();
    ctx.arc(4, 0, 27, 0, Math.PI * 2);
    ctx.fillStyle = '#1E293B';
    ctx.fill();
    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 2.4;
    ctx.stroke();

    // Inner dark grille recess
    ctx.beginPath();
    ctx.arc(4, 0, 23, 0, Math.PI * 2);
    ctx.fillStyle = '#0F172A';
    ctx.fill();

    // 4 spinning classroom fan blades
    ctx.save();
    ctx.translate(4, 0);
    ctx.rotate(fan.bladeAngle);
    for (let i = 0; i < 4; i++) {
      ctx.rotate(Math.PI * 0.5);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(10, -11, 20, -4);
      ctx.quadraticCurveTo(16, 6, 3, 4);
      ctx.closePath();
      ctx.fillStyle = status === 'gust' ? '#7DD3FC' : '#38BDF8';
      ctx.fill();
      ctx.strokeStyle = '#0284C7';
      ctx.lineWidth = 0.9;
      ctx.stroke();
    }
    ctx.restore();

    // Protective wire cage crossbars
    ctx.strokeStyle = 'rgba(203, 213, 225, 0.55)';
    ctx.lineWidth = 1.2;
    for (let a = 0; a < 4; a++) {
      const theta = (a * Math.PI) / 4;
      ctx.beginPath();
      ctx.moveTo(4 - Math.cos(theta) * 23, -Math.sin(theta) * 23);
      ctx.lineTo(4 + Math.cos(theta) * 23, Math.sin(theta) * 23);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.arc(4, 0, 14, 0, Math.PI * 2);
    ctx.stroke();

    // Center brushed hub cap
    ctx.beginPath();
    ctx.arc(4, 0, 7, 0, Math.PI * 2);
    ctx.fillStyle = '#CBD5E1';
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.4;
    ctx.stroke();

    // Status LED on top of fan clamp (amber spinup, emerald gust, dim idle)
    ctx.beginPath();
    ctx.arc(-10, -9, 3, 0, Math.PI * 2);
    ctx.fillStyle =
      status === 'gust' ? '#10B981' : status === 'spinup' ? '#F59E0B' : '#64748B';
    ctx.fill();

    ctx.restore();
  }

  private drawDeskDebris(ctx: CanvasRenderingContext2D, item: DeskDebris): void {
    if (item.alpha <= 0.01) return;

    const fallOffset = (1 - item.landingProgress) * 14;
    const landScale = item.scale * (1 + (1 - item.landingProgress) * 0.28);

    ctx.save();
    ctx.translate(item.x, item.y);
    ctx.rotate(item.angle);
    ctx.globalAlpha = item.alpha;

    if (item.kind === 'crumb') {
      // Tiny rubber eraser crumb
      ctx.save();
      ctx.translate(1.5 + fallOffset * 0.35, 2 + fallOffset * 0.45);
      ctx.fillStyle = 'rgba(20, 10, 2, 0.25)';
      ctx.beginPath();
      ctx.ellipse(0, 0, 3.2 * landScale, 2.1 * landScale, 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.fillStyle = item.rimColor;
      ctx.beginPath();
      ctx.moveTo(-3 * landScale, -1.2 * landScale);
      ctx.lineTo(0.8 * landScale, -2.3 * landScale);
      ctx.lineTo(3.4 * landScale, 0.4 * landScale);
      ctx.lineTo(1.1 * landScale, 2.2 * landScale);
      ctx.lineTo(-2.6 * landScale, 1.6 * landScale);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = 'rgba(65, 25, 35, 0.28)';
      ctx.lineWidth = 0.7;
      ctx.stroke();
      ctx.restore();
      return;
    }

    // Fluted cedar pencil shaving fan
    const outerR = 13.5 * landScale;
    const startA = -item.fanAngle * 0.5;
    const endA = item.fanAngle * 0.5;
    const step = item.fanAngle / item.scallops;

    const traceFanPath = () => {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      for (let i = 0; i < item.scallops; i++) {
        const a0 = startA + i * step;
        const aMid = a0 + step * 0.5;
        const a1 = a0 + step;
        const tipR = outerR * (0.94 + (i % 2) * 0.08);
        const ctrlR = outerR * 1.13;
        ctx.lineTo(Math.cos(a0) * tipR, Math.sin(a0) * tipR);
        ctx.quadraticCurveTo(
          Math.cos(aMid) * ctrlR,
          Math.sin(aMid) * ctrlR,
          Math.cos(a1) * tipR,
          Math.sin(a1) * tipR
        );
      }
      ctx.closePath();
    };

    // Contact / falling shadow
    ctx.save();
    ctx.translate(2 + fallOffset * 0.45, 3 + fallOffset * 0.55);
    traceFanPath();
    ctx.fillStyle = 'rgba(22, 11, 3, 0.24)';
    ctx.fill();
    ctx.restore();

    // Pale cedar wood body
    traceFanPath();
    const woodGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, outerR);
    woodGrad.addColorStop(0, '#D49E6A');
    woodGrad.addColorStop(0.55, item.woodShade);
    woodGrad.addColorStop(1, '#F8E3C6');
    ctx.fillStyle = woodGrad;
    ctx.fill();

    // Scalloped painted lacquer rim along outer arc
    ctx.save();
    traceFanPath();
    ctx.clip();
    ctx.strokeStyle = item.rimColor;
    ctx.lineWidth = 3.6 * landScale;
    ctx.beginPath();
    ctx.arc(0, 0, outerR * 0.98, startA - 0.1, endA + 0.1);
    ctx.stroke();

    // Radial wood grain ridges
    ctx.strokeStyle = 'rgba(120, 72, 32, 0.26)';
    ctx.lineWidth = 0.75;
    for (let i = 1; i < item.scallops; i++) {
      const a = startA + i * step;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 2.5, Math.sin(a) * 2.5);
      ctx.lineTo(Math.cos(a) * (outerR * 0.9), Math.sin(a) * (outerR * 0.9));
      ctx.stroke();
    }
    ctx.restore();

    // Subtle dark edge & tiny graphite collar tip
    traceFanPath();
    ctx.strokeStyle = 'rgba(72, 42, 16, 0.34)';
    ctx.lineWidth = 0.85;
    ctx.stroke();

    ctx.fillStyle = '#334155';
    ctx.beginPath();
    ctx.arc(Math.cos(0) * 1.4, Math.sin(0) * 1.4, 1.5 * landScale, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private drawClassroomLightAndDust(
    ctx: CanvasRenderingContext2D,
    dustMotes: DustMote[],
    time: number
  ): void {
    // Subtle diagonal afternoon window sunlight beams across the desk
    const sway = Math.sin(time * 0.22) * 18;
    ctx.save();

    const beamGrad = ctx.createLinearGradient(180 + sway, 0, 960 + sway, WORLD_HEIGHT);
    beamGrad.addColorStop(0, 'rgba(255, 243, 210, 0.0)');
    beamGrad.addColorStop(0.28, 'rgba(255, 240, 200, 0.045)');
    beamGrad.addColorStop(0.52, 'rgba(255, 245, 214, 0.065)');
    beamGrad.addColorStop(0.75, 'rgba(255, 238, 195, 0.032)');
    beamGrad.addColorStop(1, 'rgba(255, 238, 195, 0.0)');

    ctx.fillStyle = beamGrad;
    ctx.beginPath();
    ctx.moveTo(190 + sway, 0);
    ctx.lineTo(670 + sway, 0);
    ctx.lineTo(1060 + sway, WORLD_HEIGHT);
    ctx.lineTo(440 + sway, WORLD_HEIGHT);
    ctx.closePath();
    ctx.fill();

    // Secondary slimmer window-pane shaft
    ctx.fillStyle = 'rgba(255, 247, 224, 0.035)';
    ctx.beginPath();
    ctx.moveTo(735 + sway * 0.7, 0);
    ctx.lineTo(905 + sway * 0.7, 0);
    ctx.lineTo(1180 + sway * 0.7, WORLD_HEIGHT);
    ctx.lineTo(1010 + sway * 0.7, WORLD_HEIGHT);
    ctx.closePath();
    ctx.fill();

    // Floating dust motes catching the classroom light
    for (const mote of dustMotes) {
      // Calculate proximity to the main diagonal light beam for natural brightness modulation
      const beamCenterX = 430 + sway + (mote.y / WORLD_HEIGHT) * 320;
      const distFromBeam = Math.abs(mote.x - beamCenterX);
      const beamBoost = Math.max(0.25, 1 - distFromBeam / 460);
      const twinkle = 0.6 + 0.4 * Math.sin(time * (1.2 + mote.driftSpeed) + mote.phase);
      const alpha = mote.baseAlpha * beamBoost * twinkle;

      if (alpha <= 0.02) continue;

      if (mote.size > 1.85) {
        ctx.fillStyle = `rgba(255, 243, 205, ${alpha * 0.35})`;
        ctx.beginPath();
        ctx.arc(mote.x, mote.y, mote.size * 2.1, 0, Math.PI * 2);
        ctx.fill();
      }

      const g = Math.round(238 + mote.warmth * 12);
      const b = Math.round(196 + (1 - mote.warmth) * 44);
      ctx.fillStyle = `rgba(255, ${g}, ${b}, ${alpha})`;
      ctx.beginPath();
      ctx.arc(mote.x, mote.y, mote.size, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  private drawObstacle(ctx: CanvasRenderingContext2D, obs: StationeryObstacle): void {
    ctx.save();
    ctx.translate(obs.x, obs.y);
    ctx.rotate(obs.angle);

    // Contact shadow
    ctx.save();
    ctx.translate(4, 6);
    this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
    ctx.fillStyle = 'rgba(20, 10, 2, 0.34)';
    ctx.fill();
    ctx.restore();

    if (obs.kind === 'eraser') {
      // Classic two-tone pink & blue beveled rubber eraser with cream paper sleeve
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      ctx.fillStyle = '#F28B99';
      ctx.fill();

      // Blue abrasive third
      ctx.save();
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      ctx.clip();
      ctx.fillStyle = '#5C8ED6';
      ctx.fillRect(obs.halfW * 0.25, -obs.halfH, obs.halfW, obs.halfH * 2);

      // Paper sleeve band
      ctx.fillStyle = '#FAF3E3';
      ctx.fillRect(-obs.halfW * 0.45, -obs.halfH, obs.halfW * 0.85, obs.halfH * 2);
      ctx.strokeStyle = 'rgba(40, 30, 20, 0.2)';
      ctx.lineWidth = 1;
      ctx.strokeRect(-obs.halfW * 0.45, -obs.halfH, obs.halfW * 0.85, obs.halfH * 2);
      ctx.restore();

      // Crisp border
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      ctx.strokeStyle = '#6E3642';
      ctx.lineWidth = 1.8;
      ctx.stroke();
    } else if (obs.kind === 'sharpener') {
      // Machined brass/steel pencil sharpener block
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      const metal = ctx.createLinearGradient(-obs.halfW, -obs.halfH, obs.halfW, obs.halfH);
      metal.addColorStop(0, '#D4D9DF');
      metal.addColorStop(0.5, '#A2ABB5');
      metal.addColorStop(1, '#79838E');
      ctx.fillStyle = metal;
      ctx.fill();
      ctx.strokeStyle = '#3B4249';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Recessed angled blade + screw
      ctx.fillStyle = '#4B535D';
      ctx.fillRect(-obs.halfW * 0.55, -obs.halfH * 0.55, obs.halfW * 1.1, obs.halfH * 1.1);
      ctx.fillStyle = '#E5E7EB';
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Clear amber-tinted acrylic ruler with millimeter tick marks
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      ctx.fillStyle = 'rgba(253, 230, 138, 0.72)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(146, 64, 14, 0.68)';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Millimeter ticks along the long axis
      ctx.strokeStyle = 'rgba(120, 53, 15, 0.65)';
      ctx.lineWidth = 1;
      const horizontal = obs.halfW >= obs.halfH;
      if (horizontal) {
        for (let x = -obs.halfW + 8; x <= obs.halfW - 8; x += 8) {
          const tickLen = Math.round(x) % 24 === 0 ? 9 : 5;
          ctx.beginPath();
          ctx.moveTo(x, -obs.halfH);
          ctx.lineTo(x, -obs.halfH + tickLen);
          ctx.stroke();
        }
      } else {
        for (let y = -obs.halfH + 8; y <= obs.halfH - 8; y += 8) {
          const tickLen = Math.round(y) % 24 === 0 ? 9 : 5;
          ctx.beginPath();
          ctx.moveTo(-obs.halfW, y);
          ctx.lineTo(-obs.halfW + tickLen, y);
          ctx.stroke();
        }
      }
    }

    if (obs.hitFlash > 0) {
      ctx.globalAlpha = obs.hitFlash * 0.4;
      ctx.fillStyle = '#FFFFFF';
      this.roundedRectPath(ctx, -obs.halfW, -obs.halfH, obs.halfW * 2, obs.halfH * 2, obs.cornerRadius);
      ctx.fill();
    }

    ctx.restore();
  }

  private drawPen(
    ctx: CanvasRenderingContext2D,
    pen: PenBody,
    isHighlighted: boolean,
    time: number
  ): void {
    const colors = PLAYER_COLORS[pen.player];
    const len = pen.spec.length;
    const r = pen.spec.radius;
    const half = len * 0.5;

    ctx.save();
    ctx.translate(pen.x, pen.y);
    ctx.rotate(pen.angle);

    // Fall-off scale + fade when tumbling off desk
    if (pen.status === 'falling') {
      const scale = Math.max(0.25, 1 - pen.fallProgress * 0.65);
      ctx.scale(scale, scale);
      ctx.globalAlpha = Math.max(0, 1 - pen.fallProgress * 0.9);
    }

    // Active turn breathing halo
    if (isHighlighted && pen.status === 'active') {
      const pulse = 0.55 + 0.45 * Math.sin(time * 4.5);
      ctx.save();
      ctx.strokeStyle = colors.primary;
      ctx.globalAlpha = 0.25 + pulse * 0.25;
      ctx.lineWidth = 4;
      this.roundedRectPath(ctx, -half - 6, -r - 6, len + 12, r * 2 + 12, r + 6);
      ctx.stroke();
      ctx.restore();
    }

    // Tabletop contact shadow
    ctx.save();
    const shadowOffset = pen.status === 'falling' ? 14 : 4;
    ctx.translate(shadowOffset, shadowOffset + 2);
    ctx.fillStyle = pen.status === 'falling' ? 'rgba(0,0,0,0.2)' : 'rgba(24, 12, 3, 0.36)';
    this.roundedRectPath(ctx, -half, -r, len, r * 2, r);
    ctx.fill();
    ctx.restore();

    // Draw distinct pen silhouette per class (with optional Custom visual style)
    const isCustom = pen.custom?.styleMode === 'custom';
    const customPalette = isCustom ? getCustomColorPreset(pen.custom.colorId) : null;
    const primary = customPalette ? customPalette.primary : colors.primary;
    const secondary = customPalette ? customPalette.secondary : colors.secondary;
    const dark = customPalette ? customPalette.dark : colors.dark;

    if (pen.spec.id === 'ballpoint') {
      this.drawBallpointPen(ctx, half, r, primary, secondary, dark, isCustom ? pen.custom : null, colors.primary);
    } else if (pen.spec.id === 'fountain') {
      this.drawFountainPen(ctx, half, r, primary, dark, isCustom ? pen.custom : null, colors.primary);
    } else if (pen.spec.id === 'gel') {
      this.drawGelPen(ctx, half, r, primary, secondary, isCustom ? pen.custom : null, colors.primary);
    } else if (pen.spec.id === 'mechanical') {
      this.drawMechanicalPencil(ctx, half, r, primary, secondary, dark, isCustom ? pen.custom : null, colors.primary);
    } else if (pen.spec.id === 'rollerball') {
      this.drawRollerballPen(ctx, half, r, primary, secondary, dark, isCustom ? pen.custom : null, colors.primary);
    } else {
      this.drawMarkerPen(ctx, half, r, primary, dark, isCustom ? pen.custom : null, colors.primary);
    }

    // Hit flash highlight
    if (pen.hitFlash > 0) {
      ctx.save();
      ctx.globalAlpha = pen.hitFlash * 0.55;
      ctx.fillStyle = '#FFFFFF';
      this.roundedRectPath(ctx, -half, -r, len, r * 2, r);
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  private drawCustomSurfaceOverlay(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radius: number,
    custom: PenCustomization,
    secondaryColor: string
  ): void {
    ctx.save();
    this.roundedRectPath(ctx, x, y, w, h, radius);
    ctx.clip();

    // 1. Pattern
    if (custom.pattern === 'stripes') {
      ctx.fillStyle = secondaryColor;
      ctx.globalAlpha = 0.42;
      for (let sx = x - h; sx < x + w + h; sx += 14) {
        ctx.beginPath();
        ctx.moveTo(sx, y + h);
        ctx.lineTo(sx + 6, y + h);
        ctx.lineTo(sx + 6 + h, y);
        ctx.lineTo(sx + h, y);
        ctx.closePath();
        ctx.fill();
      }
    } else if (custom.pattern === 'chevron') {
      ctx.strokeStyle = secondaryColor;
      ctx.lineWidth = 2.6;
      ctx.globalAlpha = 0.55;
      const midY = y + h * 0.5;
      for (let cx = x + 6; cx < x + w - 4; cx += 13) {
        ctx.beginPath();
        ctx.moveTo(cx - 5, y + 1.5);
        ctx.lineTo(cx + 3, midY);
        ctx.lineTo(cx - 5, y + h - 1.5);
        ctx.stroke();
      }
    } else if (custom.pattern === 'checkered') {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.34)';
      ctx.globalAlpha = 1;
      const cell = Math.max(5, h * 0.5);
      let col = 0;
      for (let cx = x; cx < x + w; cx += cell) {
        for (let row = 0; row < 2; row++) {
          if ((col + row) % 2 === 0) {
            ctx.fillRect(cx, y + row * cell, cell, cell);
          }
        }
        col++;
      }
    } else if (custom.pattern === 'dots') {
      ctx.fillStyle = secondaryColor;
      ctx.globalAlpha = 0.52;
      for (let cx = x + 8; cx < x + w - 4; cx += 11) {
        ctx.beginPath();
        ctx.arc(cx, y + h * 0.3, 1.8, 0, Math.PI * 2);
        ctx.arc(cx + 5.5, y + h * 0.7, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (custom.pattern === 'waves') {
      ctx.strokeStyle = secondaryColor;
      ctx.lineWidth = 2.1;
      ctx.globalAlpha = 0.56;
      for (const rowFrac of [0.32, 0.68]) {
        ctx.beginPath();
        const cy = y + h * rowFrac;
        for (let wx = x; wx <= x + w; wx += 4) {
          const wy = cy + Math.sin((wx - x) * 0.24) * (h * 0.14);
          if (wx === x) ctx.moveTo(wx, wy);
          else ctx.lineTo(wx, wy);
        }
        ctx.stroke();
      }
    } else if (custom.pattern === 'rings') {
      ctx.fillStyle = secondaryColor;
      ctx.globalAlpha = 0.55;
      for (let rx = x + 10; rx < x + w - 8; rx += 18) {
        ctx.fillRect(rx, y, 4.5, h);
      }
    } else if (custom.pattern === 'lightning') {
      ctx.strokeStyle = secondaryColor;
      ctx.lineWidth = 2.2;
      ctx.globalAlpha = 0.65;
      ctx.beginPath();
      const step = 10;
      let toggle = false;
      for (let lx = x + 2; lx <= x + w; lx += step) {
        const ly = toggle ? y + h * 0.22 : y + h * 0.78;
        if (lx === x + 2) ctx.moveTo(lx, ly);
        else ctx.lineTo(lx, ly);
        toggle = !toggle;
      }
      ctx.stroke();
    } else if (custom.pattern === 'camo') {
      ctx.globalAlpha = 0.45;
      let idx = 0;
      for (let cx = x + 6; cx < x + w; cx += 16) {
        ctx.fillStyle = idx % 2 === 0 ? secondaryColor : 'rgba(15, 23, 42, 0.45)';
        ctx.beginPath();
        ctx.ellipse(
          cx,
          y + (idx % 2 === 0 ? h * 0.34 : h * 0.66),
          7.5,
          h * 0.28,
          idx % 2 === 0 ? 0.3 : -0.3,
          0,
          Math.PI * 2
        );
        ctx.fill();
        idx++;
      }
    }

    // 2. Texture
    if (custom.texture === 'brushed') {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.24)';
      ctx.lineWidth = 0.8;
      ctx.globalAlpha = 1;
      for (let ty = y + 2; ty < y + h - 1; ty += 3) {
        ctx.beginPath();
        ctx.moveTo(x, ty);
        ctx.lineTo(x + w, ty);
        ctx.stroke();
      }
    } else if (custom.texture === 'metallic') {
      const metalGrad = ctx.createLinearGradient(0, y, 0, y + h);
      metalGrad.addColorStop(0, 'rgba(255,255,255,0.45)');
      metalGrad.addColorStop(0.32, 'rgba(255,255,255,0.1)');
      metalGrad.addColorStop(0.55, 'rgba(15,23,42,0.22)');
      metalGrad.addColorStop(0.8, 'rgba(255,255,255,0.28)');
      metalGrad.addColorStop(1, 'rgba(15,23,42,0.3)');
      ctx.fillStyle = metalGrad;
      ctx.globalAlpha = 1;
      ctx.fillRect(x, y, w, h);
    } else if (custom.texture === 'matte') {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.14)';
      ctx.globalAlpha = 1;
      ctx.fillRect(x, y, w, h);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
      for (let sx = x + 3; sx < x + w - 2; sx += 5) {
        ctx.fillRect(sx, y + (sx % 2 === 0 ? h * 0.28 : h * 0.62), 1.3, 1.3);
      }
    } else if (custom.texture === 'carbon') {
      ctx.strokeStyle = 'rgba(15, 23, 42, 0.35)';
      ctx.lineWidth = 1.2;
      ctx.globalAlpha = 1;
      for (let cx = x - h; cx < x + w + h; cx += 7) {
        ctx.beginPath();
        ctx.moveTo(cx, y);
        ctx.lineTo(cx + h, y + h);
        ctx.moveTo(cx + h, y);
        ctx.lineTo(cx, y + h);
        ctx.stroke();
      }
    } else if (custom.texture === 'woodgrain') {
      ctx.strokeStyle = 'rgba(69, 34, 8, 0.34)';
      ctx.lineWidth = 1.1;
      ctx.globalAlpha = 1;
      for (let ty = y + 3; ty < y + h - 2; ty += 4.5) {
        ctx.beginPath();
        ctx.moveTo(x, ty);
        ctx.bezierCurveTo(
          x + w * 0.33,
          ty + 1.8,
          x + w * 0.66,
          ty - 1.8,
          x + w,
          ty
        );
        ctx.stroke();
      }
    } else {
      // Smooth glossy highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.32)';
      ctx.globalAlpha = 1;
      ctx.fillRect(x + 2, y + h * 0.16, w - 4, h * 0.22);
    }

    ctx.restore();
  }

  private drawBallpointPen(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    secondary: string,
    dark: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;
    // Conical tip (+X)
    ctx.beginPath();
    ctx.moveTo(half - 24, -r * 0.85);
    ctx.lineTo(half, 0);
    ctx.lineTo(half - 24, r * 0.85);
    ctx.closePath();
    ctx.fillStyle = custom ? '#E2E8F0' : '#E5C158';
    ctx.fill();
    ctx.strokeStyle = custom ? '#475569' : '#6B4E16';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // Ink ball nib tip
    ctx.beginPath();
    ctx.arc(half - 2, 0, 2.3, 0, Math.PI * 2);
    ctx.fillStyle = playerRingColor;
    ctx.fill();

    // Barrel
    this.roundedRectPath(ctx, -half + 26, -r * 0.85, len - 50, r * 1.7, 3);
    ctx.fillStyle = custom ? primary : '#F4F6F9';
    ctx.fill();
    ctx.strokeStyle = custom ? dark : '#475569';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    if (custom) {
      this.drawCustomSurfaceOverlay(
        ctx,
        -half + 26,
        -r * 0.85,
        len - 50,
        r * 1.7,
        3,
        custom,
        secondary
      );
      // Player owner collar ring
      ctx.fillStyle = playerRingColor;
      ctx.fillRect(half - 28, -r * 0.88, 4, r * 1.76);
    } else {
      // Visible inner ink cartridge tube
      ctx.fillStyle = primary;
      ctx.fillRect(-half + 32, -r * 0.26, len - 60, r * 0.52);

      // Barrel highlight stripe
      ctx.fillStyle = 'rgba(255,255,255,0.65)';
      ctx.fillRect(-half + 30, -r * 0.65, len - 58, r * 0.22);
    }

    // Cap at tail (-X)
    this.roundedRectPath(ctx, -half, -r * 0.95, 36, r * 1.9, 5);
    ctx.fillStyle = primary;
    ctx.fill();
    ctx.strokeStyle = dark;
    ctx.lineWidth = 1.4;
    ctx.stroke();

    // Pocket clip on cap
    this.roundedRectPath(ctx, -half + 6, -r - 2.5, 28, 4.5, 2);
    ctx.fillStyle = custom ? '#F8FAFC' : secondary;
    ctx.fill();
    ctx.strokeStyle = dark;
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  private drawFountainPen(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    dark: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;
    const customPalette = custom ? getCustomColorPreset(custom.colorId) : null;

    // Ornate fountain nib (+X)
    ctx.beginPath();
    ctx.moveTo(half - 28, -r * 0.65);
    ctx.quadraticCurveTo(half - 10, -r * 0.85, half + 2, 0);
    ctx.quadraticCurveTo(half - 10, r * 0.85, half - 28, r * 0.65);
    ctx.closePath();
    ctx.fillStyle = custom ? '#E2E8F0' : '#E8C563';
    ctx.fill();
    ctx.strokeStyle = custom ? '#475569' : '#6E4F12';
    ctx.lineWidth = 1.3;
    ctx.stroke();

    // Nib slit + breather hole
    ctx.beginPath();
    ctx.moveTo(half - 14, 0);
    ctx.lineTo(half + 1, 0);
    ctx.strokeStyle = '#4A330A';
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(half - 15, 0, 2, 0, Math.PI * 2);
    ctx.fillStyle = playerRingColor;
    ctx.fill();

    // Body
    this.roundedRectPath(ctx, -half, -r, len - 24, r * 2, r * 0.85);
    if (custom) {
      ctx.fillStyle = primary;
      ctx.fill();
      ctx.strokeStyle = dark;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      this.drawCustomSurfaceOverlay(
        ctx,
        -half,
        -r,
        len - 24,
        r * 2,
        r * 0.85,
        custom,
        customPalette?.secondary ?? '#FDE68A'
      );
    } else {
      const bodyGrad = ctx.createLinearGradient(0, -r, 0, r);
      bodyGrad.addColorStop(0, '#D4A84B');
      bodyGrad.addColorStop(0.28, '#F4DB8E');
      bodyGrad.addColorStop(0.55, primary);
      bodyGrad.addColorStop(1, dark);
      ctx.fillStyle = bodyGrad;
      ctx.fill();
      ctx.strokeStyle = '#3F2D0A';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // Twin center trim rings
    ctx.fillStyle = custom ? '#F8FAFC' : '#F6DF93';
    ctx.fillRect(-10, -r, 4, r * 2);
    ctx.fillRect(-2, -r, 4, r * 2);
    if (custom) {
      ctx.fillStyle = playerRingColor;
      ctx.fillRect(half - 30, -r, 4, r * 2);
    }

    // Pocket clip at tail
    this.roundedRectPath(ctx, -half + 10, -r - 2, 34, 4.5, 2);
    ctx.fillStyle = custom ? '#F8FAFC' : '#F3D478';
    ctx.fill();
    ctx.strokeStyle = '#5E420D';
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  private drawGelPen(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    secondary: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;
    // Needle tip + chrome nose cone
    ctx.beginPath();
    ctx.moveTo(half - 20, -r * 0.78);
    ctx.lineTo(half - 4, -2);
    ctx.lineTo(half + 1, 0);
    ctx.lineTo(half - 4, 2);
    ctx.lineTo(half - 20, r * 0.78);
    ctx.closePath();
    ctx.fillStyle = '#CBD5E1';
    ctx.fill();
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // Barrel
    this.roundedRectPath(ctx, -half, -r * 0.9, len - 18, r * 1.8, 5);
    ctx.fillStyle = custom ? primary : '#1E293B';
    ctx.fill();
    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 1.4;
    ctx.stroke();

    if (custom) {
      this.drawCustomSurfaceOverlay(
        ctx,
        -half,
        -r * 0.9,
        len - 18,
        r * 1.8,
        5,
        custom,
        secondary
      );
      ctx.fillStyle = playerRingColor;
      ctx.fillRect(half - 23, -r * 0.9, 4, r * 1.8);
    } else {
      // Bright ink window stripe along barrel
      ctx.fillStyle = primary;
      ctx.fillRect(-half + 14, -r * 0.35, len - 66, r * 0.7);
      ctx.fillStyle = secondary;
      ctx.fillRect(-half + 14, -r * 0.35, len - 66, r * 0.22);
    }

    // Ergonomic rubberized grip sleeve near front
    ctx.fillStyle = custom ? '#0F172A' : primary;
    ctx.fillRect(half - 48, -r * 0.98, 26, r * 1.96);
    ctx.strokeStyle = 'rgba(255,255,255,0.28)';
    ctx.lineWidth = 1.1;
    for (let x = half - 44; x <= half - 26; x += 5) {
      ctx.beginPath();
      ctx.moveTo(x, -r * 0.85);
      ctx.lineTo(x, r * 0.85);
      ctx.stroke();
    }

    // Clicker plunger at tail
    ctx.fillStyle = playerRingColor;
    this.roundedRectPath(ctx, -half - 4, -r * 0.45, 8, r * 0.9, 2);
    ctx.fill();
  }

  private drawMarkerPen(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    dark: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;
    const customPalette = custom ? getCustomColorPreset(custom.colorId) : null;

    // Broad chisel felt tip (+X)
    ctx.beginPath();
    ctx.moveTo(half - 18, -r * 0.48);
    ctx.lineTo(half, -r * 0.28);
    ctx.lineTo(half, r * 0.45);
    ctx.lineTo(half - 18, r * 0.48);
    ctx.closePath();
    ctx.fillStyle = primary;
    ctx.fill();
    ctx.strokeStyle = dark;
    ctx.lineWidth = 1.3;
    ctx.stroke();

    // Stepped collar (shows player color ring in custom mode)
    ctx.fillStyle = custom ? playerRingColor : '#334155';
    ctx.fillRect(half - 28, -r * 0.75, 12, r * 1.5);

    // Wide marker barrel
    this.roundedRectPath(ctx, -half, -r, len - 26, r * 2, 7);
    ctx.fillStyle = custom ? primary : '#F8FAFC';
    ctx.fill();
    ctx.strokeStyle = custom ? dark : '#334155';
    ctx.lineWidth = 1.6;
    ctx.stroke();

    if (custom) {
      this.drawCustomSurfaceOverlay(
        ctx,
        -half,
        -r,
        len - 26,
        r * 2,
        7,
        custom,
        customPalette?.secondary ?? '#FFFFFF'
      );
    } else {
      // Bold color band & label stripe
      ctx.fillStyle = primary;
      ctx.fillRect(-half + 18, -r + 2, len - 68, r * 0.7);
      ctx.fillRect(-half, -r + 1, 16, r * 1.9);

      // Specular shine
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fillRect(-half + 20, -r * 0.15, len - 72, r * 0.25);
    }
  }

  private drawMechanicalPencil(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    secondary: string,
    dark: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;

    // Stepped chrome drafting nose cone (+X)
    ctx.beginPath();
    ctx.moveTo(half - 24, -r * 0.85);
    ctx.lineTo(half - 9, -r * 0.36);
    ctx.lineTo(half - 9, r * 0.36);
    ctx.lineTo(half - 24, r * 0.85);
    ctx.closePath();
    ctx.fillStyle = '#E2E8F0';
    ctx.fill();
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // Precision lead sleeve & graphite tip
    ctx.fillStyle = '#94A3B8';
    ctx.fillRect(half - 9, -1.6, 7, 3.2);
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(half - 2, -0.8, 3, 1.6);

    // Hexagonal drafting barrel
    this.roundedRectPath(ctx, -half + 16, -r * 0.86, len - 40, r * 1.72, 2);
    ctx.fillStyle = primary;
    ctx.fill();
    ctx.strokeStyle = dark;
    ctx.lineWidth = 1.3;
    ctx.stroke();

    if (custom) {
      this.drawCustomSurfaceOverlay(
        ctx,
        -half + 16,
        -r * 0.86,
        len - 40,
        r * 1.72,
        2,
        custom,
        secondary
      );
    } else {
      ctx.fillStyle = 'rgba(255,255,255,0.34)';
      ctx.fillRect(-half + 18, -r * 0.36, len - 44, r * 0.28);
      ctx.fillStyle = 'rgba(0,0,0,0.16)';
      ctx.fillRect(-half + 18, r * 0.24, len - 44, r * 0.24);
    }

    // Knurled metallic grip sleeve near front
    ctx.fillStyle = '#CBD5E1';
    ctx.fillRect(half - 50, -r * 0.94, 26, r * 1.88);
    ctx.strokeStyle = '#64748B';
    ctx.lineWidth = 0.9;
    for (let x = half - 47; x <= half - 26; x += 3.5) {
      ctx.beginPath();
      ctx.moveTo(x, -r * 0.9);
      ctx.lineTo(x + 2, r * 0.9);
      ctx.moveTo(x + 2, -r * 0.9);
      ctx.lineTo(x, r * 0.9);
      ctx.stroke();
    }

    // Player color collar band
    ctx.fillStyle = playerRingColor;
    ctx.fillRect(half - 25, -r * 0.94, 3.5, r * 1.88);

    // Pink rubber eraser + brass ferrule at tail (-X)
    this.roundedRectPath(ctx, -half, -r * 0.78, 10, r * 1.56, 3);
    ctx.fillStyle = '#F472B6';
    ctx.fill();
    ctx.strokeStyle = '#9D174D';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    ctx.fillStyle = '#E5C158';
    ctx.fillRect(-half + 9, -r * 0.86, 8, r * 1.72);
    ctx.strokeStyle = '#78350F';
    ctx.lineWidth = 1;
    ctx.strokeRect(-half + 9, -r * 0.86, 8, r * 1.72);

    // Slim metal pocket clip
    this.roundedRectPath(ctx, -half + 18, -r - 2, 26, 3.5, 1.5);
    ctx.fillStyle = '#E2E8F0';
    ctx.fill();
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 0.9;
    ctx.stroke();
  }

  private drawRollerballPen(
    ctx: CanvasRenderingContext2D,
    half: number,
    r: number,
    primary: string,
    secondary: string,
    dark: string,
    custom: PenCustomization | null,
    playerRingColor: string
  ): void {
    const len = half * 2;

    // Tapered metallic rollerball front cone (+X)
    ctx.beginPath();
    ctx.moveTo(half - 26, -r * 0.82);
    ctx.quadraticCurveTo(half - 10, -r * 0.55, half, -1.5);
    ctx.lineTo(half, 1.5);
    ctx.quadraticCurveTo(half - 10, r * 0.55, half - 26, r * 0.82);
    ctx.closePath();
    ctx.fillStyle = '#E2E8F0';
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // Fine steel ball tip
    ctx.beginPath();
    ctx.arc(half - 1, 0, 2.2, 0, Math.PI * 2);
    ctx.fillStyle = playerRingColor;
    ctx.fill();

    // Sleek executive metal chassis
    this.roundedRectPath(ctx, -half + 6, -r * 0.92, len - 32, r * 1.84, r * 0.75);
    if (custom) {
      ctx.fillStyle = primary;
      ctx.fill();
      ctx.strokeStyle = dark;
      ctx.lineWidth = 1.4;
      ctx.stroke();
      this.drawCustomSurfaceOverlay(
        ctx,
        -half + 6,
        -r * 0.92,
        len - 32,
        r * 1.84,
        r * 0.75,
        custom,
        secondary
      );
    } else {
      const grad = ctx.createLinearGradient(0, -r, 0, r);
      grad.addColorStop(0, secondary);
      grad.addColorStop(0.35, primary);
      grad.addColorStop(1, dark);
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.strokeStyle = '#1E293B';
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }

    // Center satin grip & dual chrome bands
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(half - 52, -r * 0.92, 24, r * 1.84);
    ctx.fillStyle = '#F8FAFC';
    ctx.fillRect(-14, -r * 0.94, 3.5, r * 1.88);
    ctx.fillRect(half - 55, -r * 0.94, 3, r * 1.88);

    // Owner ring & silver tail finial
    ctx.fillStyle = playerRingColor;
    ctx.fillRect(half - 28, -r * 0.92, 3.5, r * 1.84);

    this.roundedRectPath(ctx, -half, -r * 0.72, 10, r * 1.44, 4);
    ctx.fillStyle = '#CBD5E1';
    ctx.fill();
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1.1;
    ctx.stroke();

    // Arched executive pocket clip
    this.roundedRectPath(ctx, -half + 12, -r - 2.2, 34, 4, 2);
    ctx.fillStyle = '#F8FAFC';
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  private drawSlingshot(
    ctx: CanvasRenderingContext2D,
    pen: PenBody,
    grabX: number,
    grabY: number,
    dragX: number,
    dragY: number,
    localOffset: number,
    power: number,
    cancelled: boolean,
    color: string
  ): void {
    const pullDx = dragX - grabX;
    const pullDy = dragY - grabY;
    const pullDist = Math.hypot(pullDx, pullDy);
    if (pullDist < 2) return;

    const dirX = -pullDx / pullDist;
    const dirY = -pullDy / pullDist;

    ctx.save();

    if (!cancelled) {
      // Forward dotted aim trajectory from pen's center of mass
      const previewLen = 90 + power * 230;
      ctx.save();
      ctx.strokeStyle = color;
      ctx.globalAlpha = 0.75;
      ctx.lineWidth = 2.5;
      ctx.setLineDash([7, 7]);
      ctx.beginPath();
      ctx.moveTo(pen.x, pen.y);
      ctx.lineTo(pen.x + dirX * previewLen, pen.y + dirY * previewLen);
      ctx.stroke();
      ctx.setLineDash([]);

      // Arrowhead at end of aim preview
      const ax = pen.x + dirX * previewLen;
      const ay = pen.y + dirY * previewLen;
      const aimAngle = Math.atan2(dirY, dirX);
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(ax - Math.cos(aimAngle - 0.45) * 11, ay - Math.sin(aimAngle - 0.45) * 11);
      ctx.lineTo(ax - Math.cos(aimAngle + 0.45) * 11, ay - Math.sin(aimAngle + 0.45) * 11);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
      ctx.restore();

      // Spin torque curved indicator if off-center grab
      const torque =
        Math.cos(pen.angle) * localOffset * dirY - Math.sin(pen.angle) * localOffset * dirX;
      if (Math.abs(torque) > 8 && power > 0.12) {
        const spinDir = Math.sign(torque);
        const arcR = 32;
        const startA = pen.angle;
        const sweep = spinDir * (0.65 + power * 1.15);
        ctx.save();
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 2.4;
        ctx.globalAlpha = 0.85;
        ctx.beginPath();
        ctx.arc(pen.x, pen.y, arcR, startA, startA + sweep, spinDir < 0);
        ctx.stroke();

        // Tiny spin arrow tip
        const endA = startA + sweep;
        const ex = pen.x + Math.cos(endA) * arcR;
        const ey = pen.y + Math.sin(endA) * arcR;
        const tangent = endA + spinDir * (Math.PI * 0.5);
        ctx.beginPath();
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex - Math.cos(tangent - 0.5) * 8, ey - Math.sin(tangent - 0.5) * 8);
        ctx.lineTo(ex - Math.cos(tangent + 0.5) * 8, ey - Math.sin(tangent + 0.5) * 8);
        ctx.closePath();
        ctx.fillStyle = '#F59E0B';
        ctx.fill();
        ctx.restore();
      }
    }

    // Clamp handle position visually to MAX_PULL_DISTANCE
    const clampedDist = Math.min(MAX_PULL_DISTANCE, pullDist);
    const hx = grabX + (pullDx / pullDist) * clampedDist;
    const hy = grabY + (pullDy / pullDist) * clampedDist;

    // Tension cord from grab anchor to pull handle
    ctx.strokeStyle = cancelled ? '#94A3B8' : '#FAF6EE';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(grabX, grabY);
    ctx.lineTo(hx, hy);
    ctx.stroke();

    // Grab anchor dot on pen
    ctx.beginPath();
    ctx.arc(grabX, grabY, 6, 0, Math.PI * 2);
    ctx.fillStyle = cancelled ? '#94A3B8' : color;
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Pull handle + percentage label
    ctx.beginPath();
    ctx.arc(hx, hy, 10, 0, Math.PI * 2);
    ctx.fillStyle = cancelled ? '#64748B' : color;
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    const label = cancelled ? 'CANCEL' : `${Math.round(power * 100)}%`;
    ctx.font = '700 12px "JetBrains Mono", monospace';
    const textW = ctx.measureText(label).width;
    const pillX = hx + 16;
    const pillY = hy - 12;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    this.roundedRectPath(ctx, pillX, pillY, textW + 14, 24, 6);
    ctx.fill();
    ctx.fillStyle = cancelled ? '#CBD5E1' : '#FAF6EE';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, pillX + 7, pillY + 12);

    ctx.restore();
  }
}

export const tabletopRenderer = new TabletopRenderer();
