export type MusicTrackId =
  | 'classroom'
  | 'lofi_desk'
  | 'arcade_duel'
  | 'jazz_hall'
  | 'zen_focus';

export interface MusicTrackOption {
  id: MusicTrackId;
  name: string;
  vibe: string;
}

export const MUSIC_TRACKS: MusicTrackOption[] = [
  { id: 'classroom', name: 'Afternoon Study', vibe: 'Warm Rhodes & marimba' },
  { id: 'lofi_desk', name: 'Late Night Desk', vibe: 'Mellow lo-fi keys' },
  { id: 'arcade_duel', name: 'Notebook Arcade', vibe: 'Upbeat chiptune pulse' },
  { id: 'jazz_hall', name: 'Recess Jazz', vibe: 'Swung bass & chords' },
  { id: 'zen_focus', name: 'Quiet Chalkboard', vibe: 'Gentle ambient bells' },
];

export interface AudioSettings {
  masterMuted: boolean;
  musicEnabled: boolean;
  musicVolume: number;
  musicTrack: MusicTrackId;
  sfxEnabled: boolean;
  sfxVolume: number;
}

const STORAGE_KEY = 'desk-duel-audio-settings';

const DEFAULT_SETTINGS: AudioSettings = {
  masterMuted: false,
  musicEnabled: true,
  musicVolume: 0.55,
  musicTrack: 'classroom',
  sfxEnabled: true,
  sfxVolume: 0.85,
};

interface TrackArrangement {
  stepDuration: number;
  filterFreq: number;
  padWave: OscillatorType;
  leadWave: OscillatorType;
  bassWave: OscillatorType;
  chords: Array<{ bass: number; notes: number[] }>;
  melody: number[];
  bassPattern: number[];
}

const TRACK_ARRANGEMENTS: Record<MusicTrackId, TrackArrangement> = {
  // 1. Warm nostalgic classroom progression (Cmaj9 -> Am9 -> Fmaj7 -> G6)
  classroom: {
    stepDuration: 0.34,
    filterFreq: 1050,
    padWave: 'triangle',
    leadWave: 'triangle',
    bassWave: 'sine',
    chords: [
      { bass: 130.81, notes: [261.63, 329.63, 392.0, 493.88, 587.33] },
      { bass: 110.0, notes: [220.0, 261.63, 329.63, 392.0, 493.88] },
      { bass: 87.31, notes: [174.61, 220.0, 261.63, 329.63, 440.0] },
      { bass: 98.0, notes: [196.0, 246.94, 293.66, 329.63, 392.0] },
    ],
    melody: [4, -1, 2, 3, -1, 1, 2, -1],
    bassPattern: [1, 0, 0, 0, 0, 0, 0, 0],
  },
  // 2. Late Night Desk (Dmaj9 -> Bm7 -> Gmaj7 -> A6)
  lofi_desk: {
    stepDuration: 0.39,
    filterFreq: 860,
    padWave: 'sine',
    leadWave: 'sine',
    bassWave: 'triangle',
    chords: [
      { bass: 146.83, notes: [293.66, 369.99, 440.0, 554.37, 659.25] },
      { bass: 123.47, notes: [246.94, 293.66, 369.99, 440.0, 587.33] },
      { bass: 98.0, notes: [196.0, 246.94, 293.66, 369.99, 493.88] },
      { bass: 110.0, notes: [220.0, 277.18, 329.63, 369.99, 440.0] },
    ],
    melody: [3, -1, 4, -1, 2, 1, -1, 0],
    bassPattern: [1, 0, 0, 1, 0, 0, 1, 0],
  },
  // 3. Notebook Arcade (Am -> F -> C -> G upbeat pulse)
  arcade_duel: {
    stepDuration: 0.21,
    filterFreq: 1750,
    padWave: 'triangle',
    leadWave: 'square',
    bassWave: 'triangle',
    chords: [
      { bass: 110.0, notes: [220.0, 261.63, 329.63, 440.0, 523.25] },
      { bass: 87.31, notes: [174.61, 220.0, 261.63, 349.23, 440.0] },
      { bass: 130.81, notes: [261.63, 329.63, 392.0, 523.25, 659.25] },
      { bass: 98.0, notes: [196.0, 246.94, 293.66, 392.0, 493.88] },
    ],
    melody: [0, 2, 4, 2, 3, 1, 4, 2],
    bassPattern: [1, 0, 1, 0, 1, 0, 1, 0],
  },
  // 4. Recess Jazz (Dm9 -> G13 -> Cmaj9 -> A7)
  jazz_hall: {
    stepDuration: 0.29,
    filterFreq: 1280,
    padWave: 'triangle',
    leadWave: 'sine',
    bassWave: 'triangle',
    chords: [
      { bass: 146.83, notes: [261.63, 329.63, 349.23, 440.0, 523.25] },
      { bass: 98.0, notes: [246.94, 329.63, 349.23, 440.0, 493.88] },
      { bass: 130.81, notes: [246.94, 293.66, 329.63, 392.0, 493.88] },
      { bass: 110.0, notes: [220.0, 277.18, 329.63, 392.0, 466.16] },
    ],
    melody: [1, -1, 3, 4, -1, 2, -1, 0],
    bassPattern: [1, 0, 1, 0, 1, 0, 1, 1],
  },
  // 5. Quiet Chalkboard (Fmaj9 -> Cmaj7 -> Dm9 -> Bbmaj7)
  zen_focus: {
    stepDuration: 0.44,
    filterFreq: 940,
    padWave: 'sine',
    leadWave: 'sine',
    bassWave: 'sine',
    chords: [
      { bass: 87.31, notes: [261.63, 329.63, 349.23, 392.0, 523.25] },
      { bass: 130.81, notes: [246.94, 261.63, 329.63, 392.0, 493.88] },
      { bass: 146.83, notes: [261.63, 329.63, 349.23, 440.0, 523.25] },
      { bass: 116.54, notes: [220.0, 293.66, 349.23, 440.0, 587.33] },
    ],
    melody: [4, -1, -1, 2, -1, 3, -1, 1],
    bassPattern: [1, 0, 0, 0, 0, 0, 0, 0],
  },
};

function isValidTrackId(value: unknown): value is MusicTrackId {
  return (
    typeof value === 'string' &&
    MUSIC_TRACKS.some((track) => track.id === value)
  );
}

class SoundEngine {
  private ctx: AudioContext | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicFilter: BiquadFilterNode | null = null;
  private settings: AudioSettings = { ...DEFAULT_SETTINGS };

  private schedulerTimer: number | null = null;
  private nextStepTime = 0;
  private stepIndex = 0;

  constructor() {
    this.loadSettings();
  }

  private loadSettings(): void {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<AudioSettings>;
        this.settings = {
          masterMuted: Boolean(parsed.masterMuted ?? DEFAULT_SETTINGS.masterMuted),
          musicEnabled: Boolean(parsed.musicEnabled ?? DEFAULT_SETTINGS.musicEnabled),
          musicVolume: this.clampVol(parsed.musicVolume ?? DEFAULT_SETTINGS.musicVolume),
          musicTrack: isValidTrackId(parsed.musicTrack)
            ? parsed.musicTrack
            : DEFAULT_SETTINGS.musicTrack,
          sfxEnabled: Boolean(parsed.sfxEnabled ?? DEFAULT_SETTINGS.sfxEnabled),
          sfxVolume: this.clampVol(parsed.sfxVolume ?? DEFAULT_SETTINGS.sfxVolume),
        };
      } else {
        const legacyMuted = localStorage.getItem('desk-duel-muted');
        if (legacyMuted === 'true') {
          this.settings.masterMuted = true;
        }
      }
    } catch {
      this.settings = { ...DEFAULT_SETTINGS };
    }
  }

  private saveSettings(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch {
      // Ignore storage failures
    }
  }

  private clampVol(val: number): number {
    if (!Number.isFinite(val)) return 0.5;
    return Math.max(0, Math.min(1, val));
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.connect(this.ctx.destination);

      this.musicFilter = this.ctx.createBiquadFilter();
      this.musicFilter.type = 'lowpass';
      this.musicFilter.frequency.value =
        TRACK_ARRANGEMENTS[this.settings.musicTrack].filterFreq;
      this.musicFilter.Q.value = 0.7;

      this.musicGain = this.ctx.createGain();
      this.musicFilter.connect(this.musicGain);
      this.musicGain.connect(this.ctx.destination);

      this.applyGains();
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    this.syncMusicLoop();
    return this.ctx;
  }

  private applyGains(): void {
    if (!this.ctx || !this.sfxGain || !this.musicGain) return;
    const now = this.ctx.currentTime;

    const effectiveSfx =
      this.settings.masterMuted || !this.settings.sfxEnabled ? 0 : this.settings.sfxVolume;
    const effectiveMusic =
      this.settings.masterMuted || !this.settings.musicEnabled
        ? 0
        : this.settings.musicVolume * 0.28;

    this.sfxGain.gain.setTargetAtTime(effectiveSfx, now, 0.02);
    this.musicGain.gain.setTargetAtTime(effectiveMusic, now, 0.08);
    if (this.musicFilter) {
      const targetFreq = TRACK_ARRANGEMENTS[this.settings.musicTrack].filterFreq;
      this.musicFilter.frequency.setTargetAtTime(targetFreq, now, 0.08);
    }
  }

  private isMusicActive(): boolean {
    return (
      !this.settings.masterMuted &&
      this.settings.musicEnabled &&
      this.settings.musicVolume > 0.005
    );
  }

  private isSfxActive(): boolean {
    return (
      !this.settings.masterMuted &&
      this.settings.sfxEnabled &&
      this.settings.sfxVolume > 0.005
    );
  }

  private syncMusicLoop(): void {
    if (!this.ctx || !this.musicFilter) return;

    if (!this.isMusicActive()) {
      if (this.schedulerTimer !== null) {
        window.clearInterval(this.schedulerTimer);
        this.schedulerTimer = null;
      }
      return;
    }

    if (this.schedulerTimer === null) {
      this.nextStepTime = this.ctx.currentTime + 0.08;
      this.schedulerTimer = window.setInterval(() => {
        this.scheduleMusicWindow();
      }, 100);
    }
  }

  private scheduleMusicWindow(): void {
    if (!this.ctx || !this.musicFilter || !this.isMusicActive()) return;
    if (this.ctx.state !== 'running') return;

    const arrangement = TRACK_ARRANGEMENTS[this.settings.musicTrack];
    const stepDuration = arrangement.stepDuration;
    const lookahead = 0.28;

    while (this.nextStepTime < this.ctx.currentTime + lookahead) {
      this.scheduleMusicStep(this.stepIndex, this.nextStepTime, arrangement);
      this.nextStepTime += stepDuration;
      this.stepIndex = (this.stepIndex + 1) % 32;
    }
  }

  private scheduleMusicStep(
    step: number,
    time: number,
    arrangement: TrackArrangement
  ): void {
    if (!this.ctx || !this.musicFilter) return;

    const bar = Math.floor(step / 8) % arrangement.chords.length;
    const beatInBar = step % 8;
    const chord = arrangement.chords[bar];

    // Warm chord pad on downbeat of each bar
    if (beatInBar === 0) {
      this.playMusicTone(chord.notes[0], time + 0.02, 2.2, 0.12, arrangement.padWave);
      this.playMusicTone(chord.notes[2], time + 0.04, 2.1, 0.1, arrangement.padWave);
      this.playMusicTone(chord.notes[3], time + 0.06, 1.9, 0.08, arrangement.padWave);
    }

    // Bass pulse pattern
    if (arrangement.bassPattern[beatInBar]) {
      const bassDur = beatInBar === 0 ? 1.4 : 0.32;
      const bassPeak = beatInBar === 0 ? 0.22 : 0.14;
      const freq = beatInBar === 6 ? chord.bass * 1.5 : chord.bass;
      this.playMusicTone(freq, time, bassDur, bassPeak, arrangement.bassWave);
    }

    // Melody / arpeggio motif
    const patternIdx = arrangement.melody[beatInBar];
    if (patternIdx >= 0) {
      const freq = chord.notes[patternIdx % chord.notes.length];
      const leadGain = arrangement.leadWave === 'square' ? 0.065 : 0.12;
      const leadDur = arrangement.leadWave === 'square' ? 0.22 : 0.55;
      this.playMusicTone(freq, time, leadDur, leadGain, arrangement.leadWave);
    }
  }

  private playMusicTone(
    freq: number,
    startTime: number,
    duration: number,
    peakGain: number,
    type: OscillatorType
  ): void {
    if (!this.ctx || !this.musicFilter) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peakGain, startTime + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.musicFilter);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  public unlock(): void {
    this.ensureContext();
  }

  public getSettings(): AudioSettings {
    return { ...this.settings };
  }

  public updateSettings(patch: Partial<AudioSettings>): AudioSettings {
    const trackChanged =
      patch.musicTrack !== undefined && patch.musicTrack !== this.settings.musicTrack;
    this.settings = {
      ...this.settings,
      ...patch,
      musicTrack: isValidTrackId(patch.musicTrack)
        ? patch.musicTrack
        : this.settings.musicTrack,
      musicVolume: this.clampVol(patch.musicVolume ?? this.settings.musicVolume),
      sfxVolume: this.clampVol(patch.sfxVolume ?? this.settings.sfxVolume),
    };
    if (trackChanged) {
      this.stepIndex = 0;
      if (this.ctx) {
        this.nextStepTime = this.ctx.currentTime + 0.05;
      }
    }
    this.saveSettings();
    this.ensureContext();
    this.applyGains();
    this.syncMusicLoop();
    return this.getSettings();
  }

  public isMuted(): boolean {
    return (
      this.settings.masterMuted ||
      (!this.settings.musicEnabled && !this.settings.sfxEnabled)
    );
  }

  public toggleMute(): boolean {
    if (this.isMuted()) {
      const nextPatch: Partial<AudioSettings> = { masterMuted: false };
      if (!this.settings.musicEnabled && !this.settings.sfxEnabled) {
        nextPatch.musicEnabled = true;
        nextPatch.sfxEnabled = true;
      }
      this.updateSettings(nextPatch);
    } else {
      this.updateSettings({ masterMuted: true });
    }
    return this.isMuted();
  }

  public playSfxPreview(): void {
    this.playPenHit(0.65);
  }

  public playFlick(powerRatio: number): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const clamped = Math.max(0.1, Math.min(1, powerRatio));

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(190 + clamped * 160, now);
    osc.frequency.exponentialRampToValueAtTime(85, now + 0.085);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.16 * clamped + 0.04, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.095);
  }

  public playPenHit(intensity: number): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const norm = Math.max(0.08, Math.min(1, intensity));

    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    osc1.type = 'triangle';
    osc2.type = 'sine';
    const baseFreq = 520 + norm * 280;
    osc1.frequency.setValueAtTime(baseFreq, now);
    osc1.frequency.exponentialRampToValueAtTime(190, now + 0.065);

    osc2.frequency.setValueAtTime(baseFreq * 1.47, now);
    osc2.frequency.exponentialRampToValueAtTime(280, now + 0.05);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.24 * norm + 0.03, now + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.075);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxGain);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.08);
    osc2.stop(now + 0.08);
  }

  public playObstacleHit(kind: 'eraser' | 'sharpener' | 'ruler', intensity: number): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const norm = Math.max(0.08, Math.min(1, intensity));
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (kind === 'eraser') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(180 + norm * 90, now);
      osc.frequency.exponentialRampToValueAtTime(70, now + 0.09);
    } else if (kind === 'sharpener') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(840 + norm * 220, now);
      osc.frequency.exponentialRampToValueAtTime(360, now + 0.055);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(620 + norm * 180, now);
      osc.frequency.exponentialRampToValueAtTime(240, now + 0.065);
    }

    const peak = kind === 'sharpener' ? 0.11 * norm + 0.02 : 0.17 * norm + 0.02;
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(peak, now + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  public playEdgeDrop(): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(420, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.34);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.16, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  public playRoundWin(): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const notes = [523.25, 659.25, 783.99];
    notes.forEach((freq, idx) => {
      if (!this.sfxGain) return;
      const start = ctx.currentTime + idx * 0.075;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.13, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.24);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(start);
      osc.stop(start + 0.25);
    });
  }

  public playMatchWin(): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      if (!this.sfxGain) return;
      const start = ctx.currentTime + idx * 0.09;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(0.15, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.38);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(start);
      osc.stop(start + 0.4);
    });
  }

  public playFanGust(): void {
    if (!this.isSfxActive()) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    const now = ctx.currentTime;
    const duration = 0.7;
    const bufSize = Math.floor(ctx.sampleRate * duration);
    const buf = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < bufSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(260, now);
    filter.frequency.exponentialRampToValueAtTime(520, now + 0.35);
    filter.frequency.exponentialRampToValueAtTime(300, now + duration);
    filter.Q.value = 1.6;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.09, now + 0.16);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start(now);
    noise.stop(now + duration);
  }
}

export const gameAudio = new SoundEngine();
