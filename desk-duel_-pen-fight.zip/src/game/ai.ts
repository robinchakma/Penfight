import { MAX_PULL_DISTANCE } from './constants';
import { computeFlickVelocities, isCenterOffDesk, stepPhysics } from './physics';
import { AIDifficulty, PenBody, StationeryObstacle, VentilationFan } from './types';

export interface AIShotPlan {
  localOffset: number;
  pullDx: number;
  pullDy: number;
  grabX: number;
  grabY: number;
  dragX: number;
  dragY: number;
  power: number;
}

function clonePen(pen: PenBody): PenBody {
  return {
    ...pen,
    spec: { ...pen.spec },
  };
}

function cloneObstacles(obstacles: StationeryObstacle[]): StationeryObstacle[] {
  return obstacles.map((o) => ({ ...o }));
}

function edgeDangerDistance(x: number, y: number): number {
  const dx = Math.min(x - 110, 1090 - x);
  const dy = Math.min(y - 84, 636 - y);
  return Math.min(dx, dy);
}

/**
 * Evaluates candidate slingshot shots using fast forward rollouts of the real physics engine.
 */
export function computeAIShot(
  pens: PenBody[],
  obstacles: StationeryObstacle[],
  difficulty: AIDifficulty,
  fan: VentilationFan | null = null,
  fanTime = 0,
  aiPlayer: 1 | 2 = 2
): AIShotPlan {
  const targetPlayer: 1 | 2 = aiPlayer === 2 ? 1 : 2;
  const aiPen = pens.find((p) => p.player === aiPlayer && p.status === 'active');
  const opponentPen = pens.find((p) => p.player === targetPlayer && p.status === 'active');

  if (!aiPen || !opponentPen) {
    return {
      localOffset: 0,
      pullDx: aiPlayer === 2 ? 80 : -80,
      pullDy: 0,
      grabX: aiPen?.x ?? (aiPlayer === 2 ? 900 : 300),
      grabY: aiPen?.y ?? 360,
      dragX: (aiPen?.x ?? (aiPlayer === 2 ? 900 : 300)) + (aiPlayer === 2 ? 80 : -80),
      dragY: aiPen?.y ?? 360,
      power: 0.45,
    };
  }

  const halfSeg = Math.max(4, aiPen.spec.length * 0.5 - aiPen.spec.radius);
  const dxToTarget = opponentPen.x - aiPen.x;
  const dyToTarget = opponentPen.y - aiPen.y;
  const baseAngle = Math.atan2(dyToTarget, dxToTarget);

  // Build candidate shots around target direction, plus spin offsets & bank angles
  const angleOffsets =
    difficulty === 'easy'
      ? [-0.35, -0.18, 0, 0.18, 0.35]
      : difficulty === 'medium'
        ? [-0.42, -0.22, -0.1, 0, 0.1, 0.22, 0.42]
        : [-0.55, -0.32, -0.16, -0.06, 0, 0.06, 0.16, 0.32, 0.55];

  const grabOffsets =
    difficulty === 'easy'
      ? [0]
      : difficulty === 'medium'
        ? [-halfSeg * 0.5, 0, halfSeg * 0.5]
        : [-halfSeg * 0.72, -halfSeg * 0.35, 0, halfSeg * 0.35, halfSeg * 0.72];

  const powers =
    difficulty === 'easy'
      ? [0.65, 0.9]
      : difficulty === 'medium'
        ? [0.68, 0.88, 1.0]
        : [0.62, 0.82, 1.0];

  interface ScoredCandidate {
    score: number;
    localOffset: number;
    pullDx: number;
    pullDy: number;
    power: number;
  }

  const candidates: ScoredCandidate[] = [];

  for (const aOff of angleOffsets) {
    const aimAngle = baseAngle + aOff;
    for (const gOff of grabOffsets) {
      for (const pwr of powers) {
        const pullDist = pwr * MAX_PULL_DISTANCE;
        // Pull is opposite to aimAngle
        const pullDx = -Math.cos(aimAngle) * pullDist;
        const pullDy = -Math.sin(aimAngle) * pullDist;

        const simOpp = clonePen(opponentPen);
        const simAI = clonePen(aiPen);
        const simObs = cloneObstacles(obstacles);

        const vel = computeFlickVelocities(simAI, gOff, pullDx, pullDy);
        simAI.vx = vel.vx;
        simAI.vy = vel.vy;
        simAI.omega = vel.omega;

        let oppDropped = false;
        let aiDropped = false;
        let maxImpulse = 0;

        for (let step = 0; step < 84; step++) {
          const res = stepPhysics([simOpp, simAI], simObs, 1 / 60, fan, fanTime + step / 60);
          for (const col of res.collisions) {
            if (col.type === 'pen' && col.impulse > maxImpulse) {
              maxImpulse = col.impulse;
            }
          }
          if (res.droppedPlayers.includes(targetPlayer)) oppDropped = true;
          if (res.droppedPlayers.includes(aiPlayer)) aiDropped = true;
          if (res.settled) break;
        }

        if (isCenterOffDesk(simOpp)) oppDropped = true;
        if (isCenterOffDesk(simAI)) aiDropped = true;

        let score = 0;
        if (oppDropped && !aiDropped) {
          score += 5000;
        } else if (oppDropped && aiDropped) {
          score += 600;
        } else if (aiDropped) {
          score -= 4000;
        }

        // Reward pushing opponent pen closer to the edge
        const beforeEdgeDist = edgeDangerDistance(opponentPen.x, opponentPen.y);
        const afterEdgeDist = edgeDangerDistance(simOpp.x, simOpp.y);
        score += (beforeEdgeDist - afterEdgeDist) * 4.2;

        // Reward strong impact
        score += Math.min(800, maxImpulse) * 0.45;

        // Reward keeping AI pen safe from edges
        const aiEdgeDist = edgeDangerDistance(simAI.x, simAI.y);
        if (aiEdgeDist < 90) {
          score -= (90 - aiEdgeDist) * 3.5;
        }

        candidates.push({
          score,
          localOffset: gOff,
          pullDx,
          pullDy,
          power: pwr,
        });
      }
    }
  }

  candidates.sort((a, b) => b.score - a.score);

  // Pick candidate based on difficulty with subtle human-like variance
  const poolSize = difficulty === 'easy' ? 5 : difficulty === 'medium' ? 2 : 1;
  const chosenIndex = Math.floor(Math.random() * Math.min(poolSize, candidates.length));
  const best = candidates[chosenIndex] ?? candidates[0];

  const angleJitter =
    difficulty === 'easy'
      ? (Math.random() - 0.5) * 0.22
      : difficulty === 'medium'
        ? (Math.random() - 0.5) * 0.08
        : (Math.random() - 0.5) * 0.025;

  const powerJitter =
    difficulty === 'easy'
      ? 0.85 + Math.random() * 0.25
      : difficulty === 'medium'
        ? 0.94 + Math.random() * 0.12
        : 0.98 + Math.random() * 0.04;

  const cosJ = Math.cos(angleJitter);
  const sinJ = Math.sin(angleJitter);
  const rx = (best.pullDx * cosJ - best.pullDy * sinJ) * powerJitter;
  const ry = (best.pullDx * sinJ + best.pullDy * cosJ) * powerJitter;

  // Clamp pull vector to MAX_PULL_DISTANCE
  const mag = Math.hypot(rx, ry);
  const scale = mag > MAX_PULL_DISTANCE ? MAX_PULL_DISTANCE / mag : 1;
  const pullDx = rx * scale;
  const pullDy = ry * scale;

  const grabX = aiPen.x + Math.cos(aiPen.angle) * best.localOffset;
  const grabY = aiPen.y + Math.sin(aiPen.angle) * best.localOffset;

  return {
    localOffset: best.localOffset,
    pullDx,
    pullDy,
    grabX,
    grabY,
    dragX: grabX + pullDx,
    dragY: grabY + pullDy,
    power: Math.min(1, Math.hypot(pullDx, pullDy) / MAX_PULL_DISTANCE),
  };
}
