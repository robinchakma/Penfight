import {
  BASE_FLICK_IMPULSE,
  DEFAULT_P1_CUSTOM,
  DEFAULT_P2_CUSTOM,
  DESK_BOUNDS,
  FLICK_TORQUE_SCALE,
  getFanWindState,
  MAX_PULL_DISTANCE,
  PEN_CLASSES,
  STOP_ANGULAR_SPEED,
  STOP_LINEAR_SPEED,
} from './constants';
import {
  PenBody,
  PenClassId,
  PenCustomization,
  StationeryObstacle,
  VentilationFan,
} from './types';

export interface Vec2 {
  x: number;
  y: number;
}

export interface CollisionEvent {
  type: 'pen' | 'obstacle';
  x: number;
  y: number;
  impulse: number;
  obstacleKind?: StationeryObstacle['kind'];
  penPlayer?: 1 | 2;
}

export interface StepResult {
  collisions: CollisionEvent[];
  droppedPlayers: Array<1 | 2>;
  settled: boolean;
}

export function createPenBody(
  player: 1 | 2,
  penClassId: PenClassId,
  x: number,
  y: number,
  angle: number,
  custom?: PenCustomization
): PenBody {
  const spec = PEN_CLASSES[penClassId];
  const width = spec.radius * 2;
  const inertia = (1 / 12) * spec.mass * (spec.length * spec.length + width * width);
  const defaultCustom = player === 1 ? DEFAULT_P1_CUSTOM : DEFAULT_P2_CUSTOM;
  return {
    player,
    spec,
    custom: custom ? { ...custom } : { ...defaultCustom },
    x,
    y,
    angle,
    vx: 0,
    vy: 0,
    omega: 0,
    mass: spec.mass,
    inertia,
    status: 'active',
    fallProgress: 0,
    fallVx: 0,
    fallVy: 0,
    fallSpin: 0,
    hitFlash: 0,
  };
}

export function applyPenSpecAndCustom(
  pen: PenBody,
  penClassId: PenClassId,
  custom: PenCustomization
): void {
  const spec = PEN_CLASSES[penClassId];
  const width = spec.radius * 2;
  pen.spec = spec;
  pen.mass = spec.mass;
  pen.inertia = (1 / 12) * spec.mass * (spec.length * spec.length + width * width);
  pen.custom = { ...custom };
}

export function getPenSpineEndpoints(pen: PenBody): { a: Vec2; b: Vec2; halfSeg: number } {
  const halfSeg = Math.max(4, pen.spec.length * 0.5 - pen.spec.radius);
  const cos = Math.cos(pen.angle);
  const sin = Math.sin(pen.angle);
  return {
    a: { x: pen.x - cos * halfSeg, y: pen.y - sin * halfSeg },
    b: { x: pen.x + cos * halfSeg, y: pen.y + sin * halfSeg },
    halfSeg,
  };
}

/**
 * Closest projection of a point onto a pen's spine segment, returning world coordinates
 * and signed local offset along the pen axis (-halfSeg .. +halfSeg).
 */
export function projectPointOntoPen(
  pen: PenBody,
  px: number,
  py: number
): { worldX: number; worldY: number; localOffset: number; distance: number } {
  const halfSeg = Math.max(4, pen.spec.length * 0.5 - pen.spec.radius);
  const cos = Math.cos(pen.angle);
  const sin = Math.sin(pen.angle);
  const dx = px - pen.x;
  const dy = py - pen.y;
  const along = dx * cos + dy * sin;
  const clamped = Math.max(-halfSeg, Math.min(halfSeg, along));
  const worldX = pen.x + cos * clamped;
  const worldY = pen.y + sin * clamped;
  const dist = Math.hypot(px - worldX, py - worldY);
  return { worldX, worldY, localOffset: clamped, distance: dist };
}

/**
 * Computes initial linear and angular velocity from a slingshot pull.
 */
export function computeFlickVelocities(
  pen: PenBody,
  localOffset: number,
  pullDx: number,
  pullDy: number
): { vx: number; vy: number; omega: number; power: number } {
  // pullDx, pullDy = dragPos - grabPos. Launch is opposite to pull!
  const pullDist = Math.hypot(pullDx, pullDy);
  const clampedDist = Math.min(MAX_PULL_DISTANCE, pullDist);
  const power = clampedDist / MAX_PULL_DISTANCE;

  if (pullDist < 1e-4) {
    return { vx: 0, vy: 0, omega: 0, power: 0 };
  }

  const dirX = -pullDx / pullDist;
  const dirY = -pullDy / pullDist;

  // Apply curved power response for finer low-power nudges and explosive full-power flicks
  const shapedPower = Math.pow(power, 1.15);
  const impulseMag = shapedPower * BASE_FLICK_IMPULSE * pen.spec.powerScale;

  const jx = dirX * impulseMag;
  const jy = dirY * impulseMag;

  const vx = jx / pen.mass;
  const vy = jy / pen.mass;

  // Lever arm vector from center of mass to grab point
  const rx = Math.cos(pen.angle) * localOffset;
  const ry = Math.sin(pen.angle) * localOffset;

  // 2D cross product r x J
  const torqueImpulse = (rx * jy - ry * jx) * FLICK_TORQUE_SCALE;
  const omega = torqueImpulse / pen.inertia;

  return { vx, vy, omega, power };
}

function clamp(v: number, min: number, max: number): number {
  return v < min ? min : v > max ? max : v;
}

/**
 * Exact closest points between two 2D line segments P1-Q1 and P2-Q2.
 */
function closestPointsBetweenSegments(
  p1: Vec2,
  q1: Vec2,
  p2: Vec2,
  q2: Vec2
): { c1: Vec2; c2: Vec2 } {
  const d1x = q1.x - p1.x;
  const d1y = q1.y - p1.y;
  const d2x = q2.x - p2.x;
  const d2y = q2.y - p2.y;
  const rx = p1.x - p2.x;
  const ry = p1.y - p2.y;

  const a = d1x * d1x + d1y * d1y;
  const e = d2x * d2x + d2y * d2y;
  const f = d2x * rx + d2y * ry;

  let s = 0;
  let t = 0;

  if (a <= 1e-6 && e <= 1e-6) {
    return { c1: { ...p1 }, c2: { ...p2 } };
  }
  if (a <= 1e-6) {
    s = 0;
    t = clamp(f / e, 0, 1);
  } else {
    const c = d1x * rx + d1y * ry;
    if (e <= 1e-6) {
      t = 0;
      s = clamp(-c / a, 0, 1);
    } else {
      const b = d1x * d2x + d1y * d2y;
      const denom = a * e - b * b;

      if (denom !== 0) {
        s = clamp((b * f - c * e) / denom, 0, 1);
      } else {
        s = 0;
      }

      t = (b * s + f) / e;
      if (t < 0) {
        t = 0;
        s = clamp(-c / a, 0, 1);
      } else if (t > 1) {
        t = 1;
        s = clamp((b - c) / a, 0, 1);
      }
    }
  }

  return {
    c1: { x: p1.x + d1x * s, y: p1.y + d1y * s },
    c2: { x: p2.x + d2x * t, y: p2.y + d2y * t },
  };
}

/**
 * Closest point distance from segment A-B to an axis-aligned box [-hw..hw] x [-hh..hh].
 * Uses multi-sample + golden-section search along t in [0,1].
 */
function closestSegmentToLocalBox(
  ax: number,
  ay: number,
  bx: number,
  by: number,
  hw: number,
  hh: number
): { segPt: Vec2; boxPt: Vec2; distSq: number } {
  const evalT = (t: number) => {
    const sx = ax + (bx - ax) * t;
    const sy = ay + (by - ay) * t;
    const cx = clamp(sx, -hw, hw);
    const cy = clamp(sy, -hh, hh);
    const dx = sx - cx;
    const dy = sy - cy;
    return { sx, sy, cx, cy, d2: dx * dx + dy * dy };
  };

  // Sample 9 points evenly to bracket the global minimum
  let bestT = 0;
  let bestRes = evalT(0);
  const samples = 8;
  for (let i = 1; i <= samples; i++) {
    const t = i / samples;
    const res = evalT(t);
    if (res.d2 < bestRes.d2) {
      bestRes = res;
      bestT = t;
    }
  }

  // Refine within [t - 1/samples, t + 1/samples]
  let lo = Math.max(0, bestT - 1 / samples);
  let hi = Math.min(1, bestT + 1 / samples);
  const phi = 0.6180339887498949;
  for (let iter = 0; iter < 10; iter++) {
    const m1 = hi - (hi - lo) * phi;
    const m2 = lo + (hi - lo) * phi;
    const r1 = evalT(m1);
    const r2 = evalT(m2);
    if (r1.d2 < r2.d2) {
      hi = m2;
      if (r1.d2 < bestRes.d2) bestRes = r1;
    } else {
      lo = m1;
      if (r2.d2 < bestRes.d2) bestRes = r2;
    }
  }

  return {
    segPt: { x: bestRes.sx, y: bestRes.sy },
    boxPt: { x: bestRes.cx, y: bestRes.cy },
    distSq: bestRes.d2,
  };
}

function resolvePenVsPen(p1: PenBody, p2: PenBody): CollisionEvent | null {
  const s1 = getPenSpineEndpoints(p1);
  const s2 = getPenSpineEndpoints(p2);
  const { c1, c2 } = closestPointsBetweenSegments(s1.a, s1.b, s2.a, s2.b);

  let dx = c2.x - c1.x;
  let dy = c2.y - c1.y;
  let dist = Math.hypot(dx, dy);
  const minDist = p1.spec.radius + p2.spec.radius;

  if (dist >= minDist) return null;

  let nx: number;
  let ny: number;
  if (dist > 1e-5) {
    nx = dx / dist;
    ny = dy / dist;
  } else {
    // Fallback perpendicular to p1 spine pointing toward p2 center
    const perpX = -Math.sin(p1.angle);
    const perpY = Math.cos(p1.angle);
    const sign = (p2.x - p1.x) * perpX + (p2.y - p1.y) * perpY >= 0 ? 1 : -1;
    nx = perpX * sign;
    ny = perpY * sign;
    dist = 0;
  }

  const penetration = minDist - dist;
  const invMass1 = 1 / p1.mass;
  const invMass2 = 1 / p2.mass;
  const invMassSum = invMass1 + invMass2;

  // Positional separation
  const corr = Math.max(0, penetration - 0.15) * 0.85;
  p1.x -= nx * corr * (invMass1 / invMassSum);
  p1.y -= ny * corr * (invMass1 / invMassSum);
  p2.x += nx * corr * (invMass2 / invMassSum);
  p2.y += ny * corr * (invMass2 / invMassSum);

  const contactX = (c1.x + c2.x) * 0.5;
  const contactY = (c1.y + c2.y) * 0.5;

  const r1x = contactX - p1.x;
  const r1y = contactY - p1.y;
  const r2x = contactX - p2.x;
  const r2y = contactY - p2.y;

  // Point velocities: v + omega x r = (vx - omega*ry, vy + omega*rx)
  const v1x = p1.vx - p1.omega * r1y;
  const v1y = p1.vy + p1.omega * r1x;
  const v2x = p2.vx - p2.omega * r2y;
  const v2y = p2.vy + p2.omega * r2x;

  const relVx = v2x - v1x;
  const relVy = v2y - v1y;
  const velAlongNormal = relVx * nx + relVy * ny;

  if (velAlongNormal > 0) {
    return null;
  }

  const e = Math.min(p1.spec.restitution, p2.spec.restitution);
  const r1CrossN = r1x * ny - r1y * nx;
  const r2CrossN = r2x * ny - r2y * nx;

  const denom =
    invMassSum +
    (r1CrossN * r1CrossN) / p1.inertia +
    (r2CrossN * r2CrossN) / p2.inertia;

  const j = (-(1 + e) * velAlongNormal) / denom;
  const impulseX = j * nx;
  const impulseY = j * ny;

  p1.vx -= impulseX * invMass1;
  p1.vy -= impulseY * invMass1;
  p1.omega -= (r1x * impulseY - r1y * impulseX) / p1.inertia;

  p2.vx += impulseX * invMass2;
  p2.vy += impulseY * invMass2;
  p2.omega += (r2x * impulseY - r2y * impulseX) / p2.inertia;

  // Tangential Coulomb friction for spin transfer on glancing blows
  const tx = -ny;
  const ty = nx;
  const relVt = relVx * tx + relVy * ty;
  const r1CrossT = r1x * ty - r1y * tx;
  const r2CrossT = r2x * ty - r2y * tx;
  const denomT =
    invMassSum +
    (r1CrossT * r1CrossT) / p1.inertia +
    (r2CrossT * r2CrossT) / p2.inertia;

  let jt = -relVt / denomT;
  const mu = 0.24;
  jt = clamp(jt, -j * mu, j * mu);

  const fx = jt * tx;
  const fy = jt * ty;
  p1.vx -= fx * invMass1;
  p1.vy -= fy * invMass1;
  p1.omega -= (r1x * fy - r1y * fx) / p1.inertia;

  p2.vx += fx * invMass2;
  p2.vy += fy * invMass2;
  p2.omega += (r2x * fy - r2y * fx) / p2.inertia;

  p1.hitFlash = 1;
  p2.hitFlash = 1;

  return {
    type: 'pen',
    x: contactX,
    y: contactY,
    impulse: j,
  };
}

function resolvePenVsObstacle(pen: PenBody, obs: StationeryObstacle): CollisionEvent | null {
  const { a, b } = getPenSpineEndpoints(pen);

  // Transform segment endpoints into obstacle's local frame
  const cos = Math.cos(-obs.angle);
  const sin = Math.sin(-obs.angle);
  const toLocal = (wx: number, wy: number): Vec2 => {
    const dx = wx - obs.x;
    const dy = wy - obs.y;
    return {
      x: dx * cos - dy * sin,
      y: dx * sin + dy * cos,
    };
  };

  const la = toLocal(a.x, a.y);
  const lb = toLocal(b.x, b.y);
  const hw = Math.max(2, obs.halfW - obs.cornerRadius);
  const hh = Math.max(2, obs.halfH - obs.cornerRadius);

  const { segPt, boxPt, distSq } = closestSegmentToLocalBox(la.x, la.y, lb.x, lb.y, hw, hh);
  const effectiveRadius = pen.spec.radius + obs.cornerRadius;

  if (distSq >= effectiveRadius * effectiveRadius) {
    return null;
  }

  let lnx: number;
  let lny: number;
  let dist = Math.sqrt(distSq);

  if (dist > 1e-5) {
    // Normal pointing from obstacle to pen
    lnx = (segPt.x - boxPt.x) / dist;
    lny = (segPt.y - boxPt.y) / dist;
  } else {
    // Spine inside core box: push out along nearest face
    const dxLeft = Math.abs(segPt.x + hw);
    const dxRight = Math.abs(hw - segPt.x);
    const dyTop = Math.abs(segPt.y + hh);
    const dyBottom = Math.abs(hh - segPt.y);
    const minFace = Math.min(dxLeft, dxRight, dyTop, dyBottom);
    if (minFace === dxLeft) {
      lnx = -1;
      lny = 0;
    } else if (minFace === dxRight) {
      lnx = 1;
      lny = 0;
    } else if (minFace === dyTop) {
      lnx = 0;
      lny = -1;
    } else {
      lnx = 0;
      lny = 1;
    }
    dist = 0;
  }

  // Transform normal and contact back to world space
  const wCos = Math.cos(obs.angle);
  const wSin = Math.sin(obs.angle);
  const nx = lnx * wCos - lny * wSin;
  const ny = lnx * wSin + lny * wCos;

  const penetration = effectiveRadius - dist;
  pen.x += nx * penetration;
  pen.y += ny * penetration;

  const worldSegX = obs.x + (segPt.x * wCos - segPt.y * wSin);
  const worldSegY = obs.y + (segPt.x * wSin + segPt.y * wCos);
  const contactX = worldSegX - nx * pen.spec.radius;
  const contactY = worldSegY - ny * pen.spec.radius;

  const rx = contactX - pen.x;
  const ry = contactY - pen.y;

  const vxAtContact = pen.vx - pen.omega * ry;
  const vyAtContact = pen.vy + pen.omega * rx;
  const velAlongNormal = vxAtContact * nx + vyAtContact * ny;

  if (velAlongNormal >= 0) {
    return null;
  }

  const e = Math.min(pen.spec.restitution, obs.restitution);
  const rCrossN = rx * ny - ry * nx;
  const invMass = 1 / pen.mass;
  const denom = invMass + (rCrossN * rCrossN) / pen.inertia;

  const j = (-(1 + e) * velAlongNormal) / denom;
  const impulseX = j * nx;
  const impulseY = j * ny;

  pen.vx += impulseX * invMass;
  pen.vy += impulseY * invMass;
  pen.omega += (rx * impulseY - ry * impulseX) / pen.inertia;

  // Tangential friction against obstacle
  const tx = -ny;
  const ty = nx;
  const vt = vxAtContact * tx + vyAtContact * ty;
  const rCrossT = rx * ty - ry * tx;
  const denomT = invMass + (rCrossT * rCrossT) / pen.inertia;
  const mu = obs.kind === 'eraser' ? 0.35 : 0.16;
  const jt = clamp(-vt / denomT, -j * mu, j * mu);

  pen.vx += jt * tx * invMass;
  pen.vy += jt * ty * invMass;
  pen.omega += (rx * (jt * ty) - ry * (jt * tx)) / pen.inertia;

  pen.hitFlash = Math.max(pen.hitFlash, 0.7);
  obs.hitFlash = 1;

  return {
    type: 'obstacle',
    x: contactX,
    y: contactY,
    impulse: j,
    obstacleKind: obs.kind,
    penPlayer: pen.player,
  };
}

export function isCenterOffDesk(pen: PenBody): boolean {
  const margin = 4;
  return (
    pen.x < DESK_BOUNDS.left - margin ||
    pen.x > DESK_BOUNDS.right + margin ||
    pen.y < DESK_BOUNDS.top - margin ||
    pen.y > DESK_BOUNDS.bottom + margin
  );
}

function applyFanWindToPen(
  pen: PenBody,
  fan: VentilationFan,
  windFactor: number,
  dt: number
): void {
  if (windFactor <= 0.16) return;
  const cosF = Math.cos(fan.angle);
  const sinF = Math.sin(fan.angle);
  const halfSeg = Math.max(4, pen.spec.length * 0.5 - pen.spec.radius);
  const cosP = Math.cos(pen.angle);
  const sinP = Math.sin(pen.angle);

  for (const offsetRatio of [-0.55, 0.55]) {
    const rx = cosP * (halfSeg * offsetRatio);
    const ry = sinP * (halfSeg * offsetRatio);
    const sx = pen.x + rx;
    const sy = pen.y + ry;

    const dx = sx - fan.x;
    const dy = sy - fan.y;
    const along = dx * cosF + dy * sinF;
    const perp = -dx * sinF + dy * cosF;

    if (along >= 0 && along <= fan.range && Math.abs(perp) <= fan.halfWidth) {
      const longFalloff = 1 - 0.52 * (along / fan.range);
      const latFalloff = Math.cos((perp / fan.halfWidth) * Math.PI * 0.5);
      const forceMag = fan.strength * windFactor * longFalloff * latFalloff * 0.5;
      const fx = cosF * forceMag;
      const fy = sinF * forceMag;

      pen.vx += (fx / pen.mass) * dt;
      pen.vy += (fy / pen.mass) * dt;
      pen.omega += ((rx * fy - ry * fx) * 0.45 / pen.inertia) * dt;
    }
  }
}

/**
 * Advances the tabletop rigid-body simulation by dt seconds using 4 substeps.
 */
export function stepPhysics(
  pens: PenBody[],
  obstacles: StationeryObstacle[],
  dt: number,
  fan: VentilationFan | null = null,
  fanTime = 0
): StepResult {
  const substeps = 4;
  const subDt = dt / substeps;
  const collisions: CollisionEvent[] = [];
  const droppedPlayers: Array<1 | 2> = [];

  for (let step = 0; step < substeps; step++) {
    const windFactor = fan ? getFanWindState(fan, fanTime + step * subDt).factor : 0;

    // 1. Integrate active pens and apply tabletop damping + localized fan wind
    for (const pen of pens) {
      if (pen.status === 'active') {
        if (fan && windFactor > 0.16) {
          applyFanWindToPen(pen, fan, windFactor, subDt);
        }

        pen.x += pen.vx * subDt;
        pen.y += pen.vy * subDt;
        pen.angle += pen.omega * subDt;

        // Exponential + dry friction blend for snappy natural stops
        const linDecay = Math.exp(-pen.spec.linearDamping * subDt);
        const angDecay = Math.exp(-pen.spec.angularDamping * subDt);
        pen.vx *= linDecay;
        pen.vy *= linDecay;
        pen.omega *= angDecay;

        const speed = Math.hypot(pen.vx, pen.vy);
        if (speed > 0 && speed < 48) {
          const dryDrop = Math.max(0, speed - 65 * subDt);
          const ratio = dryDrop / speed;
          pen.vx *= ratio;
          pen.vy *= ratio;
        }
        if (Math.abs(pen.omega) < 0.75) {
          const sign = Math.sign(pen.omega);
          const nextW = Math.max(0, Math.abs(pen.omega) - 1.6 * subDt);
          pen.omega = sign * nextW;
        }
      } else if (pen.status === 'falling') {
        pen.fallProgress = Math.min(1, pen.fallProgress + subDt * 1.95);
        pen.x += pen.fallVx * subDt;
        pen.y += (pen.fallVy + 260 * pen.fallProgress) * subDt;
        pen.angle += pen.fallSpin * subDt;
        if (pen.fallProgress >= 1) {
          pen.status = 'out';
        }
      }
    }

    // 2. Pen vs Pen collisions
    if (pens.length >= 2 && pens[0].status === 'active' && pens[1].status === 'active') {
      const ev = resolvePenVsPen(pens[0], pens[1]);
      if (ev) {
        collisions.push(ev);
      }
    }

    // 3. Pen vs Obstacles
    for (const pen of pens) {
      if (pen.status !== 'active') continue;
      for (const obs of obstacles) {
        const ev = resolvePenVsObstacle(pen, obs);
        if (ev) {
          collisions.push(ev);
        }
      }
    }

    // 4. Desk edge drop-off checks
    for (const pen of pens) {
      if (pen.status === 'active' && isCenterOffDesk(pen)) {
        pen.status = 'falling';
        pen.fallProgress = 0;
        // Carry momentum off the edge with an outward nudge
        let outX = 0;
        let outY = 0;
        if (pen.x < DESK_BOUNDS.left) outX = -110;
        else if (pen.x > DESK_BOUNDS.right) outX = 110;
        if (pen.y < DESK_BOUNDS.top) outY = -110;
        else if (pen.y > DESK_BOUNDS.bottom) outY = 110;

        const fallbackSpinDir = (pen.x + pen.y) % 2 >= 1 ? 1 : -1;
        const spinSign = Math.abs(pen.omega) > 0.1 ? Math.sign(pen.omega) : fallbackSpinDir;
        pen.fallVx = pen.vx * 0.45 + outX;
        pen.fallVy = pen.vy * 0.45 + outY;
        pen.fallSpin = pen.omega * 0.8 + spinSign * 4.5;
        pen.vx = 0;
        pen.vy = 0;
        pen.omega = 0;
        droppedPlayers.push(pen.player);
      }
    }
  }

  // Decay hit flashes
  for (const pen of pens) {
    if (pen.hitFlash > 0) pen.hitFlash = Math.max(0, pen.hitFlash - dt * 6);
  }
  for (const obs of obstacles) {
    if (obs.hitFlash > 0) obs.hitFlash = Math.max(0, obs.hitFlash - dt * 6);
  }

  // Check if all active/falling bodies are settled
  let settled = true;
  for (const pen of pens) {
    if (pen.status === 'falling') {
      settled = false;
      break;
    }
    if (pen.status === 'active') {
      const speed = Math.hypot(pen.vx, pen.vy);
      if (speed > STOP_LINEAR_SPEED || Math.abs(pen.omega) > STOP_ANGULAR_SPEED) {
        settled = false;
        break;
      }
    }
  }

  if (settled) {
    for (const pen of pens) {
      if (pen.status === 'active') {
        pen.vx = 0;
        pen.vy = 0;
        pen.omega = 0;
      }
    }
  }

  return { collisions, droppedPlayers, settled };
}
