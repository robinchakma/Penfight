import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  db,
  ensureFirestoreOnline,
  handleFirestoreError,
  OperationType,
} from '../firebase';
import { PenClassId } from './types';

export const LEADERBOARDS_COLLECTION = 'leaderboards';
export const DISPLAY_NAME_MAX_LENGTH = 32;
export const DISPLAY_NAME_MIN_LENGTH = 1;

const VALID_PEN_CLASSES: PenClassId[] = [
  'ballpoint',
  'fountain',
  'gel',
  'marker',
  'mechanical',
  'rollerball',
];

export interface LeaderboardEntry {
  uid: string;
  displayName: string;
  favoritePen: PenClassId;
  totalWins: number;
  totalLosses: number;
  roundsWon: number;
  ringOuts: number;
  tournamentsWon: number;
  hardestImpact: number;
  createdAt?: Timestamp | null;
  updatedAt?: Timestamp | null;
}

export interface MatchStatDelta {
  won: boolean;
  roundsWon: number;
  ringOuts: number;
  tournamentChampion?: boolean;
  hardestImpact: number;
  penClass: PenClassId;
}

export function sanitizeDisplayName(
  raw: string | null | undefined,
  fallback?: string | null
): string {
  const cleanedRaw = (raw ?? '').replace(/\s+/g, ' ').trim();
  if (cleanedRaw.length >= DISPLAY_NAME_MIN_LENGTH) {
    return cleanedRaw.slice(0, DISPLAY_NAME_MAX_LENGTH);
  }
  const cleanedFallback = (fallback ?? '').replace(/\s+/g, ' ').trim();
  if (cleanedFallback.length >= DISPLAY_NAME_MIN_LENGTH) {
    return cleanedFallback.slice(0, DISPLAY_NAME_MAX_LENGTH);
  }
  return 'Desk Challenger';
}

function normalizePenClass(value: unknown): PenClassId {
  if (typeof value === 'string' && VALID_PEN_CLASSES.includes(value as PenClassId)) {
    return value as PenClassId;
  }
  return 'ballpoint';
}

function clampInt(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.min(max, Math.round(value)));
}

function parseEntry(id: string, data: Record<string, unknown>): LeaderboardEntry {
  return {
    uid: typeof data.uid === 'string' ? data.uid : id,
    displayName: sanitizeDisplayName(
      typeof data.displayName === 'string' ? data.displayName : undefined
    ),
    favoritePen: normalizePenClass(data.favoritePen),
    totalWins: clampInt(Number(data.totalWins ?? 0), 0, 1000000),
    totalLosses: clampInt(Number(data.totalLosses ?? 0), 0, 1000000),
    roundsWon: clampInt(Number(data.roundsWon ?? 0), 0, 5000000),
    ringOuts: clampInt(Number(data.ringOuts ?? 0), 0, 5000000),
    tournamentsWon: clampInt(Number(data.tournamentsWon ?? 0), 0, 100000),
    hardestImpact: Math.max(
      0,
      Math.min(100000, Math.round(Number(data.hardestImpact ?? 0) || 0))
    ),
    createdAt: data.createdAt instanceof Timestamp ? data.createdAt : null,
    updatedAt: data.updatedAt instanceof Timestamp ? data.updatedAt : null,
  };
}

export function sortLeaderboardEntries(entries: LeaderboardEntry[]): LeaderboardEntry[] {
  return [...entries].sort((a, b) => {
    if (b.totalWins !== a.totalWins) return b.totalWins - a.totalWins;
    if (b.tournamentsWon !== a.tournamentsWon) return b.tournamentsWon - a.tournamentsWon;
    if (b.roundsWon !== a.roundsWon) return b.roundsWon - a.roundsWon;
    if (b.ringOuts !== a.ringOuts) return b.ringOuts - a.ringOuts;
    return a.totalLosses - b.totalLosses;
  });
}

function buildTopLeaderboardQuery(maxRows: number) {
  return query(
    collection(db, LEADERBOARDS_COLLECTION),
    where('totalWins', '>=', 0),
    orderBy('totalWins', 'desc'),
    limit(maxRows)
  );
}

export async function fetchTopLeaderboard(maxRows = 25): Promise<LeaderboardEntry[]> {
  try {
    await ensureFirestoreOnline();
    const snapshot = await getDocs(buildTopLeaderboardQuery(maxRows));
    const entries = snapshot.docs.map((docSnap) =>
      parseEntry(docSnap.id, docSnap.data() as Record<string, unknown>)
    );
    return sortLeaderboardEntries(entries);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, LEADERBOARDS_COLLECTION);
  }
}

export function subscribeTopLeaderboard(
  maxRows: number,
  onData: (entries: LeaderboardEntry[]) => void,
  onError: (err: unknown) => void
): () => void {
  const q = buildTopLeaderboardQuery(maxRows);
  return onSnapshot(
    q,
    (snapshot) => {
      const entries = snapshot.docs.map((docSnap) =>
        parseEntry(docSnap.id, docSnap.data() as Record<string, unknown>)
      );
      onData(sortLeaderboardEntries(entries));
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, LEADERBOARDS_COLLECTION);
      } catch (wrappedError) {
        onError(wrappedError);
      }
    }
  );
}

export async function fetchPlayerLeaderboardEntry(
  uid: string
): Promise<LeaderboardEntry | null> {
  const path = `${LEADERBOARDS_COLLECTION}/${uid}`;
  try {
    const snap = await getDoc(doc(db, LEADERBOARDS_COLLECTION, uid));
    if (!snap.exists()) return null;
    return parseEntry(snap.id, snap.data() as Record<string, unknown>);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function ensurePlayerLeaderboardProfile(
  user: User,
  favoritePen: PenClassId
): Promise<LeaderboardEntry> {
  const path = `${LEADERBOARDS_COLLECTION}/${user.uid}`;
  const docRef = doc(db, LEADERBOARDS_COLLECTION, user.uid);
  try {
    await ensureFirestoreOnline();
    const existingSnap = await getDoc(docRef);
    if (existingSnap.exists()) {
      return parseEntry(existingSnap.id, existingSnap.data() as Record<string, unknown>);
    }

    const displayName = sanitizeDisplayName(user.displayName);
    const safePen = normalizePenClass(favoritePen);
    await setDoc(docRef, {
      uid: user.uid,
      displayName,
      favoritePen: safePen,
      totalWins: 0,
      totalLosses: 0,
      roundsWon: 0,
      ringOuts: 0,
      tournamentsWon: 0,
      hardestImpact: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    const createdSnap = await getDoc(docRef);
    if (createdSnap.exists()) {
      return parseEntry(createdSnap.id, createdSnap.data() as Record<string, unknown>);
    }

    return {
      uid: user.uid,
      displayName,
      favoritePen: safePen,
      totalWins: 0,
      totalLosses: 0,
      roundsWon: 0,
      ringOuts: 0,
      tournamentsWon: 0,
      hardestImpact: 0,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updatePlayerLeaderboardProfile(
  uid: string,
  displayName: string,
  favoritePen: PenClassId
): Promise<void> {
  const path = `${LEADERBOARDS_COLLECTION}/${uid}`;
  const docRef = doc(db, LEADERBOARDS_COLLECTION, uid);
  const safeName = sanitizeDisplayName(displayName);
  const safePen = normalizePenClass(favoritePen);
  try {
    await updateDoc(docRef, {
      displayName: safeName,
      favoritePen: safePen,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function recordCompetitiveMatchStats(
  user: User,
  delta: MatchStatDelta
): Promise<LeaderboardEntry> {
  const path = `${LEADERBOARDS_COLLECTION}/${user.uid}`;
  const docRef = doc(db, LEADERBOARDS_COLLECTION, user.uid);

  const addWins = delta.won ? 1 : 0;
  const addLosses = delta.won ? 0 : 1;
  const addRounds = clampInt(delta.roundsWon, 0, 10);
  const addRingOuts = clampInt(delta.ringOuts, 0, 10);
  const addTournaments = delta.tournamentChampion ? 1 : 0;
  const impactScore = clampInt(delta.hardestImpact, 0, 100000);
  const safePen = normalizePenClass(delta.penClass);

  try {
    await ensureFirestoreOnline();
    const updated = await runTransaction(db, async (tx) => {
      const snap = await tx.get(docRef);
      if (!snap.exists()) {
        const displayName = sanitizeDisplayName(user.displayName);
        tx.set(docRef, {
          uid: user.uid,
          displayName,
          favoritePen: safePen,
          totalWins: addWins,
          totalLosses: addLosses,
          roundsWon: addRounds,
          ringOuts: addRingOuts,
          tournamentsWon: addTournaments,
          hardestImpact: impactScore,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        return {
          uid: user.uid,
          displayName,
          favoritePen: safePen,
          totalWins: addWins,
          totalLosses: addLosses,
          roundsWon: addRounds,
          ringOuts: addRingOuts,
          tournamentsWon: addTournaments,
          hardestImpact: impactScore,
        };
      }

      const prev = parseEntry(snap.id, snap.data() as Record<string, unknown>);
      const nextWins = clampInt(prev.totalWins + addWins, 0, 1000000);
      const nextLosses = clampInt(prev.totalLosses + addLosses, 0, 1000000);
      const nextRounds = clampInt(prev.roundsWon + addRounds, 0, 5000000);
      const nextRingOuts = clampInt(prev.ringOuts + addRingOuts, 0, 5000000);
      const nextTournaments = clampInt(prev.tournamentsWon + addTournaments, 0, 100000);
      const nextImpact = Math.max(prev.hardestImpact, impactScore);
      const safeName = sanitizeDisplayName(prev.displayName, user.displayName);

      tx.update(docRef, {
        displayName: safeName,
        favoritePen: safePen,
        totalWins: nextWins,
        totalLosses: nextLosses,
        roundsWon: nextRounds,
        ringOuts: nextRingOuts,
        tournamentsWon: nextTournaments,
        hardestImpact: nextImpact,
        updatedAt: serverTimestamp(),
      });

      return {
        ...prev,
        displayName: safeName,
        favoritePen: safePen,
        totalWins: nextWins,
        totalLosses: nextLosses,
        roundsWon: nextRounds,
        ringOuts: nextRingOuts,
        tournamentsWon: nextTournaments,
        hardestImpact: nextImpact,
      };
    });

    return updated;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
