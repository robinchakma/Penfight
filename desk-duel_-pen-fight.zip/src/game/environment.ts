import { DESK_BOUNDS, getFanWindState, WORLD_HEIGHT, WORLD_WIDTH } from './constants';
import {
  DeskDebris,
  DeskDebrisKind,
  DustMote,
  ObstacleKind,
  PenBody,
  StationeryObstacle,
  VentilationFan,
} from './types';

const PENCIL_RIM_COLORS = ['#F59E0B', '#D97706', '#DC2626', '#15803D', '#2563EB'];
const ERASER_CRUMB_COLORS = ['#F4A5B0', '#E88B99', '#8AB0E6'];
const WOOD_SHADES = ['#F3D5AE', '#EBC79B', '#E3BA89'];
const MAX_ACTIVE_DEBRIS = 18;

let nextDebrisId = 1;

function randomBetween(min: number, max: number): number {
  return min + Math.random() * (max - min);
}

function pickRandom<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

export function createInitialDustMotes(count = 36): DustMote[] {
  const motes: DustMote[] = [];
  for (let i = 0; i < count; i++) {
    motes.push({
      x: randomBetween(30, WORLD_WIDTH - 30),
      y: randomBetween(20, WORLD_HEIGHT - 20),
      vx: randomBetween(-7, 11),
      vy: randomBetween(-9, -2),
      size: randomBetween(1.0, 2.7),
      baseAlpha: randomBetween(0.14, 0.42),
      phase: randomBetween(0, Math.PI * 2),
      driftSpeed: randomBetween(0.45, 1.15),
      warmth: randomBetween(0.35, 1),
    });
  }
  return motes;
}

function createDebrisItem(
  kind: DeskDebrisKind,
  x: number,
  y: number,
  settled: boolean,
  customColor?: string
): DeskDebris {
  return {
    id: nextDebrisId++,
    kind,
    x,
    y,
    vx: settled ? 0 : randomBetween(-22, 22),
    vy: settled ? 0 : randomBetween(-18, 18),
    angle: randomBetween(0, Math.PI * 2),
    omega: settled ? 0 : randomBetween(-2.2, 2.2),
    scale: kind === 'shaving' ? randomBetween(0.75, 1.18) : randomBetween(0.7, 1.25),
    rimColor:
      customColor ??
      (kind === 'shaving' ? pickRandom(PENCIL_RIM_COLORS) : pickRandom(ERASER_CRUMB_COLORS)),
    woodShade: pickRandom(WOOD_SHADES),
    landingProgress: settled ? 1 : 0,
    alpha: settled ? randomBetween(0.78, 0.96) : 0,
    fadingOut: false,
    fanAngle: randomBetween(1.45, 2.25),
    scallops: Math.floor(randomBetween(5, 8)),
  };
}

function findSafeDeskPoint(
  obstacles: StationeryObstacle[],
  pens: PenBody[],
  preferPerimeter: boolean
): { x: number; y: number } {
  const pad = 34;
  for (let attempt = 0; attempt < 16; attempt++) {
    let x: number;
    let y: number;
    if (preferPerimeter && Math.random() < 0.72) {
      // Cluster naturally near edges/corners of the school desk
      const side = Math.floor(Math.random() * 4);
      if (side === 0) {
        x = randomBetween(DESK_BOUNDS.left + pad, DESK_BOUNDS.right - pad);
        y = randomBetween(DESK_BOUNDS.top + pad, DESK_BOUNDS.top + 135);
      } else if (side === 1) {
        x = randomBetween(DESK_BOUNDS.left + pad, DESK_BOUNDS.right - pad);
        y = randomBetween(DESK_BOUNDS.bottom - 135, DESK_BOUNDS.bottom - pad);
      } else if (side === 2) {
        x = randomBetween(DESK_BOUNDS.left + pad, DESK_BOUNDS.left + 170);
        y = randomBetween(DESK_BOUNDS.top + pad, DESK_BOUNDS.bottom - pad);
      } else {
        x = randomBetween(DESK_BOUNDS.right - 170, DESK_BOUNDS.right - pad);
        y = randomBetween(DESK_BOUNDS.top + pad, DESK_BOUNDS.bottom - pad);
      }
    } else {
      x = randomBetween(DESK_BOUNDS.left + pad, DESK_BOUNDS.right - pad);
      y = randomBetween(DESK_BOUNDS.top + pad, DESK_BOUNDS.bottom - pad);
    }

    const nearPen = pens.some((p) => Math.hypot(x - p.x, y - p.y) < 52);
    const nearObs = obstacles.some(
      (o) => Math.hypot(x - o.x, y - o.y) < Math.max(o.halfW, o.halfH) + 18
    );
    if (!nearPen && !nearObs) {
      return { x, y };
    }
  }
  return {
    x: randomBetween(DESK_BOUNDS.left + 50, DESK_BOUNDS.right - 50),
    y: randomBetween(DESK_BOUNDS.top + 50, DESK_BOUNDS.bottom - 50),
  };
}

export function createInitialDeskDebris(
  obstacles: StationeryObstacle[],
  pens: PenBody[]
): DeskDebris[] {
  const debris: DeskDebris[] = [];
  const shavingCount = 6 + Math.floor(Math.random() * 3); // 6–8 pencil shavings
  const crumbCount = 4;

  // If a sharpener or eraser obstacle is present, cluster 1-2 shavings/crumbs nearby
  const sharpener = obstacles.find((o) => o.kind === 'sharpener');
  if (sharpener) {
    const a = randomBetween(0, Math.PI * 2);
    const dist = randomBetween(34, 62);
    debris.push(
      createDebrisItem(
        'shaving',
        sharpener.x + Math.cos(a) * dist,
        sharpener.y + Math.sin(a) * dist,
        true
      )
    );
  }

  for (let i = debris.length; i < shavingCount; i++) {
    const pt = findSafeDeskPoint(obstacles, pens, true);
    debris.push(createDebrisItem('shaving', pt.x, pt.y, true));
  }

  for (let i = 0; i < crumbCount; i++) {
    const pt = findSafeDeskPoint(obstacles, pens, false);
    debris.push(createDebrisItem('crumb', pt.x, pt.y, true));
  }

  return debris;
}

export function spawnDeskDebris(
  debrisList: DeskDebris[],
  obstacles: StationeryObstacle[],
  pens: PenBody[],
  kind: DeskDebrisKind = 'shaving',
  origin?: { x: number; y: number; color?: string }
): void {
  const activeCount = debrisList.filter((d) => !d.fadingOut).length;
  if (activeCount >= MAX_ACTIVE_DEBRIS) {
    const oldest = debrisList.find((d) => !d.fadingOut && d.landingProgress >= 1);
    if (oldest) {
      oldest.fadingOut = true;
    }
  }

  let x: number;
  let y: number;
  if (origin) {
    const a = randomBetween(0, Math.PI * 2);
    const r = randomBetween(14, 42);
    x = Math.min(DESK_BOUNDS.right - 26, Math.max(DESK_BOUNDS.left + 26, origin.x + Math.cos(a) * r));
    y = Math.min(DESK_BOUNDS.bottom - 26, Math.max(DESK_BOUNDS.top + 26, origin.y + Math.sin(a) * r));
  } else {
    const pt = findSafeDeskPoint(obstacles, pens, true);
    x = pt.x;
    y = pt.y;
  }

  debrisList.push(createDebrisItem(kind, x, y, false, origin?.color));
}

export function triggerEnvironmentDraft(
  debrisList: DeskDebris[],
  dustMotes: DustMote[],
  obstacles: StationeryObstacle[],
  pens: PenBody[],
  x: number,
  y: number,
  impulse: number,
  obstacleKind?: ObstacleKind
): void {
  const norm = Math.min(1, impulse / 650);

  // Scatter nearby desk shavings/crumbs slightly from impact shockwave
  for (const item of debrisList) {
    const dx = item.x - x;
    const dy = item.y - y;
    const dist = Math.hypot(dx, dy);
    if (dist > 0.5 && dist < 130) {
      const push = (1 - dist / 130) * (40 + norm * 95);
      item.vx += (dx / dist) * push;
      item.vy += (dy / dist) * push;
      item.omega += randomBetween(-4, 4) * (1 - dist / 130);
    }
  }

  // Swirl nearby dust motes in the sunlight
  for (const mote of dustMotes) {
    const dx = mote.x - x;
    const dy = mote.y - y;
    const dist = Math.hypot(dx, dy);
    if (dist > 0.5 && dist < 150) {
      const swirl = (1 - dist / 150) * (18 + norm * 32);
      mote.vx += (dx / dist) * swirl;
      mote.vy += (dy / dist) * swirl - 6;
    }
  }

  // Sharpener knocks produce a fresh pencil shaving; eraser knocks can shed a pink crumb
  if (obstacleKind === 'sharpener' && impulse > 90) {
    spawnDeskDebris(debrisList, obstacles, pens, 'shaving', { x, y });
  } else if (obstacleKind === 'eraser' && impulse > 140 && Math.random() < 0.65) {
    spawnDeskDebris(debrisList, obstacles, pens, 'crumb', {
      x,
      y,
      color: pickRandom(ERASER_CRUMB_COLORS),
    });
  } else if (!obstacleKind && impulse > 460 && Math.random() < 0.45) {
    spawnDeskDebris(debrisList, obstacles, pens, 'shaving');
  }
}

export function stepDeskEnvironment(
  debrisList: DeskDebris[],
  dustMotes: DustMote[],
  pens: PenBody[],
  obstacles: StationeryObstacle[],
  time: number,
  dt: number,
  spawnTimer: number,
  allowPeriodicSpawn: boolean,
  reducedMotion: boolean,
  fan: VentilationFan | null = null,
  fanTime = 0
): number {
  const stepDt = reducedMotion ? dt * 0.15 : dt;
  const fanState = fan ? getFanWindState(fan, fanTime) : null;
  const fanCos = fan ? Math.cos(fan.angle) : 0;
  const fanSin = fan ? Math.sin(fan.angle) : 0;

  // 1. Floating Dust Motes in afternoon classroom sunlight
  for (const mote of dustMotes) {
    // Gentle convection + sinusoidal meander
    const swayX = Math.cos(time * mote.driftSpeed + mote.phase) * 5.5;
    const swayY = Math.sin(time * (mote.driftSpeed * 0.8) + mote.phase * 1.3) * 3.8;

    let windPushX = 0;
    let windPushY = 0;
    if (!reducedMotion && fan && fanState && fanState.factor > 0.08) {
      const dx = mote.x - fan.x;
      const dy = mote.y - fan.y;
      const along = dx * fanCos + dy * fanSin;
      const perp = -dx * fanSin + dy * fanCos;
      if (along >= 0 && along <= fan.range * 1.15 && Math.abs(perp) <= fan.halfWidth * 1.2) {
        const strength = (1 - 0.45 * (along / (fan.range * 1.15))) * fanState.factor;
        windPushX = fanCos * 145 * strength;
        windPushY = fanSin * 145 * strength;
      }
    }

    // Gentle air-wake from fast sliding pens
    if (!reducedMotion) {
      for (const pen of pens) {
        if (pen.status !== 'active') continue;
        const speed = Math.hypot(pen.vx, pen.vy);
        if (speed < 140) continue;
        const dx = mote.x - pen.x;
        const dy = mote.y - pen.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 75 && dist > 1) {
          const wake = (1 - dist / 75) * Math.min(1, speed / 700) * 38;
          mote.vx += ((dx / dist) * wake + pen.vx * 0.04) * stepDt * 6;
          mote.vy += ((dy / dist) * wake + pen.vy * 0.04) * stepDt * 6;
        }
      }
    }

    // Relax velocity smoothly toward gentle ambient drift + fan breeze
    mote.vx += (3.5 + swayX + windPushX - mote.vx) * Math.min(1, stepDt * 2.2);
    mote.vy += (-4.2 + swayY + windPushY - mote.vy) * Math.min(1, stepDt * 2.2);

    mote.x += mote.vx * stepDt;
    mote.y += mote.vy * stepDt;

    // Wrap cleanly around arena viewport
    if (mote.x < -10) mote.x = WORLD_WIDTH + 10;
    else if (mote.x > WORLD_WIDTH + 10) mote.x = -10;
    if (mote.y < -10) mote.y = WORLD_HEIGHT + 10;
    else if (mote.y > WORLD_HEIGHT + 10) mote.y = -10;
  }

  // 2. Pencil Shavings & Eraser Crumbs on the Wooden Desk
  for (let i = debrisList.length - 1; i >= 0; i--) {
    const item = debrisList[i];

    if (item.landingProgress < 1) {
      item.landingProgress = Math.min(1, item.landingProgress + stepDt * 1.45);
      item.alpha = Math.min(0.92, item.landingProgress * 1.15);
    }

    // Fan gust flutters light shavings inside the wind corridor
    if (!reducedMotion && !item.fadingOut && fan && fanState && fanState.factor > 0.25) {
      const dx = item.x - fan.x;
      const dy = item.y - fan.y;
      const along = dx * fanCos + dy * fanSin;
      const perp = -dx * fanSin + dy * fanCos;
      if (along >= 0 && along <= fan.range && Math.abs(perp) <= fan.halfWidth) {
        const push =
          (1 - 0.45 * (along / fan.range)) *
          Math.cos((perp / fan.halfWidth) * Math.PI * 0.5) *
          fanState.factor;
        const flutter = Math.sin(time * 7 + item.id) * 28;
        item.vx += (fanCos * 230 * push - fanSin * flutter) * stepDt;
        item.vy += (fanSin * 230 * push + fanCos * flutter) * stepDt;
        item.omega += Math.cos(time * 5 + item.id) * 4.5 * push * stepDt;
      }
    }

    // Air wake when a fast pen slides past a settled shaving
    if (!reducedMotion && !item.fadingOut) {
      for (const pen of pens) {
        if (pen.status !== 'active') continue;
        const penSpeed = Math.hypot(pen.vx, pen.vy);
        if (penSpeed < 170) continue;
        const dx = item.x - pen.x;
        const dy = item.y - pen.y;
        const reach = pen.spec.length * 0.45 + 22;
        const dist = Math.hypot(dx, dy);
        if (dist < reach && dist > 1) {
          const factor = (1 - dist / reach) * Math.min(1, penSpeed / 680);
          item.vx += ((dx / dist) * 55 + pen.vx * 0.14) * factor * stepDt * 9;
          item.vy += ((dy / dist) * 55 + pen.vy * 0.14) * factor * stepDt * 9;
          item.omega += ((dx * pen.vy - dy * pen.vx) * 0.0005) * factor;
        }
      }
    }

    item.x += item.vx * stepDt;
    item.y += item.vy * stepDt;
    item.angle += item.omega * stepDt;

    // Crisp wood-tabletop friction for sliding shavings
    const damp = Math.exp(-8.5 * stepDt);
    item.vx *= damp;
    item.vy *= damp;
    item.omega *= Math.exp(-7.5 * stepDt);

    // Fade out if nudged off the desk edge
    const offDesk =
      item.x < DESK_BOUNDS.left + 4 ||
      item.x > DESK_BOUNDS.right - 4 ||
      item.y < DESK_BOUNDS.top + 4 ||
      item.y > DESK_BOUNDS.bottom - 4;
    if (offDesk) {
      item.fadingOut = true;
    }

    if (item.fadingOut) {
      item.alpha -= stepDt * 0.9;
      if (item.alpha <= 0) {
        debrisList.splice(i, 1);
      }
    }
  }

  // 3. Occasional random pencil shaving landing softly on the desk
  if (allowPeriodicSpawn && !reducedMotion) {
    let nextTimer = spawnTimer - dt;
    if (nextTimer <= 0) {
      const kind: DeskDebrisKind = Math.random() < 0.78 ? 'shaving' : 'crumb';
      spawnDeskDebris(debrisList, obstacles, pens, kind);
      nextTimer = randomBetween(6.0, 10.5);
    }
    return nextTimer;
  }

  return spawnTimer;
}
