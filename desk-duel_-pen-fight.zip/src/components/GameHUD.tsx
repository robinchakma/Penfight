import {
  Award,
  Compass,
  Film,
  Pause,
  RotateCcw,
  Shield,
  SkipForward,
  Swords,
  Volume2,
  VolumeX,
  Wind,
} from 'lucide-react';
import { ACHIEVEMENTS } from '../game/achievements';
import {
  getWinsNeeded,
  PEN_CLASS_LIST,
  PEN_CLASSES,
  PEN_TEXTURES,
  PLAYER_COLORS,
} from '../game/constants';
import {
  AchievementId,
  ArenaMode,
  FanWindStatus,
  GameMode,
  GameState,
  PenClassId,
  PenCustomization,
  PenTextureId,
  TurnPhase,
} from '../game/types';

interface GameHUDProps {
  gameState: GameState;
  mode: GameMode;
  arenaMode: ArenaMode;
  fanEnabled: boolean;
  fanStatus: FanWindStatus;
  roundNumber: number;
  totalRounds: number;
  p1Wins: number;
  p2Wins: number;
  p1Pen: PenClassId;
  p2Pen: PenClassId;
  p1Custom: PenCustomization;
  p2Custom: PenCustomization;
  p1Name?: string;
  p2Name?: string;
  tournamentStageLabel?: string | null;
  activeTurn: 1 | 2;
  turnPhase: TurnPhase;
  lastShooter: 1 | 2 | null;
  recentAchievement: AchievementId | null;
  muted: boolean;
  onToggleMute: () => void;
  onPause: () => void;
  onSkipReplay: () => void;
  onFreeplaySelectPen?: (player: 1 | 2) => void;
  onFreeplayChangePen?: (player: 1 | 2, penId: PenClassId) => void;
  onFreeplayChangeFinish?: (player: 1 | 2, finish: 'standard' | PenTextureId) => void;
  onFreeplayToggleArena?: (arenaMode: ArenaMode) => void;
  onFreeplayToggleFan?: () => void;
  onFreeplayResetDesk?: () => void;
}

export function GameHUD({
  gameState,
  mode,
  arenaMode,
  fanEnabled,
  fanStatus,
  roundNumber,
  totalRounds,
  p1Wins,
  p2Wins,
  p1Pen,
  p2Pen,
  p1Custom,
  p2Custom,
  p1Name,
  p2Name,
  tournamentStageLabel,
  activeTurn,
  turnPhase,
  lastShooter,
  recentAchievement,
  muted,
  onToggleMute,
  onPause,
  onSkipReplay,
  onFreeplaySelectPen,
  onFreeplayChangePen,
  onFreeplayChangeFinish,
  onFreeplayToggleArena,
  onFreeplayToggleFan,
  onFreeplayResetDesk,
}: GameHUDProps) {
  const p1Label = p1Name ?? 'Player 1';
  const p2Label = p2Name ?? (mode === 'ai' ? 'AI Rival' : 'Player 2');
  const winsNeeded = getWinsNeeded(totalRounds);
  const pipWidthClass = winsNeeded > 4 ? 'w-2.5' : 'w-4';

  if (gameState === 'REPLAYING') {
    const shooter = lastShooter ?? activeTurn;
    const shooterName = shooter === 1 ? p1Label : p2Label;
    const shooterColor = PLAYER_COLORS[shooter].primary;

    return (
      <div className="pointer-events-none absolute inset-0 z-20 flex flex-col justify-between p-3 sm:p-4">
        <div className="w-full max-w-6xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-lg bg-[#FAF6EE] border border-amber-600/40 shadow-md">
            <Film className="w-4 h-4 text-amber-700 shrink-0" />
            <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap">
              Slow-Motion Replay
            </span>
            <span className="text-xs font-mono font-semibold text-amber-700 tabular-nums whitespace-nowrap">
              0.35×
            </span>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#FAF6EE] border border-[#2A2520]/20 shadow-sm">
            <span
              className="w-2.5 h-2.5 rounded-sm shrink-0"
              style={{ backgroundColor: shooterColor }}
              aria-hidden="true"
            />
            <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap">
              {shooterName}&apos;s Flick
            </span>
          </div>

          <div className="pointer-events-auto flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              title={muted ? 'Unmute Sound' : 'Mute Sound'}
              aria-label={muted ? 'Unmute Sound' : 'Mute Sound'}
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-800 border border-[#2A2520]/20 shadow-sm transition-colors cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onSkipReplay}
              className="inline-flex items-center gap-1.5 px-3.5 h-10 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold shadow-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <span>Skip Replay</span>
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="px-3 py-1 rounded-md bg-slate-950/75 text-[11px] sm:text-xs text-slate-200 whitespace-nowrap">
            Slow-Motion Physics Playback · Esc or Space to Return
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'freeplay') {
    const selectedPenId = activeTurn === 1 ? p1Pen : p2Pen;
    const selectedCustom = activeTurn === 1 ? p1Custom : p2Custom;
    const activeFinish: 'standard' | PenTextureId =
      selectedCustom.styleMode === 'standard' ? 'standard' : selectedCustom.texture;

    return (
      <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-2.5 sm:p-3.5">
        {/* Top Sandbox Perimeter Bar */}
        <div className="w-full max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Pen Target + Live Class Picker */}
          <div className="pointer-events-auto flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-[#FAF6EE] border border-[#2A2520]/20 shadow-sm">
            <div className="flex items-center gap-1 p-0.5 bg-[#EDE6D8] rounded-md">
              <button
                type="button"
                onClick={() => onFreeplaySelectPen?.(1)}
                className={`px-2 py-1 rounded text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  activeTurn === 1
                    ? 'bg-[#FAF6EE] text-[#1D4ED8] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Blue Pen
              </button>
              <button
                type="button"
                onClick={() => onFreeplaySelectPen?.(2)}
                className={`px-2 py-1 rounded text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                  activeTurn === 2
                    ? 'bg-[#FAF6EE] text-[#DC2626] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Red Pen
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-1">
              {PEN_CLASS_LIST.map((pen) => (
                <button
                  key={pen.id}
                  type="button"
                  onClick={() => onFreeplayChangePen?.(activeTurn, pen.id)}
                  className={`px-2.5 py-1 rounded text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    selectedPenId === pen.id
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-700 hover:bg-[#EDE6D8]'
                  }`}
                >
                  {pen.id === 'ballpoint'
                    ? 'Ballpoint'
                    : pen.id === 'fountain'
                      ? 'Fountain'
                      : pen.id === 'gel'
                        ? 'Gel'
                        : pen.id === 'marker'
                          ? 'Marker'
                          : pen.id === 'mechanical'
                            ? 'Pencil'
                            : 'Roller'}
                </button>
              ))}
            </div>
          </div>

          {/* Center Sandbox Label */}
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-[#FAF6EE] border border-[#2A2520]/20 shadow-sm">
            <Compass className="w-3.5 h-3.5 text-amber-700 shrink-0" />
            <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap">
              Free Play
            </span>
            <span className="hidden sm:inline text-xs text-slate-500 whitespace-nowrap">
              · {PEN_CLASSES[selectedPenId].name}
            </span>
          </div>

          {/* Right Reset & Utility Controls */}
          <div className="pointer-events-auto flex items-center gap-1.5">
            <button
              type="button"
              onClick={onFreeplayResetDesk}
              className="inline-flex items-center gap-1.5 px-3 h-10 rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-900 text-xs font-semibold border border-[#2A2520]/20 shadow-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Desk</span>
            </button>
            <button
              type="button"
              onClick={onToggleMute}
              title={muted ? 'Unmute Sound' : 'Mute Sound'}
              aria-label={muted ? 'Unmute Sound' : 'Mute Sound'}
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-800 border border-[#2A2520]/20 shadow-sm transition-colors cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onPause}
              title="Pause Free Play (Esc)"
              aria-label="Pause Free Play"
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-800 border border-[#2A2520]/20 shadow-sm transition-colors cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom Sandbox Live Finish & Obstacle Switcher */}
        <div className="w-full max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="pointer-events-auto flex flex-wrap items-center gap-2 px-3 py-1.5 rounded-lg bg-[#FAF6EE] border border-[#2A2520]/20 shadow-sm">
            <span className="text-[11px] font-semibold text-slate-600 whitespace-nowrap">
              Finish:
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onFreeplayChangeFinish?.(activeTurn, 'standard')}
                className={`px-2 py-1 rounded text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  activeFinish === 'standard'
                    ? 'bg-slate-900 text-white'
                    : 'bg-[#EDE6D8] text-slate-700 hover:bg-[#E2D9C6]'
                }`}
              >
                Standard
              </button>
              {PEN_TEXTURES.map((tex) => (
                <button
                  key={tex.id}
                  type="button"
                  onClick={() => onFreeplayChangeFinish?.(activeTurn, tex.id)}
                  className={`px-2 py-1 rounded text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    activeFinish === tex.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-[#EDE6D8] text-slate-700 hover:bg-[#E2D9C6]'
                  }`}
                >
                  {tex.label}
                </button>
              ))}
            </div>

            <span className="text-slate-300 hidden sm:inline" aria-hidden="true">
              |
            </span>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onFreeplayToggleArena?.('clean')}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  arenaMode === 'clean'
                    ? 'bg-slate-900 text-white'
                    : 'bg-[#EDE6D8] text-slate-700 hover:bg-[#E2D9C6]'
                }`}
              >
                <Swords className="w-3 h-3" />
                <span>Clean</span>
              </button>
              <button
                type="button"
                onClick={() => onFreeplayToggleArena?.('obstacles')}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  arenaMode === 'obstacles'
                    ? 'bg-slate-900 text-white'
                    : 'bg-[#EDE6D8] text-slate-700 hover:bg-[#E2D9C6]'
                }`}
              >
                <Shield className="w-3 h-3" />
                <span>Obstacles</span>
              </button>
              <button
                type="button"
                onClick={() => onFreeplayToggleFan?.()}
                aria-pressed={fanEnabled}
                className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  fanEnabled
                    ? 'bg-sky-700 text-white'
                    : 'bg-[#EDE6D8] text-slate-700 hover:bg-[#E2D9C6]'
                }`}
              >
                <Wind className="w-3 h-3" />
                <span>Fan</span>
              </button>
            </div>
          </div>

          <div className="px-3 py-1 rounded-md bg-slate-950/75 text-[11px] sm:text-xs text-slate-200 whitespace-nowrap">
            Drag either pen to flick · No scoring · Edges auto-respawn
          </div>
        </div>
      </div>
    );
  }

  let turnStatusText = '';
  if (turnPhase === 'simulating') {
    turnStatusText = 'Pens in Motion';
  } else if (turnPhase === 'resolving') {
    turnStatusText = 'Settling Round';
  } else if (turnPhase === 'ai_thinking') {
    const aiOwner = activeTurn === 1 ? p1Label : p2Label;
    turnStatusText = `${aiOwner} Aiming...`;
  } else {
    turnStatusText = activeTurn === 1 ? `${p1Label}'s Turn` : `${p2Label}'s Turn`;
  }

  const activeColor = PLAYER_COLORS[activeTurn].primary;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 sm:p-4">
      {/* Top Perimeter Cluster */}
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Player 1 Score Card */}
        <div
          className={`flex items-center gap-3 px-3.5 py-2 rounded-lg bg-[#FAF6EE] border transition-colors ${
            activeTurn === 1 && (turnPhase === 'aiming' || turnPhase === 'ai_thinking')
              ? 'border-[#1D4ED8] shadow-md'
              : 'border-[#2A2520]/20 shadow-sm'
          }`}
        >
          <div
            className="w-2.5 h-7 rounded-sm shrink-0"
            style={{ backgroundColor: PLAYER_COLORS[1].primary }}
            aria-hidden="true"
          />
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap truncate max-w-[130px]">
                {p1Label}
              </span>
              <span className="text-[11px] text-slate-500 hidden sm:inline whitespace-nowrap">
                {PEN_CLASSES[p1Pen].name}
              </span>
            </div>
            <div className="flex items-center gap-1 mt-1" aria-label={`${p1Label} wins: ${p1Wins}`}>
              {Array.from({ length: winsNeeded }).map((_, idx) => (
                <span
                  key={idx}
                  className={`${pipWidthClass} h-2 rounded-sm transition-colors ${
                    idx < p1Wins ? 'bg-[#1D4ED8]' : 'bg-slate-300'
                  }`}
                />
              ))}
              <span className="ml-1 text-[11px] font-mono font-semibold text-slate-700 tabular-nums">
                {p1Wins}/{winsNeeded}
              </span>
            </div>
          </div>
        </div>

        {/* Center Round & Turn Indicator */}
        <div className="flex flex-col items-center px-4 py-1.5 rounded-lg bg-[#FAF6EE] border border-[#2A2520]/20 shadow-sm">
          <div className="text-[11px] font-medium text-slate-500 tabular-nums whitespace-nowrap">
            {tournamentStageLabel ? `${tournamentStageLabel} · ` : ''}
            {totalRounds === 1
              ? 'Round 1 · Sudden Death'
              : roundNumber > totalRounds
                ? `Round ${roundNumber} · Tiebreaker`
                : `Round ${roundNumber} · Best of ${totalRounds}`}
            {fanEnabled && fanStatus === 'gust' && (
              <span className="text-sky-700 font-semibold"> · Wind Gust</span>
            )}
            {fanEnabled && fanStatus === 'spinup' && (
              <span className="text-amber-700 font-semibold"> · Fan Spin-Up</span>
            )}
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span
              className="w-2 h-2 rounded-sm shrink-0"
              style={{ backgroundColor: activeColor }}
              aria-hidden="true"
            />
            <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap">
              {turnStatusText}
            </span>
          </div>
        </div>

        {/* Right Side: Player 2 Score + Utility Buttons */}
        <div className="flex items-center gap-2">
          <div
            className={`flex items-center gap-3 px-3.5 py-2 rounded-lg bg-[#FAF6EE] border transition-colors ${
              activeTurn === 2 && (turnPhase === 'aiming' || turnPhase === 'ai_thinking')
                ? 'border-[#DC2626] shadow-md'
                : 'border-[#2A2520]/20 shadow-sm'
            }`}
          >
            <div className="min-w-0 text-right">
              <div className="flex items-center justify-end gap-2">
                <span className="text-[11px] text-slate-500 hidden sm:inline whitespace-nowrap">
                  {PEN_CLASSES[p2Pen].name}
                </span>
                <span className="text-xs sm:text-sm font-bold text-slate-900 whitespace-nowrap">
                  {p2Label}
                </span>
              </div>
              <div
                className="flex items-center justify-end gap-1 mt-1"
                aria-label={`${p2Label} wins: ${p2Wins}`}
              >
                <span className="mr-1 text-[11px] font-mono font-semibold text-slate-700 tabular-nums">
                  {p2Wins}/{winsNeeded}
                </span>
                {Array.from({ length: winsNeeded }).map((_, idx) => (
                  <span
                    key={idx}
                    className={`${pipWidthClass} h-2 rounded-sm transition-colors ${
                      idx < p2Wins ? 'bg-[#DC2626]' : 'bg-slate-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            <div
              className="w-2.5 h-7 rounded-sm shrink-0"
              style={{ backgroundColor: PLAYER_COLORS[2].primary }}
              aria-hidden="true"
            />
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5">
            <button
              type="button"
              onClick={onToggleMute}
              title={muted ? 'Unmute Sound' : 'Mute Sound'}
              aria-label={muted ? 'Unmute Sound' : 'Mute Sound'}
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-800 border border-[#2A2520]/20 shadow-sm transition-colors cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onPause}
              title="Pause Match (Esc)"
              aria-label="Pause Match"
              className="w-10 h-10 flex items-center justify-center rounded-lg bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-800 border border-[#2A2520]/20 shadow-sm transition-colors cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Quiet Control Hint + Achievement Toast */}
      <div className="flex flex-col items-center gap-2">
        {recentAchievement && (
          <div className="px-3.5 py-1.5 rounded-lg bg-[#FAF6EE] border border-amber-600/40 shadow-md flex items-center gap-2 text-xs text-slate-900">
            <Award className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-bold">Medal Earned:</span>
            <span className="font-semibold text-amber-800">
              {ACHIEVEMENTS[recentAchievement].title}
            </span>
          </div>
        )}
        <div className="px-3 py-1 rounded-md bg-slate-950/75 text-[11px] sm:text-xs text-slate-200 whitespace-nowrap">
          Drag anywhere on your pen to aim &amp; flick · Grab ends for spin · Esc Pause
        </div>
      </div>
    </div>
  );
}
