import { useEffect } from 'react';
import { ArrowRight, Film, History, Home, Play, RotateCcw, Trophy, X } from 'lucide-react';
import { ACHIEVEMENT_LIST } from '../game/achievements';
import { AudioSettings } from '../game/audio';
import { getWinsNeeded, PLAYER_COLORS } from '../game/constants';
import {
  AchievementId,
  AchievementTier,
  DeskGraffitiNote,
  GameMode,
  GameState,
  MatchStats,
  RoundHistoryEntry,
  RoundSummary,
} from '../game/types';
import { AudioControls } from './AudioControls';

interface GameModalsProps {
  gameState: GameState;
  mode: GameMode;
  totalRounds: number;
  roundSummary: RoundSummary | null;
  deskGraffiti: DeskGraffitiNote | null;
  matchHistory: RoundHistoryEntry[];
  earnedAchievements: AchievementId[];
  stats: MatchStats;
  p1Wins: number;
  p2Wins: number;
  p1Name?: string;
  p2Name?: string;
  tournamentStageLabel?: string | null;
  hasReplay: boolean;
  leaderboardSyncNotice?: string | null;
  audioSettings: AudioSettings;
  onUpdateAudioSettings: (patch: Partial<AudioSettings>) => void;
  onResume: () => void;
  onNextRound: () => void;
  onReplayLastFlick: () => void;
  onRestartMatch: () => void;
  onReturnToTitle: () => void;
  onDismissGraffiti: () => void;
}

function MedalSvg({ tier, unlocked }: { tier: AchievementTier; unlocked: boolean }) {
  const palette = !unlocked
    ? { fill: '#CBD5E1', rim: '#94A3B8', ribbon: '#94A3B8', star: '#F1F5F9' }
    : tier === 'gold'
      ? { fill: '#F59E0B', rim: '#B45309', ribbon: '#1D4ED8', star: '#FEF3C7' }
      : tier === 'silver'
        ? { fill: '#94A3B8', rim: '#475569', ribbon: '#DC2626', star: '#F8FAFC' }
        : { fill: '#D97706', rim: '#78350F', ribbon: '#0F766E', star: '#FDE68A' };

  return (
    <svg viewBox="0 0 32 36" className="w-7 h-8 shrink-0" aria-hidden="true">
      <polygon points="8,2 15,2 16,12 10,12" fill={palette.ribbon} />
      <polygon points="17,2 24,2 22,12 16,12" fill={palette.ribbon} opacity="0.82" />
      <circle cx="16" cy="22" r="10.5" fill={palette.fill} stroke={palette.rim} strokeWidth="2" />
      <polygon
        points="16,15.5 17.9,19.6 22.4,20.2 19.1,23.3 19.9,27.7 16,25.6 12.1,27.7 12.9,23.3 9.6,20.2 14.1,19.6"
        fill={palette.star}
      />
    </svg>
  );
}

function AchievementMedalsPanel({ earned }: { earned: AchievementId[] }) {
  const earnedSet = new Set(earned);

  return (
    <div className="mt-4 text-left">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-bold text-slate-700">Match Medals</span>
        <span className="text-[11px] font-mono font-semibold text-slate-500 tabular-nums">
          {earned.length}/{ACHIEVEMENT_LIST.length} Earned
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {ACHIEVEMENT_LIST.map((ach) => {
          const unlocked = earnedSet.has(ach.id);
          return (
            <div
              key={ach.id}
              title={ach.description}
              className={`p-2 rounded-lg border flex items-start gap-2 transition-colors ${
                unlocked
                  ? 'bg-[#FFFDF8] border-amber-600/45 shadow-xs'
                  : 'bg-[#EDE6D8]/55 border-[#2A2520]/10 opacity-60'
              }`}
            >
              <MedalSvg tier={ach.tier} unlocked={unlocked} />
              <div className="min-w-0">
                <div className="text-[11px] font-bold text-slate-900 leading-tight">
                  {ach.title}
                </div>
                <div className="mt-0.5 text-[10px] leading-snug text-slate-600">
                  {ach.description}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MatchHistoryPanel({
  history,
  p1Name,
  p2Name,
}: {
  history: RoundHistoryEntry[];
  p1Name: string;
  p2Name: string;
}) {
  if (history.length === 0) return null;

  return (
    <div className="mt-4 text-left">
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
          <History className="w-3.5 h-3.5 text-slate-500" />
          <span>Match History</span>
        </div>
        <span className="text-[11px] font-mono text-slate-500 tabular-nums">
          {history.length} {history.length === 1 ? 'round' : 'rounds'}
        </span>
      </div>

      <div className="max-h-36 overflow-y-auto rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 divide-y divide-[#2A2520]/10">
        {history.map((entry) => {
          const winnerName =
            entry.winner === 'draw'
              ? 'Draw'
              : entry.winner === 1
                ? p1Name
                : p2Name;

          const winnerColor =
            entry.winner === 1
              ? PLAYER_COLORS[1].primary
              : entry.winner === 2
                ? PLAYER_COLORS[2].primary
                : '#B45309';

          const eventColor =
            entry.eventType === 'Obstacle Hit' ? 'text-amber-800' : 'text-slate-700';

          return (
            <div key={entry.id} className="px-3 py-2 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="font-mono font-semibold text-slate-500 tabular-nums shrink-0">
                    R{entry.roundNumber}
                  </span>
                  <span aria-hidden="true" className="text-slate-400">
                    ·
                  </span>
                  <span
                    className="w-2 h-2 rounded-xs shrink-0"
                    style={{ backgroundColor: winnerColor }}
                    aria-hidden="true"
                  />
                  <span className="font-bold truncate" style={{ color: winnerColor }}>
                    {winnerName}
                  </span>
                </div>
                <div className="mt-0.5 text-[11px] text-slate-600 truncate">
                  <span className={`font-semibold ${eventColor}`}>{entry.eventType}</span>
                  <span aria-hidden="true" className="mx-1 text-slate-400">
                    ·
                  </span>
                  <span>{entry.eventDetail}</span>
                </div>
              </div>

              <div className="shrink-0 text-[11px] font-mono font-semibold text-slate-500 tabular-nums pt-0.5">
                {entry.p1WinsAfter}–{entry.p2WinsAfter}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DeskGraffitiOverlay({
  note,
  onDismiss,
}: {
  note: DeskGraffitiNote;
  onDismiss: () => void;
}) {
  const tiltClass =
    note.tiltDeg < -1
      ? 'lg:-rotate-1'
      : note.tiltDeg < 0
        ? 'lg:-rotate-[0.6deg]'
        : note.tiltDeg > 1
          ? 'lg:rotate-1'
          : 'lg:rotate-[0.6deg]';

  return (
    <aside
      key={note.id}
      aria-label="Carved desk graffiti quote"
      className={`animate-desk-graffiti relative w-full max-w-md lg:w-72 lg:max-w-none lg:absolute lg:bottom-6 lg:left-6 z-40 rounded-lg overflow-hidden bg-gradient-to-br from-[#CA9863] via-[#BE8A54] to-[#AD7843] border border-[#4A290E]/75 shadow-[inset_0_1px_0_rgba(255,232,196,0.38),inset_0_-1px_0_rgba(58,30,10,0.35),0_12px_28px_rgba(0,0,0,0.45)] px-3.5 py-3 text-left ${tiltClass}`}
    >
      {/* Subtle carved wood-grain lines & etched pocketknife doodle */}
      <svg
        viewBox="0 0 280 96"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-0 w-full h-full opacity-30"
        aria-hidden="true"
      >
        <path
          d="M0 16 Q70 12 145 17 T280 14"
          fill="none"
          stroke="#4A290E"
          strokeWidth="1"
        />
        <path
          d="M0 44 Q95 49 185 42 T280 46"
          fill="none"
          stroke="#4A290E"
          strokeWidth="0.9"
        />
        <path
          d="M0 75 Q80 71 170 77 T280 73"
          fill="none"
          stroke="#4A290E"
          strokeWidth="1"
        />
        {/* Tiny scratched tally & star in bottom-right corner */}
        <g stroke="#3B1E08" strokeWidth="1.2" strokeLinecap="round" fill="none">
          <path d="M244 74 L249 85 M251 73 L256 85 M258 74 L263 84 M241 81 L266 76" />
          <path d="M225 76 L228 84 L222 79 L230 79 L224 84 Z" />
        </g>
      </svg>

      <div className="relative flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-[#3B1E08] tabular-nums">
            <span>Desk Graffiti</span>
            <span aria-hidden="true">·</span>
            <span>For {note.loserLabel}</span>
            <span aria-hidden="true">·</span>
            <span>R{note.roundNumber}</span>
          </div>
          <p className="mt-1 text-[13px] font-semibold italic leading-snug text-[#211004] [text-shadow:0_1px_0_rgba(255,234,200,0.34)]">
            &ldquo;{note.quote}&rdquo;
          </p>
        </div>

        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss desk graffiti"
          title="Dismiss note"
          className="shrink-0 w-10 h-10 -mt-1.5 -mr-1.5 rounded-md flex items-center justify-center text-[#3B1E08] hover:text-[#211004] hover:bg-[#4A290E]/15 focus-visible:outline-2 focus-visible:outline-[#211004] transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}

export function GameModals({
  gameState,
  mode,
  totalRounds,
  roundSummary,
  deskGraffiti,
  matchHistory,
  earnedAchievements,
  stats,
  p1Wins,
  p2Wins,
  p1Name,
  p2Name,
  tournamentStageLabel,
  hasReplay,
  leaderboardSyncNotice,
  audioSettings,
  onUpdateAudioSettings,
  onResume,
  onNextRound,
  onReplayLastFlick,
  onRestartMatch,
  onReturnToTitle,
  onDismissGraffiti,
}: GameModalsProps) {
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === 'BUTTON') return;
        if (gameState === 'ROUND_END') {
          e.preventDefault();
          onNextRound();
        } else if (gameState === 'GAME_OVER') {
          e.preventDefault();
          onRestartMatch();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [gameState, onNextRound, onRestartMatch]);

  if (gameState !== 'PAUSED' && gameState !== 'ROUND_END' && gameState !== 'GAME_OVER') {
    return null;
  }

  const p1Label = p1Name ?? 'Player 1';
  const p2Label = p2Name ?? (mode === 'ai' ? 'AI Rival' : 'Player 2');
  const isTournament = mode === 'tournament';

  if (gameState === 'PAUSED') {
    const isFreeplay = mode === 'freeplay';
    return (
      <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-slate-950/65">
        <div className="w-full max-w-md max-h-[92dvh] overflow-y-auto bg-[#FAF6EE] text-slate-900 rounded-xl border border-[#2A2520]/20 shadow-2xl p-6">
          <h2
            className="text-2xl font-bold tracking-tight text-slate-900"
            style={{ fontFamily: 'var(--font-display)' }}
          >
            {isFreeplay ? 'Free Play Paused' : 'Match Paused'}
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            {isFreeplay
              ? 'Sandbox Practice · No Scoring or Ring-Outs'
              : `${tournamentStageLabel ? `${tournamentStageLabel} · ` : ''}${p1Label} (${p1Wins}) — ${p2Label} (${p2Wins})`}
          </p>

          <div className="mt-4">
            <AudioControls settings={audioSettings} onChange={onUpdateAudioSettings} />
          </div>

          <div className="mt-4 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={onResume}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{isFreeplay ? 'Resume Free Play' : 'Resume Match'}</span>
            </button>
            <button
              type="button"
              onClick={onRestartMatch}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 font-semibold text-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{isFreeplay ? 'Reset Desk' : isTournament ? 'Restart Current Match' : 'Restart Match'}</span>
            </button>
            <button
              type="button"
              onClick={onReturnToTitle}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-[#2A2520]/15 hover:bg-[#F2ECE0] text-slate-700 font-semibold text-sm transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>{isTournament ? 'Exit Tournament' : 'Back to Setup'}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'ROUND_END' && roundSummary) {
    const winnerLabel =
      roundSummary.winner === 'draw'
        ? 'Double Ring-Out — Draw'
        : roundSummary.winner === 1
          ? `${p1Label} Wins the Round`
          : `${p2Label} Wins the Round`;

    const accent =
      roundSummary.winner === 1
        ? PLAYER_COLORS[1].primary
        : roundSummary.winner === 2
          ? PLAYER_COLORS[2].primary
          : '#D97706';

    return (
      <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 p-4 overflow-y-auto bg-slate-950/55">
        <div className="my-auto flex flex-col items-center gap-3 w-full max-w-md">
          <div className="w-full bg-[#FAF6EE] text-slate-900 rounded-xl border border-[#2A2520]/20 shadow-2xl p-6 text-center max-h-[82dvh] lg:max-h-[92dvh] overflow-y-auto">
          <div className="text-xs font-semibold text-slate-500 tabular-nums">
            {tournamentStageLabel ? `${tournamentStageLabel} · ` : ''}Round {roundSummary.roundNumber} Complete
          </div>
          <h2
            className="mt-1 text-2xl font-bold tracking-tight"
            style={{ fontFamily: 'var(--font-display)', color: accent }}
          >
            {winnerLabel}
          </h2>
          <p className="mt-1.5 text-sm text-slate-600">{roundSummary.reason}</p>

          <div className="mt-4 flex items-center justify-center gap-6 py-2.5 px-4 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/10">
            <div>
              <div className="text-xs text-slate-500 truncate max-w-[120px]">{p1Label}</div>
              <div className="text-2xl font-mono font-bold text-[#1D4ED8] tabular-nums">
                {roundSummary.p1Wins}
              </div>
            </div>
            <div className="text-sm font-semibold text-slate-400">vs</div>
            <div>
              <div className="text-xs text-slate-500 truncate max-w-[120px]">{p2Label}</div>
              <div className="text-2xl font-mono font-bold text-[#DC2626] tabular-nums">
                {roundSummary.p2Wins}
              </div>
            </div>
          </div>

          {/* Scrolling Match History Panel */}
          <MatchHistoryPanel history={matchHistory} p1Name={p1Label} p2Name={p2Label} />

          <div className="mt-5 flex flex-col gap-2.5">
            {hasReplay && (
              <button
                type="button"
                onClick={onReplayLastFlick}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 font-semibold text-sm border border-[#2A2520]/15 transition-colors cursor-pointer"
              >
                <Film className="w-4 h-4 text-amber-700" />
                <span>Replay Last Flick</span>
              </button>
            )}
            <button
              type="button"
              onClick={onNextRound}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <span>Start Next Round</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          </div>
          {deskGraffiti && (
            <DeskGraffitiOverlay note={deskGraffiti} onDismiss={onDismissGraffiti} />
          )}
        </div>
      </div>
    );
  }

  // GAME_OVER Modal
  const winsNeeded = getWinsNeeded(totalRounds);
  const p1WonMatch = p1Wins >= winsNeeded || p1Wins > p2Wins;
  const matchTitle = p1WonMatch ? `${p1Label} Wins the Match!` : `${p2Label} Wins the Match!`;
  const winnerAccent = p1WonMatch ? PLAYER_COLORS[1].primary : PLAYER_COLORS[2].primary;

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 p-4 overflow-y-auto bg-slate-950/65">
      <div className="my-auto flex flex-col items-center gap-3 w-full max-w-lg">
        <div className="w-full bg-[#FAF6EE] text-slate-900 rounded-xl border border-[#2A2520]/20 shadow-2xl p-6 max-h-[82dvh] lg:max-h-[92dvh] overflow-y-auto">
        <div className="flex flex-col items-center text-center">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-sm mb-3"
            style={{ backgroundColor: winnerAccent }}
          >
            <Trophy className="w-6 h-6" />
          </div>
          <div className="text-xs font-semibold text-slate-500">
            {totalRounds === 1 ? 'Single Round Complete' : `Best of ${totalRounds} Complete`}
          </div>
          <h2
            className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight"
            style={{ fontFamily: 'var(--font-display)', color: winnerAccent }}
          >
            {matchTitle}
          </h2>
        </div>

        {/* Final Score */}
        <div className="mt-4 flex items-center justify-center gap-8 py-2.5 px-4 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/10">
          <div className="text-center">
            <div className="text-xs font-medium text-slate-600">{p1Label}</div>
            <div className="text-3xl font-mono font-bold text-[#1D4ED8] tabular-nums">{p1Wins}</div>
          </div>
          <div className="text-base font-bold text-slate-400">–</div>
          <div className="text-center">
            <div className="text-xs font-medium text-slate-600">{p2Label}</div>
            <div className="text-3xl font-mono font-bold text-[#DC2626] tabular-nums">{p2Wins}</div>
          </div>
        </div>

        {/* Match Breakdown */}
        <div className="mt-3 grid grid-cols-3 gap-2 text-center">
          <div className="p-2 rounded-lg bg-[#F4EFE4]">
            <div className="text-[11px] text-slate-500">Total Flicks</div>
            <div className="text-base font-mono font-bold text-slate-900 tabular-nums mt-0.5">
              {stats.totalFlicks}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-[#F4EFE4]">
            <div className="text-[11px] text-slate-500">Hardest Clash</div>
            <div className="text-base font-mono font-bold text-slate-900 tabular-nums mt-0.5">
              {Math.round(stats.hardestImpact)}
            </div>
          </div>
          <div className="p-2 rounded-lg bg-[#F4EFE4]">
            <div className="text-[11px] text-slate-500">Ring-Outs</div>
            <div className="text-base font-mono font-bold text-slate-900 tabular-nums mt-0.5">
              {stats.p1RingOuts + stats.p2RingOuts}
            </div>
          </div>
        </div>

        {/* Match Medals */}
        <AchievementMedalsPanel earned={earnedAchievements} />

        {/* Scrolling Match History Panel */}
        <MatchHistoryPanel history={matchHistory} p1Name={p1Label} p2Name={p2Label} />

        {leaderboardSyncNotice && (
          <div className="mt-3 px-3 py-2 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/10 text-[11px] font-medium text-slate-700 text-center">
            {leaderboardSyncNotice}
          </div>
        )}

        <div className="mt-5 flex flex-col gap-2.5">
          {hasReplay && (
            <button
              type="button"
              onClick={onReplayLastFlick}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 font-semibold text-sm border border-[#2A2520]/15 transition-colors cursor-pointer"
            >
              <Film className="w-4 h-4 text-amber-700" />
              <span>Replay Last Flick</span>
            </button>
          )}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <button
              type="button"
              onClick={onRestartMatch}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Play Again</span>
            </button>
            <button
              type="button"
              onClick={onReturnToTitle}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 font-semibold text-sm transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
              <span>Change Setup</span>
            </button>
          </div>
        </div>
        </div>
        {deskGraffiti && (
          <DeskGraffitiOverlay note={deskGraffiti} onDismiss={onDismissGraffiti} />
        )}
      </div>
    </div>
  );
}
