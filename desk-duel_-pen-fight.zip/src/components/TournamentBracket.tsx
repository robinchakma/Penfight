import { useEffect } from 'react';
import {
  Bot,
  CheckCircle2,
  Crown,
  Eye,
  FastForward,
  Film,
  Home,
  Play,
  RotateCcw,
  Trophy,
  User,
} from 'lucide-react';
import { PEN_CLASSES } from '../game/constants';
import {
  getNextReadyMatch,
  getTournamentEntrant,
  hasHumanAliveInBracket,
} from '../game/tournament';
import {
  DeskGraffitiNote,
  TournamentBracketState,
  TournamentEntrant,
  TournamentMatchNode,
} from '../game/types';
import { PenPreviewIcon } from './PenPreviewIcon';

interface TournamentBracketProps {
  bracket: TournamentBracketState;
  lastMatchSummary: {
    matchId: string;
    stageLabel: string;
    winnerName: string;
    scoreLine: string;
  } | null;
  deskGraffiti: DeskGraffitiNote | null;
  hasReplay: boolean;
  leaderboardSyncNotice?: string | null;
  onPlayMatch: (matchId: string) => void;
  onSimulateMatch: (matchId: string) => void;
  onAutoFinishTournament: () => void;
  onReplayLastFlick: () => void;
  onRestartTournament: () => void;
  onReturnToTitle: () => void;
  onDismissGraffiti: () => void;
}

function BracketEntrantRow({
  entrant,
  score,
  isWinner,
  isLoser,
  sideColor,
}: {
  entrant: TournamentEntrant | null;
  score: number;
  isWinner: boolean;
  isLoser: boolean;
  sideColor: string;
}) {
  if (!entrant) {
    return (
      <div className="flex items-center justify-between gap-2 px-2.5 py-2 text-xs text-slate-400">
        <span>Waiting for winner</span>
        <span className="font-mono tabular-nums">–</span>
      </div>
    );
  }

  return (
    <div
      className={`flex items-center justify-between gap-2 px-2.5 py-2 transition-opacity ${
        isWinner ? 'bg-amber-50/90' : isLoser ? 'opacity-55' : ''
      }`}
    >
      <div className="flex items-center gap-2 min-w-0">
        <span
          className="w-1.5 h-5 rounded-xs shrink-0"
          style={{ backgroundColor: sideColor }}
          aria-hidden="true"
        />
        <span className="text-[11px] font-mono font-semibold text-slate-500 tabular-nums shrink-0">
          #{entrant.seed}
        </span>
        <div className="min-w-0">
          <div className="flex items-center gap-1 text-xs font-bold text-slate-900 truncate">
            {isWinner && <Crown className="w-3 h-3 text-amber-600 shrink-0" />}
            <span className="truncate">{entrant.name}</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-500 truncate">
            {entrant.isAI ? (
              <Bot className="w-2.5 h-2.5 shrink-0 text-slate-400" />
            ) : (
              <User className="w-2.5 h-2.5 shrink-0 text-slate-400" />
            )}
            <span className="truncate">{PEN_CLASSES[entrant.penClass].name}</span>
          </div>
        </div>
      </div>

      <span
        className={`text-sm font-mono font-bold tabular-nums shrink-0 ${
          isWinner ? 'text-slate-950' : 'text-slate-600'
        }`}
      >
        {score}
      </span>
    </div>
  );
}

function BracketMatchCard({
  bracket,
  match,
  isNextUp,
}: {
  bracket: TournamentBracketState;
  match: TournamentMatchNode;
  isNextUp: boolean;
}) {
  const entrantA = getTournamentEntrant(bracket, match.entrantAId);
  const entrantB = getTournamentEntrant(bracket, match.entrantBId);
  const completed = match.status === 'completed';

  return (
    <div
      className={`rounded-lg border overflow-hidden transition-all ${
        isNextUp
          ? 'bg-[#FFFDF8] border-[#1D4ED8] ring-2 ring-[#1D4ED8]/25 shadow-sm'
          : completed
            ? 'bg-[#F4EFE4] border-[#2A2520]/15'
            : 'bg-[#F4EFE4]/70 border-[#2A2520]/10'
      }`}
    >
      <div className="px-2.5 py-1.5 border-b border-[#2A2520]/10 flex items-center justify-between gap-2 text-[11px]">
        <span className="font-semibold text-slate-700 truncate">{match.stageLabel}</span>
        <span
          className={`font-semibold whitespace-nowrap shrink-0 ${
            isNextUp
              ? 'text-[#1D4ED8]'
              : completed
                ? 'text-emerald-700'
                : 'text-slate-400'
          }`}
        >
          {isNextUp ? 'Up Next' : completed ? 'Done' : 'Pending'}
        </span>
      </div>

      <div className="divide-y divide-[#2A2520]/10">
        <BracketEntrantRow
          entrant={entrantA}
          score={completed ? match.scoreA : 0}
          isWinner={completed && match.winnerId === entrantA?.id}
          isLoser={completed && match.winnerId !== null && match.winnerId !== entrantA?.id}
          sideColor="#1D4ED8"
        />
        <BracketEntrantRow
          entrant={entrantB}
          score={completed ? match.scoreB : 0}
          isWinner={completed && match.winnerId === entrantB?.id}
          isLoser={completed && match.winnerId !== null && match.winnerId !== entrantB?.id}
          sideColor="#DC2626"
        />
      </div>

      {completed && match.summaryNote && (
        <div className="px-2.5 py-1 border-t border-[#2A2520]/8 text-[10px] text-slate-500 truncate">
          {match.simulatedByEngine ? 'Simulated · ' : ''}
          {match.summaryNote}
        </div>
      )}
    </div>
  );
}

export function TournamentBracket({
  bracket,
  lastMatchSummary,
  deskGraffiti,
  hasReplay,
  leaderboardSyncNotice,
  onPlayMatch,
  onSimulateMatch,
  onAutoFinishTournament,
  onReplayLastFlick,
  onRestartTournament,
  onReturnToTitle,
  onDismissGraffiti,
}: TournamentBracketProps) {
  const nextMatch = getNextReadyMatch(bracket);
  const nextEntrantA = nextMatch ? getTournamentEntrant(bracket, nextMatch.entrantAId) : null;
  const nextEntrantB = nextMatch ? getTournamentEntrant(bracket, nextMatch.entrantBId) : null;
  const nextIsAIvsAI = Boolean(nextEntrantA?.isAI && nextEntrantB?.isAI);
  const humanAlive = hasHumanAliveInBracket(bracket);
  const champion = getTournamentEntrant(bracket, bracket.championId);

  // Automatically cascade AI-vs-AI bracket matches while a human contestant awaits their next round
  useEffect(() => {
    if (champion || !nextMatch || !nextIsAIvsAI || !humanAlive) return;
    const timer = window.setTimeout(() => {
      onSimulateMatch(nextMatch.id);
    }, 440);
    return () => window.clearTimeout(timer);
  }, [champion, nextMatch, nextIsAIvsAI, humanAlive, onSimulateMatch]);

  // Keyboard shortcut: Enter starts next human match
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key !== 'Enter') return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'BUTTON') return;
      if (champion) return;
      if (nextMatch && !nextIsAIvsAI) {
        e.preventDefault();
        onPlayMatch(nextMatch.id);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [champion, nextMatch, nextIsAIvsAI, onPlayMatch]);

  const roundColumns =
    bracket.size === 8
      ? [
          {
            title: 'Quarterfinals',
            matches: bracket.matches.filter((m) => m.roundIndex === 0),
          },
          {
            title: 'Semifinals',
            matches: bracket.matches.filter((m) => m.roundIndex === 1),
          },
          {
            title: 'Grand Final',
            matches: bracket.matches.filter((m) => m.roundIndex === 2),
          },
        ]
      : [
          {
            title: 'Semifinals',
            matches: bracket.matches.filter((m) => m.roundIndex === 0),
          },
          {
            title: 'Grand Final',
            matches: bracket.matches.filter((m) => m.roundIndex === 1),
          },
        ];

  const completedCount = bracket.matches.filter((m) => m.status === 'completed').length;
  const totalMatches = bracket.matches.length;

  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 p-4 overflow-y-auto bg-slate-950/60">
      <div className="my-auto w-full max-w-5xl bg-[#FAF6EE] text-slate-900 rounded-xl border border-[#2A2520]/20 shadow-2xl p-5 sm:p-6 max-h-[92dvh] overflow-y-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#2A2520]/10">
          <div>
            <div className="text-xs font-semibold text-slate-500 tabular-nums">
              {bracket.size}-Player Knockout Tournament ·{' '}
              {bracket.totalRoundsPerMatch === 1
                ? 'Single Round Matches'
                : `Best of ${bracket.totalRoundsPerMatch} Matches`}{' '}
              · {completedCount}/{totalMatches} Matches Complete
            </div>
            <h2
              className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-slate-900"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {champion ? 'Tournament Complete' : 'Tournament Bracket'}
            </h2>
          </div>

          {lastMatchSummary && !champion && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span className="font-semibold text-slate-800">
                {lastMatchSummary.stageLabel}: {lastMatchSummary.winnerName} ({lastMatchSummary.scoreLine})
              </span>
            </div>
          )}
        </div>

        {/* Champion Podium Banner */}
        {champion && (
          <div className="mt-4 p-4 sm:p-5 rounded-xl bg-gradient-to-br from-amber-50 via-[#FFFBF0] to-[#F4EFE4] border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-sm shrink-0">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-semibold text-amber-800">
                  Overall Bracket Champion · Seed #{champion.seed}
                </div>
                <div
                  className="text-xl sm:text-2xl font-bold text-slate-950"
                  style={{ fontFamily: 'var(--font-display)' }}
                >
                  {champion.name}
                </div>
                <div className="text-xs text-slate-600">
                  {PEN_CLASSES[champion.penClass].name} ·{' '}
                  {champion.isAI ? 'AI Contender' : 'Human Champion'}
                </div>
              </div>
            </div>

            <div className="px-4 py-2.5 rounded-lg bg-[#C89B6E]/35 border border-[#784E28]/20">
              <PenPreviewIcon
                penId={champion.penClass}
                player={1}
                custom={champion.custom}
                className="w-36 h-8"
              />
            </div>
          </div>
        )}

        {leaderboardSyncNotice && (
          <div className="mt-3 px-3 py-2 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/10 text-xs font-medium text-slate-700 text-center">
            {leaderboardSyncNotice}
          </div>
        )}

        {/* Bracket Tree Grid */}
        <div
          className={`mt-5 grid gap-4 items-center ${
            bracket.size === 8 ? 'grid-cols-1 md:grid-cols-3' : 'grid-cols-1 md:grid-cols-2'
          }`}
        >
          {roundColumns.map((col, colIdx) => (
            <div key={col.title} className="flex flex-col gap-3">
              <div className="text-xs font-bold text-slate-600 pb-1 border-b border-[#2A2520]/10">
                {col.title}
              </div>
              <div
                className={`flex flex-col ${
                  colIdx === 0
                    ? 'gap-2.5'
                    : colIdx === 1
                      ? 'gap-6 md:py-6'
                      : 'md:py-16'
                }`}
              >
                {col.matches.map((match) => (
                  <BracketMatchCard
                    key={match.id}
                    bracket={bracket}
                    match={match}
                    isNextUp={!champion && nextMatch?.id === match.id}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Desk Graffiti note if player just lost a match */}
        {deskGraffiti && (
          <div className="mt-4 p-3 rounded-lg bg-[#C99B68]/45 border border-[#4A290E]/35 flex items-center justify-between gap-3 text-left">
            <div className="text-xs text-[#211004]">
              <span className="font-bold">Desk Graffiti · For {deskGraffiti.loserLabel}:</span>{' '}
              <span className="italic font-semibold">&ldquo;{deskGraffiti.quote}&rdquo;</span>
            </div>
            <button
              type="button"
              onClick={onDismissGraffiti}
              className="text-xs font-semibold text-[#3B1E08] hover:text-[#211004] px-2 py-1 rounded cursor-pointer shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Action Controls */}
        <div className="mt-5 pt-4 border-t border-[#2A2520]/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {hasReplay && (
              <button
                type="button"
                onClick={onReplayLastFlick}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-xs font-semibold border border-[#2A2520]/15 transition-colors cursor-pointer"
              >
                <Film className="w-3.5 h-3.5 text-amber-700" />
                <span>Replay Last Flick</span>
              </button>
            )}
            <button
              type="button"
              onClick={onReturnToTitle}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg border border-[#2A2520]/15 hover:bg-[#F2ECE0] text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              <Home className="w-3.5 h-3.5" />
              <span>{champion ? 'Change Setup' : 'Exit Tournament'}</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2.5 w-full sm:w-auto">
            {champion ? (
              <button
                type="button"
                onClick={onRestartTournament}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] text-white text-sm font-bold shadow-sm transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Play New Tournament</span>
              </button>
            ) : nextMatch && nextIsAIvsAI && humanAlive ? (
              <button
                type="button"
                onClick={() => onSimulateMatch(nextMatch.id)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors cursor-pointer"
              >
                <FastForward className="w-4 h-4" />
                <span>Advancing AI Bracket ({nextMatch.stageLabel})...</span>
              </button>
            ) : nextMatch && nextIsAIvsAI ? (
              <>
                <button
                  type="button"
                  onClick={() => onPlayMatch(nextMatch.id)}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-sm font-semibold border border-[#2A2520]/15 transition-colors cursor-pointer"
                >
                  <Eye className="w-4 h-4" />
                  <span>Watch {nextMatch.stageLabel} Live</span>
                </button>
                <button
                  type="button"
                  onClick={onAutoFinishTournament}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] text-white text-sm font-bold shadow-sm transition-colors cursor-pointer"
                >
                  <FastForward className="w-4 h-4" />
                  <span>Finish Bracket</span>
                </button>
              </>
            ) : nextMatch ? (
              <button
                type="button"
                onClick={() => onPlayMatch(nextMatch.id)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] text-white text-sm font-bold shadow-sm transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>
                  Play {nextMatch.stageLabel}: {nextEntrantA?.name} vs {nextEntrantB?.name}
                </span>
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
