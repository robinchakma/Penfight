import { useId } from 'react';
import { getCustomColorPreset, PLAYER_COLORS } from '../game/constants';
import { PenClassId, PenCustomization } from '../game/types';

interface PenPreviewIconProps {
  penId: PenClassId;
  player: 1 | 2;
  custom?: PenCustomization;
  className?: string;
}

export function PenPreviewIcon({
  penId,
  player,
  custom,
  className = 'w-20 h-6',
}: PenPreviewIconProps) {
  const uid = useId().replace(/:/g, '');
  const baseColors = PLAYER_COLORS[player];
  const isCustom = custom?.styleMode === 'custom';
  const customPreset = isCustom && custom ? getCustomColorPreset(custom.colorId) : null;

  const primary = customPreset ? customPreset.primary : baseColors.primary;
  const secondary = customPreset ? customPreset.secondary : baseColors.secondary;
  const dark = customPreset ? customPreset.dark : baseColors.dark;

  const renderSvgDefs = () => {
    if (!isCustom || !custom) return null;
    const patId = `pat-${uid}`;
    const texId = `tex-${uid}`;

    return (
      <defs>
        {custom.pattern === 'stripes' && (
          <pattern id={patId} width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <rect width="4" height="10" fill={secondary} fillOpacity="0.45" />
          </pattern>
        )}
        {custom.pattern === 'chevron' && (
          <pattern id={patId} width="12" height="16" patternUnits="userSpaceOnUse">
            <path
              d="M1,1 L7,8 L1,15"
              fill="none"
              stroke={secondary}
              strokeWidth="2.2"
              strokeOpacity="0.58"
            />
          </pattern>
        )}
        {custom.pattern === 'checkered' && (
          <pattern id={patId} width="10" height="10" patternUnits="userSpaceOnUse">
            <rect x="0" y="0" width="5" height="5" fill="#FFFFFF" fillOpacity="0.34" />
            <rect x="5" y="5" width="5" height="5" fill="#FFFFFF" fillOpacity="0.34" />
          </pattern>
        )}
        {custom.pattern === 'dots' && (
          <pattern id={patId} width="10" height="10" patternUnits="userSpaceOnUse">
            <circle cx="3" cy="3" r="1.5" fill={secondary} fillOpacity="0.58" />
            <circle cx="8" cy="8" r="1.5" fill={secondary} fillOpacity="0.58" />
          </pattern>
        )}
        {custom.pattern === 'waves' && (
          <pattern id={patId} width="24" height="16" patternUnits="userSpaceOnUse">
            <path
              d="M0,5 Q6,1 12,5 T24,5 M0,11 Q6,7 12,11 T24,11"
              fill="none"
              stroke={secondary}
              strokeOpacity="0.58"
              strokeWidth="1.8"
            />
          </pattern>
        )}
        {custom.pattern === 'rings' && (
          <pattern id={patId} width="18" height="20" patternUnits="userSpaceOnUse">
            <rect x="6" y="0" width="4.5" height="20" fill={secondary} fillOpacity="0.56" />
          </pattern>
        )}
        {custom.pattern === 'lightning' && (
          <pattern id={patId} width="18" height="18" patternUnits="userSpaceOnUse">
            <path
              d="M0,13 L9,4 L18,13"
              fill="none"
              stroke={secondary}
              strokeOpacity="0.65"
              strokeWidth="2.1"
            />
          </pattern>
        )}
        {custom.pattern === 'camo' && (
          <pattern id={patId} width="26" height="18" patternUnits="userSpaceOnUse">
            <ellipse cx="7" cy="6" rx="6" ry="3.5" fill={secondary} fillOpacity="0.45" />
            <ellipse cx="19" cy="12" rx="6" ry="3.5" fill="#0F172A" fillOpacity="0.32" />
          </pattern>
        )}

        {custom.texture === 'brushed' && (
          <pattern id={texId} width="16" height="3" patternUnits="userSpaceOnUse">
            <line x1="0" y1="1.5" x2="16" y2="1.5" stroke="#FFFFFF" strokeOpacity="0.26" strokeWidth="0.8" />
          </pattern>
        )}
        {custom.texture === 'metallic' && (
          <linearGradient id={texId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.44" />
            <stop offset="35%" stopColor="#FFFFFF" stopOpacity="0.08" />
            <stop offset="60%" stopColor="#0F172A" stopOpacity="0.24" />
            <stop offset="85%" stopColor="#FFFFFF" stopOpacity="0.24" />
            <stop offset="100%" stopColor="#0F172A" stopOpacity="0.3" />
          </linearGradient>
        )}
        {custom.texture === 'matte' && (
          <pattern id={texId} width="6" height="6" patternUnits="userSpaceOnUse">
            <rect width="6" height="6" fill="#0F172A" fillOpacity="0.14" />
            <circle cx="2" cy="2" r="0.7" fill="#FFFFFF" fillOpacity="0.18" />
          </pattern>
        )}
        {custom.texture === 'carbon' && (
          <pattern id={texId} width="6" height="6" patternUnits="userSpaceOnUse">
            <path d="M0,0 L6,6 M6,0 L0,6" stroke="#0F172A" strokeOpacity="0.35" strokeWidth="1" />
          </pattern>
        )}
        {custom.texture === 'woodgrain' && (
          <pattern id={texId} width="24" height="6" patternUnits="userSpaceOnUse">
            <path
              d="M0,3 Q8,1 16,3 T24,3"
              fill="none"
              stroke="#452208"
              strokeOpacity="0.35"
              strokeWidth="1"
            />
          </pattern>
        )}
      </defs>
    );
  };

  const renderBarrelOverlay = (x: number, y: number, w: number, h: number, rx: number) => {
    if (!isCustom || !custom) return null;
    const patId = `pat-${uid}`;
    const texId = `tex-${uid}`;

    return (
      <>
        {custom.pattern !== 'solid' && (
          <rect x={x} y={y} width={w} height={h} rx={rx} fill={`url(#${patId})`} />
        )}
        {custom.texture !== 'smooth' ? (
          <rect x={x} y={y} width={w} height={h} rx={rx} fill={`url(#${texId})`} />
        ) : (
          <rect x={x + 2} y={y + 2} width={w - 4} height={h * 0.25} rx={1} fill="#FFFFFF" fillOpacity="0.32" />
        )}
      </>
    );
  };

  if (penId === 'ballpoint') {
    return (
      <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
        {renderSvgDefs()}
        <rect x="6" y="8" width="28" height="12" rx="4" fill={primary} stroke={dark} strokeWidth="1.5" />
        <rect
          x="10"
          y="5"
          width="20"
          height="3.5"
          rx="1.5"
          fill={isCustom ? '#F8FAFC' : secondary}
          stroke={dark}
          strokeWidth="1"
        />
        <rect
          x="34"
          y="9"
          width="56"
          height="10"
          rx="2"
          fill={isCustom ? primary : '#F1F5F9'}
          stroke={isCustom ? dark : '#475569'}
          strokeWidth="1.4"
        />
        {!isCustom && <rect x="36" y="12.5" width="52" height="3" fill={primary} />}
        {renderBarrelOverlay(34, 9, 56, 10, 2)}
        {isCustom && <rect x="86" y="9" width="4" height="10" fill={baseColors.primary} />}
        <polygon
          points="90,9 114,14 90,19"
          fill={isCustom ? '#E2E8F0' : '#E5C158'}
          stroke={isCustom ? '#475569' : '#6B4E16'}
          strokeWidth="1.2"
        />
        <circle cx="113" cy="14" r="2" fill={baseColors.primary} />
      </svg>
    );
  }

  if (penId === 'fountain') {
    return (
      <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
        {renderSvgDefs()}
        <rect
          x="6"
          y="7"
          width="84"
          height="14"
          rx="6"
          fill={primary}
          stroke={isCustom ? dark : '#3F2D0A'}
          strokeWidth="1.5"
        />
        {renderBarrelOverlay(6, 7, 84, 14, 6)}
        <rect
          x="14"
          y="4.5"
          width="26"
          height="3.5"
          rx="1.5"
          fill={isCustom ? '#F8FAFC' : '#F3D478'}
          stroke="#5E420D"
          strokeWidth="1"
        />
        <rect x="52" y="7" width="3.5" height="14" fill={isCustom ? '#F8FAFC' : '#F6DF93'} />
        <rect x="58" y="7" width="3.5" height="14" fill={isCustom ? '#F8FAFC' : '#F6DF93'} />
        {isCustom && <rect x="85" y="7" width="4" height="14" fill={baseColors.primary} />}
        <path
          d="M90,9 Q104,8 116,14 Q104,20 90,19 Z"
          fill={isCustom ? '#E2E8F0' : '#E8C563'}
          stroke={isCustom ? '#475569' : '#6E4F12'}
          strokeWidth="1.3"
        />
        <line x1="100" y1="14" x2="114" y2="14" stroke="#4A330A" strokeWidth="1.2" />
      </svg>
    );
  }

  if (penId === 'gel') {
    return (
      <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
        {renderSvgDefs()}
        <rect x="4" y="10.5" width="6" height="7" rx="1.5" fill={baseColors.primary} />
        <rect
          x="10"
          y="8"
          width="84"
          height="12"
          rx="4"
          fill={isCustom ? primary : '#1E293B'}
          stroke="#0F172A"
          strokeWidth="1.4"
        />
        {!isCustom && <rect x="20" y="12" width="46" height="4" fill={primary} />}
        {renderBarrelOverlay(10, 8, 84, 12, 4)}
        <rect x="68" y="7.5" width="24" height="13" rx="2" fill={isCustom ? '#0F172A' : primary} />
        {isCustom && <rect x="90" y="8" width="4" height="12" fill={baseColors.primary} />}
        <polygon points="94,9 115,14 94,19" fill="#CBD5E1" stroke="#475569" strokeWidth="1.2" />
      </svg>
    );
  }

  if (penId === 'mechanical') {
    return (
      <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
        {renderSvgDefs()}
        <rect x="4" y="9" width="9" height="10" rx="2.5" fill="#F472B6" stroke="#9D174D" strokeWidth="1.1" />
        <rect x="12" y="8.5" width="7" height="11" fill="#E5C158" stroke="#78350F" strokeWidth="1" />
        <rect x="19" y="8.5" width="54" height="11" rx="1.5" fill={primary} stroke={dark} strokeWidth="1.3" />
        {renderBarrelOverlay(19, 8.5, 54, 11, 1.5)}
        <rect x="20" y="5.5" width="22" height="3" rx="1.2" fill="#E2E8F0" stroke="#475569" strokeWidth="0.9" />
        <rect x="73" y="8" width="18" height="12" fill="#CBD5E1" stroke="#64748B" strokeWidth="1.1" />
        <line x1="77" y1="8.5" x2="77" y2="19.5" stroke="#64748B" strokeWidth="1" />
        <line x1="82" y1="8.5" x2="82" y2="19.5" stroke="#64748B" strokeWidth="1" />
        <line x1="87" y1="8.5" x2="87" y2="19.5" stroke="#64748B" strokeWidth="1" />
        <rect x="90" y="8" width="3.5" height="12" fill={baseColors.primary} />
        <polygon points="93.5,8.5 109,12 109,16 93.5,19.5" fill="#E2E8F0" stroke="#475569" strokeWidth="1.1" />
        <rect x="109" y="12.5" width="6" height="3" fill="#64748B" />
        <rect x="115" y="13.3" width="3" height="1.4" fill="#1E293B" />
      </svg>
    );
  }

  if (penId === 'rollerball') {
    return (
      <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
        {renderSvgDefs()}
        <rect x="4" y="9.5" width="9" height="9" rx="3" fill="#CBD5E1" stroke="#475569" strokeWidth="1.1" />
        <rect x="11" y="7.5" width="80" height="13" rx="5" fill={primary} stroke={dark} strokeWidth="1.4" />
        {renderBarrelOverlay(11, 7.5, 80, 13, 5)}
        <rect x="16" y="4.8" width="28" height="3" rx="1.4" fill="#F8FAFC" stroke="#334155" strokeWidth="0.9" />
        <rect x="52" y="7.5" width="3" height="13" fill="#F8FAFC" />
        <rect x="69" y="7.5" width="20" height="13" fill="#0F172A" />
        <rect x="88" y="7.5" width="3.5" height="13" fill={baseColors.primary} />
        <path d="M91.5,8.5 Q104,9.5 114,13 L114,15 Q104,18.5 91.5,19.5 Z" fill="#E2E8F0" stroke="#334155" strokeWidth="1.2" />
        <circle cx="114.5" cy="14" r="1.8" fill={baseColors.primary} />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 120 28" className={className} aria-hidden="true">
      {renderSvgDefs()}
      <rect
        x="6"
        y="5.5"
        width="84"
        height="17"
        rx="5"
        fill={isCustom ? primary : '#F8FAFC'}
        stroke={isCustom ? dark : '#334155'}
        strokeWidth="1.6"
      />
      {!isCustom && (
        <>
          <rect x="6" y="6" width="14" height="16" rx="4" fill={primary} />
          <rect x="24" y="7" width="54" height="5.5" fill={primary} />
        </>
      )}
      {renderBarrelOverlay(6, 5.5, 84, 17, 5)}
      <rect x="90" y="8" width="9" height="12" fill={isCustom ? baseColors.primary : '#334155'} />
      <polygon points="99,9.5 113,11 113,17 99,18.5" fill={primary} stroke={dark} strokeWidth="1.2" />
    </svg>
  );
}
