import { useEffect } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  ArrowLeft,
  Award,
  HelpCircle,
  Info,
  LogIn,
  LogOut,
  Settings,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import { AudioSettings } from '../game/audio';
import { LeaderboardEntry, sanitizeDisplayName } from '../game/leaderboard';
import { AudioControls } from './AudioControls';

interface SettingsScreenProps {
  audioSettings: AudioSettings;
  user: FirebaseUser | null;
  authReady: boolean;
  authLoading: boolean;
  authError: string | null;
  myEntry: LeaderboardEntry | null;
  onUpdateAudioSettings: (patch: Partial<AudioSettings>) => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onOpenLeaderboards: () => void;
  onBack: () => void;
}

export function SettingsScreen({
  audioSettings,
  user,
  authReady,
  authLoading,
  authError,
  myEntry,
  onUpdateAudioSettings,
  onSignIn,
  onSignOut,
  onOpenLeaderboards,
  onBack,
}: SettingsScreenProps) {
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onBack();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onBack]);

  return (
    <div className="w-full max-w-4xl my-3 bg-[#FAF6EE] text-[#1E242B] rounded-xl border border-[#2A2520]/20 shadow-[0_24px_60px_rgba(0,0,0,0.55)] p-4 sm:p-6">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#2A2520]/10">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>

          <div>
            <h2
              className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              <Settings className="w-5 h-5 text-slate-700 shrink-0" />
              <span>Settings</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Audio tracks, game overview, help &amp; policy, and account session.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenLeaderboards}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
        >
          <Award className="w-3.5 h-3.5 text-amber-700" />
          <span>Global Leaderboards</span>
        </button>
      </div>

      <div className="mt-5 space-y-6">
        {/* 1. Audio Section */}
        <section aria-labelledby="settings-audio-heading">
          <div className="flex items-center gap-2 mb-2.5">
            <Volume2 className="w-4 h-4 text-[#1D4ED8] shrink-0" />
            <h3
              id="settings-audio-heading"
              className="text-sm font-bold text-slate-900"
            >
              Audio &amp; Background Music
            </h3>
          </div>
          <AudioControls settings={audioSettings} onChange={onUpdateAudioSettings} />
        </section>

        {/* 2. About Section */}
        <section
          aria-labelledby="settings-about-heading"
          className="pt-5 border-t border-[#2A2520]/10"
        >
          <div className="flex items-center gap-2 mb-2">
            <Info className="w-4 h-4 text-[#1D4ED8] shrink-0" />
            <h3
              id="settings-about-heading"
              className="text-sm font-bold text-slate-900"
            >
              About Desk Duel: Pen Fight
            </h3>
          </div>
          <div className="rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 p-4 space-y-2 text-xs text-slate-700 leading-relaxed">
            <p>
              <strong className="text-slate-900">Desk Duel: Pen Fight</strong> recreates the
              classic classroom tabletop game with 2D rigid-body capsule physics, spin
              impulse dynamics, and tactile wooden desk environments.
            </p>
            <p>
              Choose from six distinct writing instruments—Ballpoint Classic, Brass
              Fountain, Neon Gel Runner, Jumbo Felt Marker, Drafting Pencil, and Steel
              Rollerball—customize barrel finishes as you win rounds, challenge AI rivals
              or local friends, enter 4- or 8-player knockout tournaments, and climb the
              Global Leaderboards.
            </p>
          </div>
        </section>

        {/* 3. Help and Policy Section */}
        <section
          aria-labelledby="settings-help-heading"
          className="pt-5 border-t border-[#2A2520]/10"
        >
          <div className="flex items-center gap-2 mb-2.5">
            <HelpCircle className="w-4 h-4 text-[#1D4ED8] shrink-0" />
            <h3
              id="settings-help-heading"
              className="text-sm font-bold text-slate-900"
            >
              Help &amp; Policy
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 p-4 space-y-2">
              <div className="text-xs font-bold text-slate-900">
                How to Play &amp; Controls
              </div>
              <ul className="space-y-1.5 text-xs text-slate-700 leading-relaxed list-disc pl-4">
                <li>
                  Click and drag anywhere along your pen, then pull back to aim and set
                  flick strength.
                </li>
                <li>
                  Grabbing near the tip or cap imparts rotational spin for sweeping
                  knockouts.
                </li>
                <li>
                  Bank shots off erasers, sharpeners, and rulers, and adjust for periodic
                  ventilation fan gusts.
                </li>
                <li>
                  Press <span className="font-mono font-semibold text-slate-900">Esc</span>{' '}
                  during a match to pause, or{' '}
                  <span className="font-mono font-semibold text-slate-900">Space</span> /{' '}
                  <span className="font-mono font-semibold text-slate-900">Enter</span> to
                  skip instant replays.
                </li>
              </ul>
            </div>

            <div className="rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 p-4 space-y-2">
              <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span>Privacy &amp; Fair Play Policy</span>
              </div>
              <ul className="space-y-1.5 text-xs text-slate-700 leading-relaxed list-disc pl-4">
                <li>
                  Signing in with Google is optional and used only to save your public
                  callsign, signature pen, and ranked match statistics.
                </li>
                <li>
                  Email addresses and personal account details are never published or
                  stored on public leaderboard entries.
                </li>
                <li>
                  Audio preferences and unlocked custom pen finishes are stored locally on
                  your device.
                </li>
                <li>
                  Only completed <strong className="text-slate-900">vs AI</strong> and
                  human-played <strong className="text-slate-900">Tournament</strong>{' '}
                  matches count toward Global Leaderboards.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* 4. Account & Sign Out Section */}
        <section
          aria-labelledby="settings-account-heading"
          className="pt-5 border-t border-[#2A2520]/10"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 p-4">
            <div className="min-w-0">
              <h3
                id="settings-account-heading"
                className="text-xs font-bold text-slate-900"
              >
                Account Session
              </h3>
              {user ? (
                <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-600">
                  <span className="font-semibold text-slate-900 truncate max-w-[200px]">
                    {myEntry?.displayName ?? sanitizeDisplayName(user.displayName)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {myEntry?.totalWins ?? 0} Match Wins
                  </span>
                </div>
              ) : (
                <p className="mt-1 text-xs text-slate-600">
                  Signed out. Sign in with Google to sync ranked match wins to the Global
                  Leaderboards.
                </p>
              )}
              {authError && (
                <p className="mt-1.5 text-xs font-medium text-red-700">{authError}</p>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {user ? (
                <button
                  type="button"
                  onClick={onSignOut}
                  disabled={authLoading}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#DC2626] hover:bg-[#B91C1C] disabled:opacity-60 text-white text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{authLoading ? 'Signing Out...' : 'Sign Out'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onSignIn}
                  disabled={authLoading || !authReady}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] disabled:opacity-60 text-white text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>{authLoading ? 'Signing In...' : 'Sign in with Google'}</span>
                </button>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
