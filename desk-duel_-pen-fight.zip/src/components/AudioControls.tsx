import { Disc3, Music, Volume2, VolumeX } from 'lucide-react';
import {
  AudioSettings,
  gameAudio,
  MUSIC_TRACKS,
  MusicTrackId,
} from '../game/audio';

interface AudioControlsProps {
  settings: AudioSettings;
  onChange: (patch: Partial<AudioSettings>) => void;
}

export function AudioControls({ settings, onChange }: AudioControlsProps) {
  const effectiveMusicOn = !settings.masterMuted && settings.musicEnabled;
  const effectiveSfxOn = !settings.masterMuted && settings.sfxEnabled;

  const handleToggleMusic = () => {
    if (settings.masterMuted) {
      onChange({ masterMuted: false, musicEnabled: true });
    } else {
      onChange({ musicEnabled: !settings.musicEnabled });
    }
  };

  const handleToggleSfx = () => {
    const nextOn = settings.masterMuted ? true : !settings.sfxEnabled;
    onChange({
      masterMuted: false,
      sfxEnabled: nextOn,
    });
    if (nextOn) {
      setTimeout(() => gameAudio.playSfxPreview(), 20);
    }
  };

  const handleMusicVolume = (val: number) => {
    onChange({
      masterMuted: false,
      musicEnabled: val > 0,
      musicVolume: val,
    });
  };

  const handleSelectTrack = (musicTrack: MusicTrackId) => {
    onChange({
      masterMuted: false,
      musicEnabled: true,
      musicTrack,
    });
  };

  const handleSfxVolume = (val: number) => {
    onChange({
      masterMuted: false,
      sfxEnabled: val > 0,
      sfxVolume: val,
    });
  };

  return (
    <div className="rounded-lg bg-[#F1EAE0] border border-[#2A2520]/12 p-3.5 space-y-3.5 text-left">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold text-slate-800">Audio Controls</span>
        {settings.masterMuted && (
          <span className="text-[11px] font-semibold text-amber-700">Master Muted</span>
        )}
      </div>

      {/* Music Channel */}
      <div className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Music className="w-3.5 h-3.5 text-slate-600 shrink-0" />
            <span className="text-xs font-semibold text-slate-900">Background Music</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] font-mono font-semibold text-slate-600 tabular-nums w-9 text-right">
              {effectiveMusicOn ? `${Math.round(settings.musicVolume * 100)}%` : 'Off'}
            </span>
            <button
              type="button"
              onClick={handleToggleMusic}
              aria-pressed={effectiveMusicOn}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                effectiveMusicOn
                  ? 'bg-[#1D4ED8] text-white'
                  : 'bg-[#E2D9C6] text-slate-700 hover:bg-[#D7CCB6]'
              }`}
            >
              {effectiveMusicOn ? 'On' : 'Off'}
            </button>
          </div>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          step={1}
          aria-label="Background Music Volume"
          value={effectiveMusicOn ? Math.round(settings.musicVolume * 100) : 0}
          onChange={(e) => handleMusicVolume(Number(e.target.value) / 100)}
          className="w-full h-1.5 bg-[#D8CEBC] rounded-lg appearance-none cursor-pointer accent-[#1D4ED8]"
        />

        {/* Track Selector */}
        <div className="pt-1.5">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 mb-1.5">
            <Disc3 className="w-3 h-3 shrink-0" />
            <span>Music Track</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {MUSIC_TRACKS.map((track) => {
              const active = settings.musicTrack === track.id;
              return (
                <button
                  key={track.id}
                  type="button"
                  onClick={() => handleSelectTrack(track.id)}
                  aria-pressed={active}
                  className={`flex items-center justify-between gap-2 px-2.5 py-2 rounded-md border text-left transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#1D4ED8] border-[#1D4ED8] text-white'
                      : 'bg-[#FAF6EE] border-[#2A2520]/12 text-slate-800 hover:bg-[#E7DFCE]'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold truncate">{track.name}</div>
                    <div
                      className={`text-[10px] truncate ${
                        active ? 'text-blue-100' : 'text-slate-500'
                      }`}
                    >
                      {track.vibe}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Sound Effects Channel */}
      <div className="space-y-1.5 pt-2 border-t border-[#2A2520]/10">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              {effectiveSfxOn ? (
                <Volume2 className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              )}
              <span className="text-xs font-semibold text-slate-900">Sound Effects</span>
            </div>
            <div className="text-[11px] text-slate-500 pl-5.5">
              Flicks, impacts &amp; collisions
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] font-mono font-semibold text-slate-600 tabular-nums w-9 text-right">
              {effectiveSfxOn ? `${Math.round(settings.sfxVolume * 100)}%` : 'Off'}
            </span>
            <button
              type="button"
              onClick={handleToggleSfx}
              aria-pressed={effectiveSfxOn}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                effectiveSfxOn
                  ? 'bg-[#1D4ED8] text-white'
                  : 'bg-[#E2D9C6] text-slate-700 hover:bg-[#D7CCB6]'
              }`}
            >
              {effectiveSfxOn ? 'On' : 'Off'}
            </button>
          </div>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          step={1}
          aria-label="Sound Effects Volume"
          value={effectiveSfxOn ? Math.round(settings.sfxVolume * 100) : 0}
          onChange={(e) => handleSfxVolume(Number(e.target.value) / 100)}
          onPointerUp={() => {
            if (settings.sfxEnabled && settings.sfxVolume > 0) {
              gameAudio.playSfxPreview();
            }
          }}
          className="w-full h-1.5 bg-[#D8CEBC] rounded-lg appearance-none cursor-pointer accent-[#1D4ED8]"
        />
      </div>
    </div>
  );
}
