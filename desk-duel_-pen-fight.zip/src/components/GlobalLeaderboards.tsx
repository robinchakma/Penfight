import { FormEvent, useCallback, useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import {
  ArrowLeft,
  Check,
  Crown,
  Edit3,
  LogIn,
  LogOut,
  RefreshCw,
  Trophy,
  X,
} from 'lucide-react';
import { formatFirebaseQuotaOrAuthMessage } from '../firebase';
import { DEFAULT_P1_CUSTOM, PEN_CLASSES } from '../game/constants';
import {
  DISPLAY_NAME_MAX_LENGTH,
  fetchPlayerLeaderboardEntry,
  fetchTopLeaderboard,
  LeaderboardEntry,
  sanitizeDisplayName,
  subscribeTopLeaderboard,
  updatePlayerLeaderboardProfile,
} from '../game/leaderboard';
import { PenClassId } from '../game/types';
import { PenPreviewIcon } from './PenPreviewIcon';

interface GlobalLeaderboardsProps {
  user: User | null;
  authReady: boolean;
  authLoading: boolean;
  authError: string | null;
  selectedPen: PenClassId;
  myEntry: LeaderboardEntry | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onProfileUpdated: (entry: LeaderboardEntry) => void;
  onBack: () => void;
}

function formatWinRate(wins: number, losses: number): string {
  const total = wins + losses;
  if (total <= 0) return '—';
  return `${Math.round((wins / total) * 100)}%`;
}

export function GlobalLeaderboards({
  user,
  authReady,
  authLoading,
  authError,
  selectedPen,
  myEntry,
  onSignIn,
  onSignOut,
  onProfileUpdated,
  onBack,
}: GlobalLeaderboardsProps) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [editingName, setEditingName] = useState(false);
  const [draftName, setDraftName] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileNotice, setProfileNotice] = useState<string | null>(null);

  const loadSnapshotOnce = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const list = await fetchTopLeaderboard(25);
      setEntries(list);
    } catch (err) {
      setErrorMsg(formatFirebaseQuotaOrAuthMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authReady) return;

    if (user) {
      setLoading(true);
      setErrorMsg(null);
      const unsubscribe = subscribeTopLeaderboard(
        25,
        (nextEntries) => {
          setEntries(nextEntries);
          setLoading(false);
          setErrorMsg(null);
        },
        (err) => {
          setErrorMsg(formatFirebaseQuotaOrAuthMessage(err));
          setLoading(false);
        }
      );
      return () => unsubscribe();
    }

    void loadSnapshotOnce();
  }, [authReady, user, loadSnapshotOnce]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (editingName) {
          e.preventDefault();
          setEditingName(false);
          return;
        }
        e.preventDefault();
        onBack();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [editingName, onBack]);

  const handleOpenEdit = () => {
    setDraftName(myEntry?.displayName ?? sanitizeDisplayName(user?.displayName));
    setProfileNotice(null);
    setEditingName(true);
  };

  const handleSaveProfile = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const cleanName = sanitizeDisplayName(draftName, user.displayName);
    setSavingProfile(true);
    setProfileNotice(null);
    try {
      await updatePlayerLeaderboardProfile(user.uid, cleanName, selectedPen);
      const refreshed = await fetchPlayerLeaderboardEntry(user.uid);
      if (refreshed) {
        onProfileUpdated(refreshed);
      }
      setEditingName(false);
      setProfileNotice('Callsign & signature pen updated.');
    } catch (err) {
      setProfileNotice(formatFirebaseQuotaOrAuthMessage(err));
    } finally {
      setSavingProfile(false);
    }
  };

  const myTopIndex = user ? entries.findIndex((item) => item.uid === user.uid) : -1;
  const myRankLabel =
    myTopIndex >= 0
      ? `#${myTopIndex + 1}`
      : myEntry
        ? 'Outside Top 25'
        : 'Unranked';

  return (
    <div className="w-full max-w-4xl my-3 bg-[#FAF6EE] text-[#1E242B] rounded-xl border border-[#2A2520]/20 shadow-[0_24px_60px_rgba(0,0,0,0.55)] p-4 sm:p-6">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#2A2520]/10">
        <div className="flex items-start gap-3">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Settings</span>
          </button>

          <div>
            <h2
              className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              <Trophy className="w-5 h-5 text-amber-600 shrink-0" />
              <span>Global Leaderboards</span>
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Top players ranked by total match wins across vs AI and Tournament modes.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {!user && (
            <button
              type="button"
              onClick={() => void loadSnapshotOnce()}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] disabled:opacity-60 text-slate-800 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          )}

          {user ? (
            <button
              type="button"
              onClick={onSignOut}
              disabled={authLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-800 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onSignIn}
              disabled={authLoading || !authReady}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] disabled:opacity-60 text-white text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{authLoading ? 'Signing In...' : 'Sign in with Google'}</span>
            </button>
          )}
        </div>
      </div>

      {authError && (
        <div className="mt-3 p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-800">
          {authError}
        </div>
      )}

      {/* Player Standing Strip */}
      <div className="mt-4 p-3.5 rounded-lg bg-[#F4EFE4] border border-[#2A2520]/10">
        {user ? (
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="min-w-0">
              {editingName ? (
                <form onSubmit={handleSaveProfile} className="flex flex-wrap items-center gap-2">
                  <label htmlFor="callsign-input" className="sr-only">
                    Leaderboard Callsign
                  </label>
                  <input
                    id="callsign-input"
                    type="text"
                    value={draftName}
                    maxLength={DISPLAY_NAME_MAX_LENGTH}
                    onChange={(e) => setDraftName(e.target.value)}
                    placeholder="Enter callsign"
                    className="px-2.5 py-1.5 rounded-md bg-white border border-slate-300 text-xs font-semibold text-slate-900 focus:outline-2 focus:outline-blue-600 w-48"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={savingProfile}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white text-xs font-semibold cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{savingProfile ? 'Saving...' : 'Save'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingName(false)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#E5DEC9] hover:bg-[#D8CEB6] text-slate-800 text-xs font-semibold cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Cancel</span>
                  </button>
                </form>
              ) : (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-bold text-slate-900 truncate">
                    {myEntry?.displayName ?? sanitizeDisplayName(user.displayName)}
                  </span>
                  <span aria-hidden="true" className="text-slate-400">
                    ·
                  </span>
                  <span className="text-xs font-semibold text-amber-800 font-mono tabular-nums">
                    Rank {myRankLabel}
                  </span>
                  <button
                    type="button"
                    onClick={handleOpenEdit}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md hover:bg-[#E6DEC9] text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>Edit Callsign</span>
                  </button>
                </div>
              )}

              <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-600 tabular-nums">
                <span>
                  <strong className="text-slate-900 font-mono">
                    {myEntry?.totalWins ?? 0}
                  </strong>{' '}
                  Wins
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong className="text-slate-900 font-mono">
                    {myEntry?.totalLosses ?? 0}
                  </strong>{' '}
                  Losses
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  Win Rate{' '}
                  <strong className="text-slate-900 font-mono">
                    {formatWinRate(myEntry?.totalWins ?? 0, myEntry?.totalLosses ?? 0)}
                  </strong>
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong className="text-slate-900 font-mono">
                    {myEntry?.ringOuts ?? 0}
                  </strong>{' '}
                  Ring-Outs
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong className="text-slate-900 font-mono">
                    {myEntry?.tournamentsWon ?? 0}
                  </strong>{' '}
                  Titles
                </span>
              </div>

              {profileNotice && (
                <div className="mt-1.5 text-xs font-medium text-slate-700">
                  {profileNotice}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <div className="px-2.5 py-1.5 rounded-md bg-[#C89B6E]/35 border border-[#784E28]/20">
                <PenPreviewIcon
                  penId={myEntry?.favoritePen ?? selectedPen}
                  player={1}
                  custom={DEFAULT_P1_CUSTOM}
                  className="w-24 h-5"
                />
              </div>
              <div className="text-xs text-slate-600">
                <div className="font-semibold text-slate-800">
                  {PEN_CLASSES[myEntry?.favoritePen ?? selectedPen].name}
                </div>
                <div className="text-[11px]">Signature Pen</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-slate-900">
                Track Your Career Record
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Sign in with Google to save match wins, knockouts, and tournament crowns to the global rankings.
              </p>
            </div>
            <button
              type="button"
              onClick={onSignIn}
              disabled={authLoading || !authReady}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] disabled:opacity-60 text-white text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{authLoading ? 'Signing In...' : 'Sign In to Compete'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Leaderboard Table */}
      <div className="mt-4">
        {loading ? (
          <div className="space-y-2 py-4">
            {[1, 2, 3, 4, 5].map((row) => (
              <div
                key={row}
                className="h-11 rounded-lg bg-[#EDE6D8]/70 animate-pulse"
              />
            ))}
          </div>
        ) : errorMsg ? (
          <div className="p-5 rounded-lg bg-[#F4EFE4] border border-red-300/60 text-center">
            <p className="text-sm font-semibold text-slate-900">
              Unable to Load Global Leaderboards
            </p>
            <p className="mt-1 text-xs text-slate-600 max-w-lg mx-auto break-words">
              {errorMsg}
            </p>
            <button
              type="button"
              onClick={() => void loadSnapshotOnce()}
              className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        ) : entries.length === 0 ? (
          <div className="p-8 rounded-lg bg-[#F4EFE4] border border-[#2A2520]/10 text-center">
            <Trophy className="w-8 h-8 text-amber-600 mx-auto mb-2" />
            <div className="text-sm font-bold text-slate-900">
              No Ranked Challengers Yet
            </div>
            <p className="mt-1 text-xs text-slate-600 max-w-md mx-auto">
              Sign in with Google and win a vs AI match or Tournament to claim the #1 spot on the desk.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-[#2A2520]/12 bg-[#FFFDF8]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#2A2520]/10 bg-[#F4EFE4] text-[11px] font-semibold text-slate-600">
                  <th className="py-2.5 pl-3.5 pr-2 w-14">Rank</th>
                  <th className="py-2.5 px-2">Player</th>
                  <th className="py-2.5 px-2 hidden sm:table-cell">Signature Pen</th>
                  <th className="py-2.5 px-2 text-right">Match Wins</th>
                  <th className="py-2.5 px-2 text-right hidden md:table-cell">Record</th>
                  <th className="py-2.5 px-2 text-right hidden sm:table-cell">Knockouts</th>
                  <th className="py-2.5 pl-2 pr-3.5 text-right">Titles</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2A2520]/8 text-xs">
                {entries.map((entry, idx) => {
                  const rank = idx + 1;
                  const isMe = user?.uid === entry.uid;
                  const rankTone =
                    rank === 1
                      ? 'text-amber-700 font-bold'
                      : rank === 2
                        ? 'text-slate-600 font-bold'
                        : rank === 3
                          ? 'text-orange-700 font-bold'
                          : 'text-slate-500 font-semibold';

                  return (
                    <tr
                      key={entry.uid}
                      className={
                        isMe
                          ? 'bg-blue-50/75'
                          : 'hover:bg-[#F7F2E7]/70 transition-colors'
                      }
                    >
                      <td className={`py-2.5 pl-3.5 pr-2 font-mono tabular-nums ${rankTone}`}>
                        <span className="inline-flex items-center gap-1">
                          {rank === 1 && (
                            <Crown className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          )}
                          <span>#{rank}</span>
                        </span>
                      </td>

                      <td className="py-2.5 px-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="font-bold text-slate-900 truncate max-w-[160px] sm:max-w-[220px]">
                            {entry.displayName}
                          </span>
                          {isMe && (
                            <span className="text-[11px] font-semibold text-blue-700 shrink-0">
                              (You)
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 sm:hidden">
                          {PEN_CLASSES[entry.favoritePen].name} · {entry.ringOuts} KOs
                        </div>
                      </td>

                      <td className="py-2.5 px-2 hidden sm:table-cell">
                        <div className="flex items-center gap-2">
                          <PenPreviewIcon
                            penId={entry.favoritePen}
                            player={1}
                            custom={DEFAULT_P1_CUSTOM}
                            className="w-16 h-4 shrink-0"
                          />
                          <span className="text-slate-700 whitespace-nowrap">
                            {PEN_CLASSES[entry.favoritePen].name}
                          </span>
                        </div>
                      </td>

                      <td className="py-2.5 px-2 text-right font-mono font-bold text-slate-950 tabular-nums">
                        {entry.totalWins}
                      </td>

                      <td className="py-2.5 px-2 text-right font-mono text-slate-600 tabular-nums hidden md:table-cell whitespace-nowrap">
                        {entry.totalWins}W–{entry.totalLosses}L ·{' '}
                        {formatWinRate(entry.totalWins, entry.totalLosses)}
                      </td>

                      <td className="py-2.5 px-2 text-right font-mono text-slate-700 tabular-nums hidden sm:table-cell">
                        {entry.ringOuts}
                      </td>

                      <td className="py-2.5 pl-2 pr-3.5 text-right font-mono font-semibold text-slate-800 tabular-nums">
                        {entry.tournamentsWon}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
