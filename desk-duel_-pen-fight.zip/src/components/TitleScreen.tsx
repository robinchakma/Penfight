import { useEffect, useState } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  Bot,
  Compass,
  Lock,
  Paintbrush,
  Play,
  Settings,
  Shield,
  Sparkles,
  Swords,
  Trophy,
  Unlock,
  User,
  Users,
  Wind,
} from 'lucide-react';
import { AudioSettings } from '../game/audio';
import {
  CUSTOM_PEN_COLORS,
  getCustomColorPreset,
  getWinsNeeded,
  PEN_CLASS_LIST,
  PEN_CLASSES,
  PEN_PATTERNS,
  PEN_TEXTURES,
  PLAYER_COLORS,
  ROUND_OPTIONS,
} from '../game/constants';
import { LeaderboardEntry } from '../game/leaderboard';
import { applyTournamentPreset } from '../game/tournament';
import {
  AIDifficulty,
  ArenaMode,
  GameMode,
  MatchConfig,
  PenClassId,
  PenCustomization,
  PenPatternId,
  PenStyleMode,
  PenTextureId,
  TournamentEntrant,
  TournamentSize,
} from '../game/types';
import { GlobalLeaderboards } from './GlobalLeaderboards';
import { PenPreviewIcon } from './PenPreviewIcon';
import { SettingsScreen } from './SettingsScreen';

interface TitleScreenProps {
  config: MatchConfig;
  audioSettings: AudioSettings;
  unlockedCustomClasses: Record<PenClassId, boolean>;
  user: FirebaseUser | null;
  authReady: boolean;
  authLoading: boolean;
  authError: string | null;
  myLeaderboardEntry: LeaderboardEntry | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onLeaderboardProfileUpdated: (entry: LeaderboardEntry) => void;
  onUnlockCustomClass: (penId: PenClassId) => void;
  onUpdateAudioSettings: (patch: Partial<AudioSettings>) => void;
  onChangeConfig: (next: MatchConfig) => void;
  onStartMatch: () => void;
}

export function TitleScreen({
  config,
  audioSettings,
  unlockedCustomClasses,
  user,
  authReady,
  authLoading,
  authError,
  myLeaderboardEntry,
  onSignIn,
  onSignOut,
  onLeaderboardProfileUpdated,
  onUnlockCustomClass,
  onUpdateAudioSettings,
  onChangeConfig,
  onStartMatch,
}: TitleScreenProps) {
  const [subView, setSubView] = useState<'setup' | 'settings' | 'leaderboards'>('setup');
  const [editingPlayer, setEditingPlayer] = useState<1 | 2>(1);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (subView !== 'setup') {
        return;
      }
      if (e.key === 'Enter' || e.key === ' ') {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === 'BUTTON' || tag === 'INPUT' || tag === 'SELECT') return;
        e.preventDefault();
        onStartMatch();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onStartMatch, subView]);

  const setMode = (mode: GameMode) => onChangeConfig({ ...config, mode });
  const setDifficulty = (aiDifficulty: AIDifficulty) =>
    onChangeConfig({ ...config, aiDifficulty });
  const setTournamentSize = (tournamentSize: TournamentSize) =>
    onChangeConfig({ ...config, tournamentSize });
  const setArenaMode = (arenaMode: ArenaMode) => onChangeConfig({ ...config, arenaMode });
  const toggleFanHazard = () =>
    onChangeConfig({ ...config, fanEnabled: !config.fanEnabled });
  const setTotalRounds = (totalRounds: number) =>
    onChangeConfig({ ...config, totalRounds });
  const winsNeeded = getWinsNeeded(config.totalRounds);
  const isFreeplay = config.mode === 'freeplay';
  const isTournament = config.mode === 'tournament';

  const setP1Pen = (p1Pen: PenClassId) => {
    const styleMode: PenStyleMode =
      isFreeplay || unlockedCustomClasses[p1Pen] ? config.p1Custom.styleMode : 'standard';
    const nextCustom = { ...config.p1Custom, styleMode };
    const nextEntrants = config.tournamentEntrants.map((ent, idx) =>
      idx === 0 ? { ...ent, penClass: p1Pen, custom: nextCustom } : ent
    );
    onChangeConfig({
      ...config,
      p1Pen,
      p1Custom: nextCustom,
      tournamentEntrants: nextEntrants,
    });
  };
  const setP2Pen = (p2Pen: PenClassId) => {
    const styleMode: PenStyleMode =
      isFreeplay || unlockedCustomClasses[p2Pen] ? config.p2Custom.styleMode : 'standard';
    onChangeConfig({
      ...config,
      p2Pen,
      p2Custom: { ...config.p2Custom, styleMode },
    });
  };

  const activePenId = editingPlayer === 1 || isTournament ? config.p1Pen : config.p2Pen;
  const activeCustom = editingPlayer === 1 || isTournament ? config.p1Custom : config.p2Custom;
  const activeClassUnlocked = isFreeplay || unlockedCustomClasses[activePenId];

  const updateActiveCustom = (patch: Partial<PenCustomization>) => {
    if (editingPlayer === 1 || isTournament) {
      const nextCustom = { ...config.p1Custom, ...patch };
      const nextEntrants = config.tournamentEntrants.map((ent, idx) =>
        idx === 0 ? { ...ent, custom: nextCustom } : ent
      );
      onChangeConfig({
        ...config,
        p1Custom: nextCustom,
        tournamentEntrants: nextEntrants,
      });
    } else {
      onChangeConfig({ ...config, p2Custom: { ...config.p2Custom, ...patch } });
    }
  };

  const updateTournamentEntrant = (index: number, patch: Partial<TournamentEntrant>) => {
    const nextEntrants = config.tournamentEntrants.map((ent, idx) =>
      idx === index ? { ...ent, ...patch } : ent
    );
    const updatedSeed1 = nextEntrants[0];
    onChangeConfig({
      ...config,
      tournamentEntrants: nextEntrants,
      p1Pen: updatedSeed1 ? updatedSeed1.penClass : config.p1Pen,
    });
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-between p-4 sm:p-6 bg-slate-950/45 overflow-y-auto">
      {/* Top Utility Bar: Only Settings button on Home Page */}
      <div className="w-full max-w-5xl flex items-center justify-end pt-1">
        <button
          type="button"
          onClick={() =>
            setSubView((prev) => (prev === 'settings' ? 'setup' : 'settings'))
          }
          className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold border shadow-sm whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
            subView === 'settings'
              ? 'bg-slate-900 hover:bg-slate-800 text-white border-slate-900'
              : 'bg-[#FAF6EE] hover:bg-[#EFE7D6] text-slate-900 border-[#2A2520]/20'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>{subView === 'settings' ? 'Close Settings' : 'Settings'}</span>
        </button>
      </div>

      {/* Top Bespoke Inline SVG Title Lockup */}
      <div className="w-full max-w-5xl flex flex-col items-center">
        <div className="flex items-center gap-3 mb-2">
          <svg
            viewBox="0 0 64 40"
            className="w-12 h-8 sm:w-14 sm:h-9 shrink-0 drop-shadow-md"
            aria-hidden="true"
          >
            <g transform="translate(32 20) rotate(-24)">
              <rect x="-26" y="-4" width="40" height="8" rx="3" fill="#1D4ED8" stroke="#FAF6EE" strokeWidth="1.5" />
              <polygon points="14,-4 26,0 14,4" fill="#F3D478" stroke="#FAF6EE" strokeWidth="1.2" />
            </g>
            <g transform="translate(32 20) rotate(24)">
              <rect x="-26" y="-4" width="40" height="8" rx="3" fill="#DC2626" stroke="#FAF6EE" strokeWidth="1.5" />
              <polygon points="14,-4 26,0 14,4" fill="#F3D478" stroke="#FAF6EE" strokeWidth="1.2" />
            </g>
          </svg>
          <span className="text-xs sm:text-sm font-semibold tracking-wide text-amber-200">
            {isFreeplay
              ? 'Free Play Tabletop Sandbox'
              : isTournament
                ? `${config.tournamentSize}-Player Knockout Bracket`
                : config.totalRounds === 1
                  ? 'Single-Round Tabletop Clash'
                  : `Best of ${config.totalRounds} Tabletop Clash`}
          </span>
        </div>

        <h1
          className="text-center font-bold tracking-tight text-[#FAF6EE] drop-shadow-[0_3px_10px_rgba(0,0,0,0.65)]"
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2.1rem, 4.5vw, 3.6rem)',
            lineHeight: 1.04,
            textWrap: 'balance',
          }}
        >
          Desk Duel: Pen Fight
        </h1>
        <p className="mt-1.5 text-sm sm:text-base text-slate-200 text-center max-w-xl">
          Flick off-center for spin, bank off classroom stationery, and knock your rival off the oak desk.
        </p>
      </div>

      {/* Central Match Setup Sheet OR Settings Screen OR Global Leaderboards Screen */}
      {subView === 'settings' ? (
        <SettingsScreen
          audioSettings={audioSettings}
          user={user}
          authReady={authReady}
          authLoading={authLoading}
          authError={authError}
          myEntry={myLeaderboardEntry}
          onUpdateAudioSettings={onUpdateAudioSettings}
          onSignIn={onSignIn}
          onSignOut={onSignOut}
          onOpenLeaderboards={() => setSubView('leaderboards')}
          onBack={() => setSubView('setup')}
        />
      ) : subView === 'leaderboards' ? (
        <GlobalLeaderboards
          user={user}
          authReady={authReady}
          authLoading={authLoading}
          authError={authError}
          selectedPen={config.p1Pen}
          myEntry={myLeaderboardEntry}
          onSignIn={onSignIn}
          onSignOut={onSignOut}
          onProfileUpdated={onLeaderboardProfileUpdated}
          onBack={() => setSubView('settings')}
        />
      ) : (
      <div className="w-full max-w-4xl my-3 bg-[#FAF6EE] text-[#1E242B] rounded-xl border border-[#2A2520]/20 shadow-[0_24px_60px_rgba(0,0,0,0.55)] p-4 sm:p-6">
        {/* Top Row: Match Mode, AI Difficulty / Bracket Size, Arena Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b border-[#2A2520]/10">
          {/* Play Mode */}
          <div>
            <div className="text-xs font-semibold text-slate-600 mb-2">Play Mode</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-2 gap-1 p-1 bg-[#EDE6D8] rounded-lg">
              <button
                type="button"
                onClick={() => setMode('ai')}
                className={`flex items-center justify-center gap-1 px-2 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.mode === 'ai'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Bot className="w-3.5 h-3.5 shrink-0" />
                <span>vs AI</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('local')}
                className={`flex items-center justify-center gap-1 px-2 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.mode === 'local'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5 shrink-0" />
                <span>2P Local</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('tournament')}
                className={`flex items-center justify-center gap-1 px-2 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.mode === 'tournament'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Trophy className="w-3.5 h-3.5 shrink-0" />
                <span>Tournament</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('freeplay')}
                className={`flex items-center justify-center gap-1 px-2 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.mode === 'freeplay'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Compass className="w-3.5 h-3.5 shrink-0" />
                <span>Free Play</span>
              </button>
            </div>
          </div>

          {/* AI Difficulty / Bracket Size / Turn Format */}
          <div>
            <div className="text-xs font-semibold text-slate-600 mb-2">
              {config.mode === 'ai'
                ? 'AI Difficulty'
                : config.mode === 'tournament'
                  ? 'Bracket Size'
                  : config.mode === 'freeplay'
                    ? 'Sandbox Mode'
                    : 'Turn Format'}
            </div>
            {config.mode === 'ai' ? (
              <div className="grid grid-cols-3 gap-1 p-1 bg-[#EDE6D8] rounded-lg">
                {(['easy', 'medium', 'hard'] as AIDifficulty[]).map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setDifficulty(diff)}
                    className={`px-2 py-2 rounded-md text-xs font-semibold capitalize whitespace-nowrap transition-colors cursor-pointer ${
                      config.aiDifficulty === diff
                        ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            ) : config.mode === 'tournament' ? (
              <div className="grid grid-cols-2 gap-1 p-1 bg-[#EDE6D8] rounded-lg">
                {([4, 8] as TournamentSize[]).map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setTournamentSize(size)}
                    className={`px-2 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                      config.tournamentSize === size
                        ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {size} Players
                  </button>
                ))}
              </div>
            ) : config.mode === 'freeplay' ? (
              <div className="px-3 py-2.5 rounded-lg bg-[#EDE6D8]/70 text-xs font-medium text-slate-700 truncate">
                No Scoring · Edges Auto-Respawn
              </div>
            ) : (
              <div className="px-3 py-2.5 rounded-lg bg-[#EDE6D8]/70 text-xs font-medium text-slate-700">
                Pass & Play · Alternating Flicks
              </div>
            )}
          </div>

          {/* Desk Layout & Ventilation Fan */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-600">Desk Setup</span>
              <button
                type="button"
                onClick={toggleFanHazard}
                aria-pressed={config.fanEnabled}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                  config.fanEnabled
                    ? 'bg-sky-100 text-sky-900 border border-sky-300'
                    : 'bg-[#EDE6D8] text-slate-600 hover:text-slate-900 border border-transparent'
                }`}
              >
                <Wind className="w-3 h-3 shrink-0" />
                <span>Vent Fan: {config.fanEnabled ? 'On' : 'Off'}</span>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#EDE6D8] rounded-lg">
              <button
                type="button"
                onClick={() => setArenaMode('clean')}
                className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.arenaMode === 'clean'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Swords className="w-3.5 h-3.5 shrink-0" />
                <span>Clean Desk</span>
              </button>
              <button
                type="button"
                onClick={() => setArenaMode('obstacles')}
                className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  config.arenaMode === 'obstacles'
                    ? 'bg-[#FAF6EE] text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Shield className="w-3.5 h-3.5 shrink-0" />
                <span>Obstacles</span>
              </button>
            </div>
          </div>
        </div>

        {/* Match Rounds Selector (1-10) */}
        <div className="py-3.5 border-b border-[#2A2520]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-700">
              {isFreeplay ? 'Free Play Rules' : 'Match Rounds'}
            </span>
            <span aria-hidden="true" className="text-slate-400">
              ·
            </span>
            <span className="text-slate-500 tabular-nums">
              {isFreeplay
                ? 'Unlimited flicks · Switch pen classes & textures live on the desk'
                : config.totalRounds === 1
                  ? 'Single Round · First to 1'
                  : `Best of ${config.totalRounds} · First to ${winsNeeded}`}
            </span>
          </div>
          {!isFreeplay && (
            <div
              className="grid grid-cols-5 sm:grid-cols-10 gap-1 p-1 bg-[#EDE6D8] rounded-lg"
              role="group"
              aria-label="Select match rounds from 1 to 10"
            >
              {ROUND_OPTIONS.map((num) => {
                const active = config.totalRounds === num;
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setTotalRounds(num)}
                    aria-pressed={active}
                    className={`min-w-[34px] h-8 px-2 rounded-md font-mono text-xs font-bold tabular-nums transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#1D4ED8] text-white shadow-sm'
                        : 'text-slate-700 hover:bg-[#FAF6EE]/70 hover:text-slate-900'
                    }`}
                  >
                    {num}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Pen Class Selection OR Tournament Bracket Roster */}
        {isTournament ? (
          <div className="pt-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                <Trophy className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{config.tournamentSize}-Player Bracket Roster</span>
                <span className="text-xs font-normal text-slate-500">
                  · {config.tournamentSize === 4 ? 'Semifinals & Final' : 'Quarterfinals, Semis & Final'}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1 p-0.5 bg-[#EDE6D8] rounded-md">
                  <button
                    type="button"
                    onClick={() =>
                      onChangeConfig({
                        ...config,
                        tournamentEntrants: applyTournamentPreset(
                          config.tournamentEntrants,
                          'solo_ai'
                        ),
                      })
                    }
                    className="px-2.5 py-1 rounded text-xs font-semibold text-slate-700 hover:bg-[#FAF6EE] hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    1 Human + AI
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onChangeConfig({
                        ...config,
                        tournamentEntrants: applyTournamentPreset(
                          config.tournamentEntrants,
                          'all_human'
                        ),
                      })
                    }
                    className="px-2.5 py-1 rounded text-xs font-semibold text-slate-700 hover:bg-[#FAF6EE] hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    All Human
                  </button>
                </div>

                {config.tournamentEntrants
                  .slice(0, config.tournamentSize)
                  .some((e) => e.isAI) && (
                  <div className="flex items-center gap-1 p-0.5 bg-[#EDE6D8] rounded-md">
                    {(['easy', 'medium', 'hard'] as AIDifficulty[]).map((diff) => (
                      <button
                        key={diff}
                        type="button"
                        onClick={() => setDifficulty(diff)}
                        className={`px-2 py-1 rounded text-[11px] font-semibold capitalize transition-colors cursor-pointer ${
                          config.aiDifficulty === diff
                            ? 'bg-[#FAF6EE] text-slate-900 shadow-xs'
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        {diff} AI
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {config.tournamentEntrants.slice(0, config.tournamentSize).map((ent, idx) => (
                <div
                  key={ent.id}
                  className="p-2.5 rounded-lg bg-[#F4EFE4] border border-[#2A2520]/12 flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="text-[11px] font-mono font-bold text-slate-500 tabular-nums shrink-0">
                      #{idx + 1}
                    </span>
                    <input
                      type="text"
                      value={ent.name}
                      maxLength={14}
                      aria-label={`Seed ${idx + 1} name`}
                      onChange={(e) =>
                        updateTournamentEntrant(idx, { name: e.target.value })
                      }
                      className="min-w-0 flex-1 px-1.5 py-0.5 rounded bg-[#FAF6EE] border border-[#2A2520]/15 text-xs font-semibold text-slate-900 focus:outline-none focus:border-[#1D4ED8]"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        updateTournamentEntrant(idx, { isAI: !ent.isAI })
                      }
                      aria-label={`Toggle Seed ${idx + 1} human or AI`}
                      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold shrink-0 cursor-pointer transition-colors ${
                        ent.isAI
                          ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                          : 'bg-blue-100 text-blue-900 hover:bg-blue-200'
                      }`}
                    >
                      {ent.isAI ? (
                        <>
                          <Bot className="w-2.5 h-2.5" />
                          <span>AI</span>
                        </>
                      ) : (
                        <>
                          <User className="w-2.5 h-2.5" />
                          <span>Human</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-1">
                    {PEN_CLASS_LIST.map((pen) => {
                      const active = ent.penClass === pen.id;
                      const short =
                        pen.id === 'ballpoint'
                          ? 'Ball'
                          : pen.id === 'fountain'
                            ? 'Ftn'
                            : pen.id === 'gel'
                              ? 'Gel'
                              : pen.id === 'marker'
                                ? 'Mrk'
                                : pen.id === 'mechanical'
                                  ? 'Mech'
                                  : 'Roll';
                      return (
                        <button
                          key={pen.id}
                          type="button"
                          onClick={() => updateTournamentEntrant(idx, { penClass: pen.id })}
                          className={`py-1 rounded text-[10px] font-semibold transition-colors cursor-pointer ${
                            active
                              ? 'bg-slate-900 text-white'
                              : 'bg-[#E9E2D2] text-slate-700 hover:bg-[#DDD4C0]'
                          }`}
                        >
                          {short}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4">
          {/* Player 1 */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-bold text-slate-900">
                {isFreeplay ? 'Blue Pen' : 'Player 1'} ·{' '}
                <span style={{ color: PLAYER_COLORS[1].primary }}>Blue Ink</span>
              </span>
              <span className="text-xs text-slate-500">
                {isFreeplay ? 'Left slot' : 'Starts Round 1'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PEN_CLASS_LIST.map((pen) => {
                const selected = config.p1Pen === pen.id;
                return (
                  <button
                    key={pen.id}
                    type="button"
                    onClick={() => setP1Pen(pen.id)}
                    className={`text-left p-2.5 rounded-lg border transition-all cursor-pointer ${
                      selected
                        ? 'bg-blue-50/90 border-blue-600 ring-1 ring-blue-600'
                        : 'bg-[#F4EFE4] border-[#2A2520]/12 hover:border-[#2A2520]/30'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-900 truncate">{pen.name}</span>
                      <PenPreviewIcon
                        penId={pen.id}
                        player={1}
                        custom={
                          selected && (isFreeplay || unlockedCustomClasses[pen.id])
                            ? config.p1Custom
                            : undefined
                        }
                        className="w-16 h-4 shrink-0"
                      />
                    </div>
                    <div className="mt-1 text-[11px] text-slate-600">
                      {pen.weightLabel} · {pen.gripLabel} · {pen.speedLabel}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Player 2 / AI */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-bold text-slate-900">
                {config.mode === 'ai' ? 'AI Rival' : isFreeplay ? 'Red Pen' : 'Player 2'} ·{' '}
                <span style={{ color: PLAYER_COLORS[2].primary }}>Red Ink</span>
              </span>
              <span className="text-xs text-slate-500">
                {config.mode === 'ai'
                  ? `${config.aiDifficulty} bot`
                  : isFreeplay
                    ? 'Right slot'
                    : 'Opponent'}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PEN_CLASS_LIST.map((pen) => {
                const selected = config.p2Pen === pen.id;
                return (
                  <button
                    key={pen.id}
                    type="button"
                    onClick={() => setP2Pen(pen.id)}
                    className={`text-left p-2.5 rounded-lg border transition-all cursor-pointer ${
                      selected
                        ? 'bg-red-50/90 border-red-600 ring-1 ring-red-600'
                        : 'bg-[#F4EFE4] border-[#2A2520]/12 hover:border-[#2A2520]/30'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-900 truncate">{pen.name}</span>
                      <PenPreviewIcon
                        penId={pen.id}
                        player={2}
                        custom={
                          selected && (isFreeplay || unlockedCustomClasses[pen.id])
                            ? config.p2Custom
                            : undefined
                        }
                        className="w-16 h-4 shrink-0"
                      />
                    </div>
                    <div className="mt-1 text-[11px] text-slate-600">
                      {pen.weightLabel} · {pen.gripLabel} · {pen.speedLabel}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        )}

        {/* Pen Customizer Section */}
        <div className="mt-4 pt-4 border-t border-[#2A2520]/10">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <Paintbrush className="w-4 h-4 text-slate-700" />
              <span className="text-sm font-bold text-slate-900">Pen Customizer</span>
              <span className="text-xs text-slate-500">
                · {PEN_CLASSES[activePenId].name}
                {isTournament ? ' · Seed #1 Finish' : isFreeplay ? ' · Sandbox Preview Open' : ''}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Player Tabs (hidden in Tournament where Seed #1 is customized) */}
              {!isTournament && (
              <div className="flex items-center gap-1 p-0.5 bg-[#EDE6D8] rounded-md">
                <button
                  type="button"
                  onClick={() => setEditingPlayer(1)}
                  className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                    editingPlayer === 1
                      ? 'bg-[#FAF6EE] text-[#1D4ED8] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isFreeplay ? 'Blue Pen' : 'Player 1'}
                </button>
                <button
                  type="button"
                  onClick={() => setEditingPlayer(2)}
                  className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                    editingPlayer === 2
                      ? 'bg-[#FAF6EE] text-[#DC2626] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {config.mode === 'ai' ? 'AI Rival' : isFreeplay ? 'Red Pen' : 'Player 2'}
                </button>
              </div>
              )}

              {/* Standard vs Custom Visual Style Toggle */}
              <div className="flex items-center gap-1 p-0.5 bg-[#EDE6D8] rounded-md">
                <button
                  type="button"
                  onClick={() => updateActiveCustom({ styleMode: 'standard' })}
                  className={`px-2.5 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                    activeCustom.styleMode === 'standard'
                      ? 'bg-[#FAF6EE] text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Standard
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (activeClassUnlocked) {
                      updateActiveCustom({ styleMode: 'custom' });
                    } else {
                      updateActiveCustom({ styleMode: 'custom' });
                    }
                  }}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                    activeCustom.styleMode === 'custom'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {!activeClassUnlocked && <Lock className="w-3 h-3" />}
                  <span>Custom</span>
                </button>
              </div>
            </div>
          </div>

          {/* Customizer Body */}
          <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-4 items-center p-3 rounded-lg bg-[#F4EFE4] border border-[#2A2520]/10">
            {/* Live Wood-Tray Pen Preview */}
            <div className="flex flex-col items-center justify-center p-3 rounded-md bg-[#C89B6E]/45 border border-[#784E28]/25">
              <PenPreviewIcon
                penId={activePenId}
                player={editingPlayer}
                custom={activeClassUnlocked ? activeCustom : { ...activeCustom, styleMode: 'standard' }}
                className="w-44 h-10 drop-shadow-sm"
              />
              <div className="mt-1.5 text-[11px] font-medium text-slate-800 text-center">
                {activeCustom.styleMode === 'custom' && activeClassUnlocked
                  ? `${getCustomColorPreset(activeCustom.colorId).name} · ${
                      PEN_PATTERNS.find((p) => p.id === activeCustom.pattern)?.label
                    } · ${PEN_TEXTURES.find((t) => t.id === activeCustom.texture)?.label}`
                  : 'Standard Classroom Finish'}
              </div>
            </div>

            {/* Locked Prompt OR Color / Pattern / Texture Pickers */}
            {activeCustom.styleMode === 'custom' && !activeClassUnlocked ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 py-1">
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                    <span>Custom Visual Style Locked for {PEN_CLASSES[activePenId].name}</span>
                  </div>
                  <p className="mt-1 text-xs text-slate-600">
                    Win 1 round with {PEN_CLASSES[activePenId].name} in a match to unlock custom colors, patterns, and textures—or unlock it in the workshop now.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onUnlockCustomClass(activePenId);
                    updateActiveCustom({ styleMode: 'custom' });
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock Custom Style</span>
                </button>
              </div>
            ) : activeCustom.styleMode === 'standard' ? (
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 py-1">
                <div className="text-xs text-slate-600">
                  Switch style to <strong className="text-slate-900">Custom</strong> to personalize barrel color, racing patterns, and surface texture for {PEN_CLASSES[activePenId].name}.
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (!activeClassUnlocked) {
                      onUnlockCustomClass(activePenId);
                    }
                    updateActiveCustom({ styleMode: 'custom' });
                  }}
                  className="px-3.5 py-2 rounded-lg bg-[#EDE6D8] hover:bg-[#E2D9C6] text-slate-900 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                >
                  {activeClassUnlocked ? 'Customize Pen' : 'Unlock & Customize'}
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {/* Color Row */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-semibold text-slate-600 w-14 shrink-0">
                    Color
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {CUSTOM_PEN_COLORS.map((preset) => {
                      const active = activeCustom.colorId === preset.id;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          title={preset.name}
                          aria-label={`Color ${preset.name}`}
                          onClick={() => updateActiveCustom({ colorId: preset.id })}
                          className={`w-6 h-6 rounded-md border transition-transform cursor-pointer ${
                            active
                              ? 'ring-2 ring-offset-1 ring-slate-900 scale-105 border-white'
                              : 'border-black/20 hover:scale-105'
                          }`}
                          style={{ backgroundColor: preset.primary }}
                        />
                      );
                    })}
                  </div>
                </div>

                {/* Pattern Row */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-semibold text-slate-600 w-14 shrink-0">
                    Pattern
                  </span>
                  <div className="flex flex-wrap items-center gap-1">
                    {PEN_PATTERNS.map((pat) => (
                      <button
                        key={pat.id}
                        type="button"
                        onClick={() => updateActiveCustom({ pattern: pat.id as PenPatternId })}
                        className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                          activeCustom.pattern === pat.id
                            ? 'bg-slate-900 text-white'
                            : 'bg-[#E9E2D2] text-slate-700 hover:bg-[#DDD4C0]'
                        }`}
                      >
                        {pat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Texture Row */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-semibold text-slate-600 w-14 shrink-0">
                    Texture
                  </span>
                  <div className="flex flex-wrap items-center gap-1">
                    {PEN_TEXTURES.map((tex) => (
                      <button
                        key={tex.id}
                        type="button"
                        onClick={() => updateActiveCustom({ texture: tex.id as PenTextureId })}
                        className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer ${
                          activeCustom.texture === tex.id
                            ? 'bg-slate-900 text-white'
                            : 'bg-[#E9E2D2] text-slate-700 hover:bg-[#DDD4C0]'
                        }`}
                      >
                        {tex.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Row */}
        <div className="mt-4 pt-4 border-t border-[#2A2520]/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-600 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span>
              Tip: Grab near the tip or cap of your pen to whip it sideways and sweep your rival off the edge.
            </span>
          </div>
          <button
            type="button"
            onClick={onStartMatch}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 rounded-lg bg-[#1D4ED8] hover:bg-[#1E40AF] active:translate-y-px text-white font-bold text-sm shadow-md transition-all whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>
              {isFreeplay ? 'Enter Free Play' : isTournament ? 'Start Tournament' : 'Start Match'}
            </span>
          </button>
        </div>
      </div>
      )}

      {/* Single flat control-hint line */}
      <div className="pb-1 text-xs text-slate-300/90 text-center">
        {subView === 'settings'
          ? 'Configure Audio Tracks, About & Policy, or Account · Escape to Return Home'
          : subView === 'leaderboards'
            ? 'Global Rankings Updated Live · Escape to Return to Settings'
            : 'Click & Drag on Pen to Aim · Pull Back for Power · Off-Center Hits Add Spin · Enter to Start'}
      </div>
    </div>
  );
}
