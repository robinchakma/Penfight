import { useEffect, useRef } from 'react';
import { computeAIShot, AIShotPlan } from '../game/ai';
import { gameAudio } from '../game/audio';
import {
  createObstaclesForRound,
  createVentilationFanForRound,
  DESK_BOUNDS,
  getFanWindState,
  MIN_PULL_DISTANCE,
  PLAYER_COLORS,
  WORLD_HEIGHT,
  WORLD_WIDTH,
} from '../game/constants';
import {
  createInitialDeskDebris,
  createInitialDustMotes,
  stepDeskEnvironment,
  triggerEnvironmentDraft,
} from '../game/environment';
import {
  applyPenSpecAndCustom,
  computeFlickVelocities,
  createPenBody,
  projectPointOntoPen,
  stepPhysics,
} from '../game/physics';
import { tabletopRenderer } from '../game/renderer';
import {
  AchievementId,
  AimDragState,
  DeskDebris,
  DustMote,
  FanWindStatus,
  FlickReplayData,
  GameState,
  MatchConfig,
  MatchStats,
  ObstacleKind,
  Particle,
  PenBody,
  RoundEventType,
  StationeryObstacle,
  TrailSegment,
  TurnPhase,
  VentilationFan,
} from '../game/types';

const FIXED_DT = 1 / 180;
const REPLAY_TIME_SCALE = 0.35;
const REPLAY_AIM_DURATION = 0.6;
const REPLAY_HOLD_DURATION = 0.65;

interface PenFightArenaProps {
  gameState: GameState;
  config: MatchConfig;
  roundNumber: number;
  roundToken: number;
  replayToken: number;
  activeTurn: 1 | 2;
  turnPhase: TurnPhase;
  p1IsAI?: boolean;
  p2IsAI?: boolean;
  onTurnPhaseChange: (phase: TurnPhase) => void;
  onTurnAdvance: (nextTurn: 1 | 2) => void;
  onRoundResolved: (
    winner: 1 | 2 | 'draw',
    reason: string,
    eventType: RoundEventType,
    eventDetail: string
  ) => void;
  onReplayComplete: () => void;
  onRecordFlick: (shooter: 1 | 2) => void;
  onRecordImpact: (impulse: number) => void;
  onUnlockAchievement: (id: AchievementId) => void;
  onFanStatusChange?: (status: FanWindStatus) => void;
}

interface SimState {
  pens: PenBody[];
  obstacles: StationeryObstacle[];
  fan: VentilationFan | null;
  fanTime: number;
  lastFanStatus: FanWindStatus;
  particles: Particle[];
  trails: TrailSegment[];
  deskDebris: DeskDebris[];
  dustMotes: DustMote[];
  shavingSpawnTimer: number;
  aimDrag: AimDragState | null;
  hoverGrab: { x: number; y: number } | null;
  aiPlan: AIShotPlan | null;
  aiTimer: number;
  hitstopTimer: number;
  shakeMag: number;
  physicsAccum: number;
  droppedThisTurn: Array<1 | 2>;
  prevPenPositions: Record<number, { x: number; y: number }>;
  activePointerId: number | null;
  time: number;
  lastFlickReplay: FlickReplayData | null;
  replayPhase: 'idle' | 'aiming' | 'moving' | 'hold';
  replayTimer: number;
  replayFan: VentilationFan | null;
  replayFanTime: number;
  replayFinalSnapshot: {
    pens: PenBody[];
    obstacles: StationeryObstacle[];
  } | null;
  turnPenClashes: number;
  turnObstacleHits: Array<{ kind: ObstacleKind; penPlayer: 1 | 2; impulse: number }>;
  turnStartPenDist: number;
  turnLaunchOmega: number;
}

const OBSTACLE_LABELS: Record<ObstacleKind, string> = {
  eraser: 'Rubber Eraser',
  sharpener: 'Brass Sharpener',
  ruler: 'Acrylic Ruler',
};

function summarizeTurnOutcome(
  winner: 1 | 2 | 'draw',
  shooter: 1 | 2,
  penClashes: number,
  obstacleHits: Array<{ kind: ObstacleKind; penPlayer: 1 | 2; impulse: number }>
): { eventType: RoundEventType; eventDetail: string } {
  if (obstacleHits.length > 0) {
    if (winner !== 'draw') {
      const loser: 1 | 2 = winner === 1 ? 2 : 1;
      const loserObsHit = [...obstacleHits]
        .reverse()
        .find((hit) => hit.penPlayer === loser);
      if (loserObsHit) {
        return {
          eventType: 'Obstacle Hit',
          eventDetail: `Deflected off ${OBSTACLE_LABELS[loserObsHit.kind]}`,
        };
      }
      const shooterObsHit = [...obstacleHits]
        .reverse()
        .find((hit) => hit.penPlayer === shooter);
      if (shooterObsHit) {
        return {
          eventType: 'Obstacle Hit',
          eventDetail: `Banked off ${OBSTACLE_LABELS[shooterObsHit.kind]}`,
        };
      }
    }
    const lastHit = obstacleHits[obstacleHits.length - 1];
    return {
      eventType: 'Obstacle Hit',
      eventDetail: `Ricocheted off ${OBSTACLE_LABELS[lastHit.kind]}`,
    };
  }

  if (winner === 'draw') {
    return {
      eventType: 'Ring Out',
      eventDetail: 'Double edge drop-off',
    };
  }

  const loser: 1 | 2 = winner === 1 ? 2 : 1;
  if (penClashes > 0 && loser !== shooter) {
    return {
      eventType: 'Ring Out',
      eventDetail: 'Knocked off in direct clash',
    };
  }
  if (penClashes > 0 && loser === shooter) {
    return {
      eventType: 'Ring Out',
      eventDetail: 'Rebounded off rival over edge',
    };
  }
  return {
    eventType: 'Ring Out',
    eventDetail: 'Slid off the desk edge',
  };
}

function clonePens(pens: PenBody[]): PenBody[] {
  return pens.map((pen) => ({ ...pen, spec: { ...pen.spec } }));
}

function cloneObstacles(obstacles: StationeryObstacle[]): StationeryObstacle[] {
  return obstacles.map((obs) => ({ ...obs }));
}

export function PenFightArena({
  gameState,
  config,
  roundNumber,
  roundToken,
  replayToken,
  activeTurn,
  turnPhase,
  p1IsAI = false,
  p2IsAI,
  onTurnPhaseChange,
  onTurnAdvance,
  onRoundResolved,
  onReplayComplete,
  onRecordFlick,
  onRecordImpact,
  onUnlockAchievement,
  onFanStatusChange,
}: PenFightArenaProps) {
  const resolvedP2IsAI = p2IsAI ?? config.mode === 'ai';
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const propsRef = useRef({
    gameState,
    config,
    roundNumber,
    activeTurn,
    turnPhase,
    p1IsAI,
    p2IsAI: resolvedP2IsAI,
    onTurnPhaseChange,
    onTurnAdvance,
    onRoundResolved,
    onReplayComplete,
    onRecordFlick,
    onRecordImpact,
    onUnlockAchievement,
    onFanStatusChange,
  });
  propsRef.current = {
    gameState,
    config,
    roundNumber,
    activeTurn,
    turnPhase,
    p1IsAI,
    p2IsAI: resolvedP2IsAI,
    onTurnPhaseChange,
    onTurnAdvance,
    onRoundResolved,
    onReplayComplete,
    onRecordFlick,
    onRecordImpact,
    onUnlockAchievement,
    onFanStatusChange,
  };

  const simRef = useRef<SimState>({
    pens: [],
    obstacles: [],
    fan: null,
    fanTime: 0,
    lastFanStatus: 'idle',
    particles: [],
    trails: [],
    deskDebris: [],
    dustMotes: createInitialDustMotes(36),
    shavingSpawnTimer: 5.5,
    aimDrag: null,
    hoverGrab: null,
    aiPlan: null,
    aiTimer: 0,
    hitstopTimer: 0,
    shakeMag: 0,
    physicsAccum: 0,
    droppedThisTurn: [],
    prevPenPositions: {},
    activePointerId: null,
    time: 0,
    lastFlickReplay: null,
    replayPhase: 'idle',
    replayTimer: 0,
    replayFan: null,
    replayFanTime: 0,
    replayFinalSnapshot: null,
    turnPenClashes: 0,
    turnObstacleHits: [],
    turnStartPenDist: 0,
    turnLaunchOmega: 0,
  });

  // Reset round bodies & obstacles when roundToken, roundNumber, or mode changes
  useEffect(() => {
    const s = simRef.current;
    const cfg = propsRef.current.config;
    const tilt = ((roundNumber - 1) % 2 === 0 ? 1 : -1) * 0.14;
    const p1 = createPenBody(1, cfg.p1Pen, 285, 360, Math.PI * 0.5 + tilt, cfg.p1Custom);
    const p2 = createPenBody(2, cfg.p2Pen, 915, 360, -Math.PI * 0.5 + tilt, cfg.p2Custom);
    const obstacles = cfg.arenaMode === 'obstacles' ? createObstaclesForRound(roundNumber) : [];

    s.pens = [p1, p2];
    s.obstacles = obstacles;
    s.fan = cfg.fanEnabled ? createVentilationFanForRound(roundNumber) : null;
    s.fanTime = 0;
    s.lastFanStatus = 'idle';
    propsRef.current.onFanStatusChange?.('idle');
    s.particles = [];
    s.trails = [];
    s.deskDebris = createInitialDeskDebris(obstacles, s.pens);
    s.shavingSpawnTimer = 5.5 + Math.random() * 3.5;
    s.aimDrag = null;
    s.hoverGrab = null;
    s.aiPlan = null;
    s.aiTimer = 0;
    s.hitstopTimer = 0;
    s.shakeMag = 0;
    s.physicsAccum = 0;
    s.droppedThisTurn = [];
    s.activePointerId = null;
    s.lastFlickReplay = null;
    s.replayPhase = 'idle';
    s.replayTimer = 0;
    s.replayFan = null;
    s.replayFanTime = 0;
    s.replayFinalSnapshot = null;
    s.turnPenClashes = 0;
    s.turnObstacleHits = [];
    s.turnStartPenDist = 0;
    s.turnLaunchOmega = 0;
    s.prevPenPositions = {
      1: { x: p1.x, y: p1.y },
      2: { x: p2.x, y: p2.y },
    };
  }, [roundToken, roundNumber, config.mode]);

  // Live-update obstacles & fan hazard when toggled (Title Screen or Free Play)
  useEffect(() => {
    const s = simRef.current;
    s.obstacles = config.arenaMode === 'obstacles' ? createObstaclesForRound(roundNumber) : [];
  }, [config.arenaMode, roundNumber]);

  useEffect(() => {
    const s = simRef.current;
    s.fan = config.fanEnabled ? createVentilationFanForRound(roundNumber) : null;
    if (!config.fanEnabled) {
      s.lastFanStatus = 'idle';
      propsRef.current.onFanStatusChange?.('idle');
    }
  }, [config.fanEnabled, roundNumber]);

  // Live-update pen class & custom finish in-place (Title Screen preview & Free Play switching)
  useEffect(() => {
    const s = simRef.current;
    const p1 = s.pens.find((p) => p.player === 1);
    const p2 = s.pens.find((p) => p.player === 2);
    if (p1) applyPenSpecAndCustom(p1, config.p1Pen, config.p1Custom);
    if (p2) applyPenSpecAndCustom(p2, config.p2Pen, config.p2Custom);
  }, [config.p1Pen, config.p2Pen, config.p1Custom, config.p2Custom]);

  // Initialize slow-motion replay playback when entering REPLAYING
  useEffect(() => {
    const s = simRef.current;
    if (gameState === 'REPLAYING' && replayToken > 0) {
      const replay = s.lastFlickReplay;
      if (!replay) {
        propsRef.current.onReplayComplete();
        return;
      }
      if (!s.replayFinalSnapshot) {
        s.replayFinalSnapshot = {
          pens: clonePens(s.pens),
          obstacles: cloneObstacles(s.obstacles),
        };
      }
      s.pens = clonePens(replay.pens);
      s.obstacles = cloneObstacles(replay.obstacles);
      s.replayFan = replay.fan ? { ...replay.fan } : null;
      s.replayFanTime = replay.fanTime;
      s.particles = [];
      s.trails = [];
      s.aimDrag = null;
      s.hoverGrab = null;
      s.hitstopTimer = 0;
      s.shakeMag = 0;
      s.physicsAccum = 0;
      s.replayPhase = 'aiming';
      s.replayTimer = 0;
      s.prevPenPositions = {
        1: { x: s.pens[0]?.x ?? 0, y: s.pens[0]?.y ?? 0 },
        2: { x: s.pens[1]?.x ?? 0, y: s.pens[1]?.y ?? 0 },
      };
    } else if (gameState !== 'REPLAYING' && s.replayPhase !== 'idle') {
      // Restore end-of-round final positions if user skipped replay early
      if (s.replayFinalSnapshot) {
        s.pens = clonePens(s.replayFinalSnapshot.pens);
        s.obstacles = cloneObstacles(s.replayFinalSnapshot.obstacles);
        s.replayFinalSnapshot = null;
      }
      s.replayPhase = 'idle';
      s.replayTimer = 0;
      s.aimDrag = null;
      s.trails = [];
    }
  }, [gameState, replayToken]);

  // Clear active drag / held state if paused or window blurs
  useEffect(() => {
    const clearDrag = () => {
      const s = simRef.current;
      s.aimDrag = null;
      s.hoverGrab = null;
      s.activePointerId = null;
    };
    if (gameState !== 'PLAYING') {
      clearDrag();
    }
    window.addEventListener('blur', clearDrag);
    return () => window.removeEventListener('blur', clearDrag);
  }, [gameState]);

  // Cancel drag with Escape during aiming (capture phase so it doesn't also open Pause)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && simRef.current.aimDrag?.active) {
        e.stopPropagation();
        simRef.current.aimDrag = null;
        simRef.current.activePointerId = null;
      }
    };
    window.addEventListener('keydown', onKeyDown, true);
    return () => window.removeEventListener('keydown', onKeyDown, true);
  }, []);

  // Main isolated 60fps simulation & render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId = 0;
    let lastTime = performance.now();

    const syncCanvasSize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = container.getBoundingClientRect();
      const targetW = Math.max(1, Math.floor(rect.width * dpr));
      const targetH = Math.max(1, Math.floor(rect.height * dpr));
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
    };

    const spawnBurst = (x: number, y: number, color: string, count: number, speedScale: number) => {
      const s = simRef.current;
      for (let i = 0; i < count; i++) {
        const a = Math.random() * Math.PI * 2;
        const spd = (45 + Math.random() * 190) * speedScale;
        s.particles.push({
          x,
          y,
          vx: Math.cos(a) * spd,
          vy: Math.sin(a) * spd,
          size: 2.2 + Math.random() * 3.4,
          life: 0.25 + Math.random() * 0.26,
          maxLife: 0.51,
          color,
          alpha: 0.9,
        });
      }
    };

    const handleStepFeedback = (
      res: ReturnType<typeof stepPhysics>,
      isReplay: boolean
    ) => {
      const s = simRef.current;
      const p = propsRef.current;

      for (const pen of s.pens) {
        const prev = s.prevPenPositions[pen.player];
        if (pen.status === 'active' && prev) {
          const spd = Math.hypot(pen.vx, pen.vy);
          if (spd > 240 && Math.hypot(pen.x - prev.x, pen.y - prev.y) > 2) {
            s.trails.push({
              x1: prev.x,
              y1: prev.y,
              x2: pen.x,
              y2: pen.y,
              life: isReplay ? 0.28 : 0.16,
              maxLife: isReplay ? 0.28 : 0.16,
              color: PLAYER_COLORS[pen.player].secondary,
              width: pen.spec.radius * 0.9,
            });
          }
        }
        s.prevPenPositions[pen.player] = { x: pen.x, y: pen.y };
      }

      for (const col of res.collisions) {
        const norm = Math.min(1, col.impulse / 750);
        if (col.type === 'pen') {
          gameAudio.playPenHit(norm);
          if (!isReplay && p.config.mode !== 'freeplay') {
            p.onRecordImpact(col.impulse);
            s.turnPenClashes += 1;
            if (col.impulse >= 620) {
              p.onUnlockAchievement('heavy_clash');
            }
            if (s.turnLaunchOmega >= 9.5) {
              p.onUnlockAchievement('spin_master');
            }
          }
          spawnBurst(col.x, col.y, '#FDE68A', Math.round(7 + norm * 11), 0.7 + norm * 0.8);
          if (!isReplay) {
            triggerEnvironmentDraft(
              s.deskDebris,
              s.dustMotes,
              s.obstacles,
              s.pens,
              col.x,
              col.y,
              col.impulse
            );
          }
          if (col.impulse > 220) {
            s.hitstopTimer = 0.032 + norm * 0.025;
            s.shakeMag = Math.max(s.shakeMag, 3 + norm * 7.5);
          }
        } else {
          const kind = col.obstacleKind ?? 'eraser';
          if (!isReplay && col.penPlayer) {
            s.turnObstacleHits.push({
              kind,
              penPlayer: col.penPlayer,
              impulse: col.impulse,
            });
          }
          gameAudio.playObstacleHit(kind, norm);
          const burstColor =
            kind === 'eraser' ? '#F9A8D4' : kind === 'sharpener' ? '#E2E8F0' : '#FCD34D';
          spawnBurst(col.x, col.y, burstColor, Math.round(5 + norm * 7), 0.6 + norm * 0.5);
          if (!isReplay) {
            triggerEnvironmentDraft(
              s.deskDebris,
              s.dustMotes,
              s.obstacles,
              s.pens,
              col.x,
              col.y,
              col.impulse,
              kind
            );
          }
          if (col.impulse > 260) {
            s.shakeMag = Math.max(s.shakeMag, 2 + norm * 3.5);
          }
        }
      }

      for (const droppedPlayer of res.droppedPlayers) {
        if (isReplay || !s.droppedThisTurn.includes(droppedPlayer)) {
          if (!isReplay) s.droppedThisTurn.push(droppedPlayer);
          gameAudio.playEdgeDrop();
          const droppedPen = s.pens.find((pen) => pen.player === droppedPlayer);
          if (droppedPen) {
            spawnBurst(
              droppedPen.x,
              droppedPen.y,
              PLAYER_COLORS[droppedPlayer].secondary,
              14,
              0.9
            );
          }
        }
      }
    };

    const tick = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(rawDt, 0.05);

      syncCanvasSize();

      const p = propsRef.current;
      const s = simRef.current;
      const fxDt = p.gameState === 'REPLAYING' ? dt * 0.45 : dt;
      const reducedMotion =
        typeof window !== 'undefined' &&
        window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      s.time += fxDt;

      const activeFan = p.gameState === 'REPLAYING' ? s.replayFan : s.fan;
      const activeFanTime = p.gameState === 'REPLAYING' ? s.replayFanTime : s.fanTime;

      if (p.gameState !== 'PAUSED') {
        if (p.gameState !== 'REPLAYING' && s.fan) {
          s.fanTime += dt;
          const { status, factor } = getFanWindState(s.fan, s.fanTime);
          const bladeSpeed =
            status === 'gust'
              ? 24
              : status === 'spinup'
                ? 7 + factor * 50
                : status === 'spindown'
                  ? 4 + factor * 20
                  : 2.1;
          s.fan.bladeAngle = (s.fan.bladeAngle + bladeSpeed * dt) % (Math.PI * 2);

          if (status !== s.lastFanStatus) {
            if (status === 'gust' && p.gameState === 'PLAYING') {
              gameAudio.playFanGust();
            }
            s.lastFanStatus = status;
            p.onFanStatusChange?.(status);
          }
        } else if (p.gameState === 'REPLAYING' && s.replayFan) {
          const { status, factor } = getFanWindState(s.replayFan, s.replayFanTime);
          const bladeSpeed =
            status === 'gust' ? 24 : status === 'spinup' ? 7 + factor * 50 : 2.5;
          s.replayFan.bladeAngle =
            (s.replayFan.bladeAngle + bladeSpeed * fxDt) % (Math.PI * 2);
        }

        s.shavingSpawnTimer = stepDeskEnvironment(
          s.deskDebris,
          s.dustMotes,
          s.pens,
          s.obstacles,
          s.time,
          fxDt,
          s.shavingSpawnTimer,
          p.gameState === 'PLAYING' || p.gameState === 'TITLE_MENU',
          reducedMotion,
          activeFan,
          activeFanTime
        );
      }

      // Update particles & trails
      for (let i = s.particles.length - 1; i >= 0; i--) {
        const pt = s.particles[i];
        pt.x += pt.vx * fxDt;
        pt.y += pt.vy * fxDt;
        pt.vx *= Math.exp(-5 * fxDt);
        pt.vy *= Math.exp(-5 * fxDt);
        pt.life -= fxDt;
        if (pt.life <= 0) s.particles.splice(i, 1);
      }

      for (let i = s.trails.length - 1; i >= 0; i--) {
        s.trails[i].life -= fxDt;
        if (s.trails[i].life <= 0) s.trails.splice(i, 1);
      }

      if (s.shakeMag > 0) {
        s.shakeMag = Math.max(0, s.shakeMag - dt * 36);
      }

      if (p.gameState === 'REPLAYING' && s.lastFlickReplay) {
        const replay = s.lastFlickReplay;
        if (s.replayPhase === 'aiming') {
          s.replayTimer += dt;
          const rawProgress = Math.min(1, s.replayTimer / REPLAY_AIM_DURATION);
          // Smooth cubic ease-out pull-back
          const ease = 1 - Math.pow(1 - rawProgress, 3);
          const curDragX = replay.grabX + (replay.dragX - replay.grabX) * ease;
          const curDragY = replay.grabY + (replay.dragY - replay.grabY) * ease;

          s.aimDrag = {
            active: true,
            player: replay.shooter,
            localGrabOffset: replay.localOffset,
            grabX: replay.grabX,
            grabY: replay.grabY,
            dragX: curDragX,
            dragY: curDragY,
            power: replay.power * ease,
            launchVx: replay.launchVx,
            launchVy: replay.launchVy,
            launchOmega: replay.launchOmega,
            cancelled: false,
          };

          if (s.replayTimer >= REPLAY_AIM_DURATION) {
            s.aimDrag = null;
            s.replayPhase = 'moving';
            s.replayTimer = 0;
            s.physicsAccum = 0;
            const shooterPen = s.pens.find(
              (pen) => pen.player === replay.shooter && pen.status === 'active'
            );
            if (shooterPen) {
              shooterPen.vx = replay.launchVx;
              shooterPen.vy = replay.launchVy;
              shooterPen.omega = replay.launchOmega;
            }
            gameAudio.playFlick(replay.power);
          }
        } else if (s.replayPhase === 'moving') {
          if (s.hitstopTimer > 0) {
            s.hitstopTimer = Math.max(0, s.hitstopTimer - dt);
          } else {
            s.physicsAccum += dt * REPLAY_TIME_SCALE;
            let settled = false;
            let steps = 0;
            while (s.physicsAccum >= FIXED_DT && steps < 8) {
              s.physicsAccum -= FIXED_DT;
              steps++;
              const res = stepPhysics(
                s.pens,
                s.obstacles,
                FIXED_DT,
                s.replayFan,
                s.replayFanTime
              );
              s.replayFanTime += FIXED_DT;
              handleStepFeedback(res, true);
              if (res.settled) {
                settled = true;
                break;
              }
            }
            if (settled) {
              s.replayPhase = 'hold';
              s.replayTimer = 0;
            }
          }
        } else if (s.replayPhase === 'hold') {
          s.replayTimer += dt;
          if (s.replayTimer >= REPLAY_HOLD_DURATION) {
            s.replayPhase = 'idle';
            s.replayTimer = 0;
            p.onReplayComplete();
          }
        }
      } else if (p.gameState === 'PLAYING') {
        // Free Play idle wind: push any pen sitting inside an active gust even before flicking
        if (
          p.config.mode === 'freeplay' &&
          p.turnPhase === 'aiming' &&
          !s.aimDrag?.active &&
          s.fan
        ) {
          const { factor } = getFanWindState(s.fan, s.fanTime);
          if (factor > 0.22) {
            s.physicsAccum += dt;
            let steps = 0;
            while (s.physicsAccum >= FIXED_DT && steps < 10) {
              s.physicsAccum -= FIXED_DT;
              steps++;
              const res = stepPhysics(s.pens, s.obstacles, FIXED_DT, s.fan, s.fanTime);
              handleStepFeedback(res, false);
            }
            for (const pen of s.pens) {
              if (pen.status === 'out') {
                const other = s.pens.find(
                  (o) => o.player !== pen.player && o.status === 'active'
                );
                const baseX = pen.player === 1 ? 285 : 915;
                let spawnY = 360;
                if (other && Math.hypot(other.x - baseX, other.y - spawnY) < 130) {
                  spawnY = other.y > 360 ? 200 : 520;
                }
                pen.x = baseX;
                pen.y = spawnY;
                pen.angle = (pen.player === 1 ? Math.PI * 0.5 : -Math.PI * 0.5) + 0.14;
                pen.vx = 0;
                pen.vy = 0;
                pen.omega = 0;
                pen.status = 'active';
                pen.fallProgress = 0;
                pen.fallVx = 0;
                pen.fallVy = 0;
                pen.fallSpin = 0;
                pen.hitFlash = 0.7;
                s.prevPenPositions[pen.player] = { x: pen.x, y: pen.y };
                spawnBurst(pen.x, pen.y, PLAYER_COLORS[pen.player].secondary, 12, 0.7);
              }
            }
          }
        }

        // AI Turn Orchestration
        if (p.turnPhase === 'ai_thinking') {
          const aiSide = p.activeTurn;
          const oppSide: 1 | 2 = aiSide === 1 ? 2 : 1;
          if (!s.aiPlan) {
            s.aiPlan = computeAIShot(
              s.pens,
              s.obstacles,
              p.config.aiDifficulty,
              s.fan,
              s.fanTime,
              aiSide
            );
            s.aiTimer = 0;
          }
          s.aiTimer += dt;
          const telegraphDuration = 0.68;
          if (s.aiTimer >= telegraphDuration) {
            const aiPen = s.pens.find((pen) => pen.player === aiSide && pen.status === 'active');
            if (aiPen && s.aiPlan) {
              const vel = computeFlickVelocities(
                aiPen,
                s.aiPlan.localOffset,
                s.aiPlan.pullDx,
                s.aiPlan.pullDy
              );

              // Snapshot exact pre-flick state for slow-motion replay
              s.lastFlickReplay = {
                shooter: aiSide,
                pens: clonePens(s.pens),
                obstacles: cloneObstacles(s.obstacles),
                fan: s.fan ? { ...s.fan } : null,
                fanTime: s.fanTime,
                localOffset: s.aiPlan.localOffset,
                grabX: s.aiPlan.grabX,
                grabY: s.aiPlan.grabY,
                dragX: s.aiPlan.dragX,
                dragY: s.aiPlan.dragY,
                power: vel.power,
                launchVx: vel.vx,
                launchVy: vel.vy,
                launchOmega: vel.omega,
              };

              const otherPen = s.pens.find((pen) => pen.player === oppSide);
              s.turnStartPenDist = otherPen
                ? Math.hypot(aiPen.x - otherPen.x, aiPen.y - otherPen.y)
                : 0;
              s.turnLaunchOmega = Math.abs(vel.omega);

              aiPen.vx = vel.vx;
              aiPen.vy = vel.vy;
              aiPen.omega = vel.omega;
              s.physicsAccum = 0;
              s.droppedThisTurn = [];
              s.turnPenClashes = 0;
              s.turnObstacleHits = [];
              gameAudio.playFlick(vel.power);
              p.onRecordFlick(aiSide);
            }
            s.aiPlan = null;
            s.aiTimer = 0;
            p.onTurnPhaseChange('simulating');
          }
        } else if (p.turnPhase === 'simulating') {
          if (s.hitstopTimer > 0) {
            s.hitstopTimer = Math.max(0, s.hitstopTimer - dt);
          } else {
            s.physicsAccum += dt;
            let settled = false;
            let steps = 0;
            while (s.physicsAccum >= FIXED_DT && steps < 12) {
              s.physicsAccum -= FIXED_DT;
              steps++;
              const res = stepPhysics(s.pens, s.obstacles, FIXED_DT, s.fan, s.fanTime);
              handleStepFeedback(res, false);
              if (res.settled) {
                settled = true;
                break;
              }
            }

            // Turn resolution when all bodies settle
            if (settled) {
              if (p.config.mode === 'freeplay') {
                // Free Play: never score or ring-out; respawn any pen that slid off the desk
                for (const pen of s.pens) {
                  if (pen.status !== 'active') {
                    const other = s.pens.find((o) => o.player !== pen.player && o.status === 'active');
                    const baseX = pen.player === 1 ? 285 : 915;
                    let spawnY = 360;
                    if (other && Math.hypot(other.x - baseX, other.y - spawnY) < 130) {
                      spawnY = other.y > 360 ? 200 : 520;
                    }
                    pen.x = baseX;
                    pen.y = spawnY;
                    pen.angle = (pen.player === 1 ? Math.PI * 0.5 : -Math.PI * 0.5) + 0.14;
                    pen.vx = 0;
                    pen.vy = 0;
                    pen.omega = 0;
                    pen.status = 'active';
                    pen.fallProgress = 0;
                    pen.fallVx = 0;
                    pen.fallVy = 0;
                    pen.fallSpin = 0;
                    pen.hitFlash = 0.7;
                    s.prevPenPositions[pen.player] = { x: pen.x, y: pen.y };
                    spawnBurst(pen.x, pen.y, PLAYER_COLORS[pen.player].secondary, 12, 0.7);
                  }
                }
                p.onTurnPhaseChange('aiming');
              } else {
                const p1Out = s.pens[0]?.status !== 'active';
                const p2Out = s.pens[1]?.status !== 'active';

                // Achievement checks on turn settlement
                const shooterObsHits = s.turnObstacleHits.filter(
                  (h) => h.penPlayer === p.activeTurn
                ).length;
                if (
                  (shooterObsHits >= 2 || s.turnObstacleHits.length >= 2) &&
                  (s.turnPenClashes > 0 || p1Out || p2Out)
                ) {
                  p.onUnlockAchievement('double_bank');
                }

                for (const pen of s.pens) {
                  if (pen.status === 'active') {
                    const edgeDist = Math.min(
                      pen.x - DESK_BOUNDS.left,
                      DESK_BOUNDS.right - pen.x,
                      pen.y - DESK_BOUNDS.top,
                      DESK_BOUNDS.bottom - pen.y
                    );
                    if (edgeDist <= 28) {
                      p.onUnlockAchievement('perfect_edge');
                    }
                  }
                }

                if (s.turnStartPenDist >= 480 && p1Out !== p2Out) {
                  const winner: 1 | 2 = p2Out ? 1 : 2;
                  if (winner === p.activeTurn) {
                    p.onUnlockAchievement('long_ring_out');
                  }
                }

                if (p1Out && p2Out) {
                  if (
                    s.droppedThisTurn.length >= 2 &&
                    s.droppedThisTurn[0] !== s.droppedThisTurn[1]
                  ) {
                    const firstOut = s.droppedThisTurn[0];
                    const winner: 1 | 2 = firstOut === 1 ? 2 : 1;
                    const cause = summarizeTurnOutcome(
                      winner,
                      p.activeTurn,
                      s.turnPenClashes,
                      s.turnObstacleHits
                    );
                    gameAudio.playRoundWin();
                    p.onRoundResolved(
                      winner,
                      'Opponent tumbled off the desk edge first!',
                      cause.eventType,
                      cause.eventDetail
                    );
                  } else {
                    const cause = summarizeTurnOutcome(
                      'draw',
                      p.activeTurn,
                      s.turnPenClashes,
                      s.turnObstacleHits
                    );
                    p.onRoundResolved(
                      'draw',
                      'Both pens went off the edge simultaneously!',
                      cause.eventType,
                      cause.eventDetail
                    );
                  }
                } else if (p2Out) {
                  const cause = summarizeTurnOutcome(
                    1,
                    p.activeTurn,
                    s.turnPenClashes,
                    s.turnObstacleHits
                  );
                  gameAudio.playRoundWin();
                  p.onRoundResolved(
                    1,
                    'Rival knocked clean off the wooden desk!',
                    cause.eventType,
                    cause.eventDetail
                  );
                } else if (p1Out) {
                  const cause = summarizeTurnOutcome(
                    2,
                    p.activeTurn,
                    s.turnPenClashes,
                    s.turnObstacleHits
                  );
                  gameAudio.playRoundWin();
                  p.onRoundResolved(
                    2,
                    'Player 1 pen fell off the desk edge!',
                    cause.eventType,
                    cause.eventDetail
                  );
                } else {
                  const nextTurn: 1 | 2 = p.activeTurn === 1 ? 2 : 1;
                  p.onTurnAdvance(nextTurn);
                }
              }
            }
          }
        }
      }

      // Render world onto high-DPI scaled canvas
      const dpr = canvas.width / Math.max(1, container.clientWidth);
      const viewW = canvas.width;
      const viewH = canvas.height;
      const scale = Math.min(viewW / WORLD_WIDTH, viewH / WORLD_HEIGHT);
      const offsetX = (viewW - WORLD_WIDTH * scale) * 0.5;
      const offsetY = (viewH - WORLD_HEIGHT * scale) * 0.5;

      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = '#0E1318';
      ctx.fillRect(0, 0, viewW, viewH);

      ctx.translate(offsetX, offsetY);
      ctx.scale(scale, scale);

      const shakeX = s.shakeMag > 0 ? (Math.random() - 0.5) * 2 * s.shakeMag : 0;
      const shakeY = s.shakeMag > 0 ? (Math.random() - 0.5) * 2 * s.shakeMag : 0;

      const aiTelegraph =
        p.gameState === 'PLAYING' && p.turnPhase === 'ai_thinking' && s.aiPlan
          ? {
              active: true,
              grabX: s.aiPlan.grabX,
              grabY: s.aiPlan.grabY,
              dragX: s.aiPlan.dragX,
              dragY: s.aiPlan.dragY,
              power: s.aiPlan.power,
              progress: Math.min(1, s.aiTimer / 0.52),
            }
          : null;

      tabletopRenderer.render(ctx, {
        pens: s.pens,
        obstacles: s.obstacles,
        particles: s.particles,
        trails: s.trails,
        deskDebris: s.deskDebris,
        dustMotes: s.dustMotes,
        fan: activeFan,
        fanTime: activeFanTime,
        aimDrag: s.aimDrag,
        aiTelegraph,
        activeTurn: p.activeTurn,
        showTurnHighlight: p.gameState === 'PLAYING' && p.turnPhase === 'aiming',
        hoverGrab:
          p.gameState === 'PLAYING' && p.turnPhase === 'aiming' ? s.hoverGrab : null,
        shakeX,
        shakeY,
        time: s.time,
      });

      ctx.restore();
      void dpr;

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animId);
  }, []);

  const clientToWorld = (clientX: number, clientY: number): { x: number; y: number } | null => {
    const container = containerRef.current;
    if (!container) return null;
    const rect = container.getBoundingClientRect();
    const scale = Math.min(rect.width / WORLD_WIDTH, rect.height / WORLD_HEIGHT);
    const offsetX = (rect.width - WORLD_WIDTH * scale) * 0.5;
    const offsetY = (rect.height - WORLD_HEIGHT * scale) * 0.5;
    return {
      x: (clientX - rect.left - offsetX) / scale,
      y: (clientY - rect.top - offsetY) / scale,
    };
  };

  const canHumanAim = (): boolean => {
    if (gameState !== 'PLAYING' || turnPhase !== 'aiming') return false;
    const activeIsAI = activeTurn === 1 ? p1IsAI : resolvedP2IsAI;
    if (activeIsAI) return false;
    return true;
  };

  const findGrabbablePen = (
    worldX: number,
    worldY: number,
    extraRadius: number
  ): {
    pen: PenBody;
    proj: ReturnType<typeof projectPointOntoPen>;
  } | null => {
    const s = simRef.current;
    const candidates =
      config.mode === 'freeplay'
        ? s.pens.filter((pen) => pen.status === 'active')
        : s.pens.filter((pen) => pen.player === activeTurn && pen.status === 'active');

    let best: { pen: PenBody; proj: ReturnType<typeof projectPointOntoPen> } | null = null;
    for (const pen of candidates) {
      const proj = projectPointOntoPen(pen, worldX, worldY);
      if (proj.distance <= pen.spec.radius + extraRadius) {
        if (!best || proj.distance < best.proj.distance) {
          best = { pen, proj };
        }
      }
    }
    return best;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.button === 2) {
      simRef.current.aimDrag = null;
      simRef.current.activePointerId = null;
      return;
    }
    if (!canHumanAim()) return;

    const pt = clientToWorld(e.clientX, e.clientY);
    if (!pt) return;

    const s = simRef.current;
    const hit = findGrabbablePen(pt.x, pt.y, 26);
    if (hit) {
      const { pen: activePen, proj } = hit;
      if (config.mode === 'freeplay' && activePen.player !== activeTurn) {
        onTurnAdvance(activePen.player);
      }
      s.activePointerId = e.pointerId;
      e.currentTarget.setPointerCapture(e.pointerId);
      s.hoverGrab = null;
      s.aimDrag = {
        active: true,
        player: activePen.player,
        localGrabOffset: proj.localOffset,
        grabX: proj.worldX,
        grabY: proj.worldY,
        dragX: pt.x,
        dragY: pt.y,
        power: 0,
        launchVx: 0,
        launchVy: 0,
        launchOmega: 0,
        cancelled: true,
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const pt = clientToWorld(e.clientX, e.clientY);
    if (!pt) return;
    const s = simRef.current;

    if (s.aimDrag?.active && s.activePointerId === e.pointerId) {
      const activePen = s.pens.find((pen) => pen.player === s.aimDrag!.player);
      if (!activePen) return;

      const pullDx = pt.x - s.aimDrag.grabX;
      const pullDy = pt.y - s.aimDrag.grabY;
      const pullDist = Math.hypot(pullDx, pullDy);
      const cancelled = pullDist < MIN_PULL_DISTANCE;
      const vel = computeFlickVelocities(
        activePen,
        s.aimDrag.localGrabOffset,
        pullDx,
        pullDy
      );

      s.aimDrag = {
        ...s.aimDrag,
        dragX: pt.x,
        dragY: pt.y,
        power: vel.power,
        launchVx: vel.vx,
        launchVy: vel.vy,
        launchOmega: vel.omega,
        cancelled,
      };
      return;
    }

    if (canHumanAim()) {
      const hit = findGrabbablePen(pt.x, pt.y, 22);
      if (hit) {
        s.hoverGrab = { x: hit.proj.worldX, y: hit.proj.worldY };
        return;
      }
    }
    s.hoverGrab = null;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const s = simRef.current;
    if (!s.aimDrag?.active || s.activePointerId !== e.pointerId) return;

    const drag = s.aimDrag;
    s.aimDrag = null;
    s.activePointerId = null;

    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }

    if (drag.cancelled || !canHumanAim()) {
      return;
    }

    const activePen = s.pens.find((pen) => pen.player === drag.player && pen.status === 'active');
    if (!activePen) return;

    // Snapshot exact pre-flick physics state for slow-motion replay
    s.lastFlickReplay = {
      shooter: drag.player,
      pens: clonePens(s.pens),
      obstacles: cloneObstacles(s.obstacles),
      fan: s.fan ? { ...s.fan } : null,
      fanTime: s.fanTime,
      localOffset: drag.localGrabOffset,
      grabX: drag.grabX,
      grabY: drag.grabY,
      dragX: drag.dragX,
      dragY: drag.dragY,
      power: drag.power,
      launchVx: drag.launchVx,
      launchVy: drag.launchVy,
      launchOmega: drag.launchOmega,
    };

    const otherPen = s.pens.find((pen) => pen.player !== drag.player);
    s.turnStartPenDist = otherPen
      ? Math.hypot(activePen.x - otherPen.x, activePen.y - otherPen.y)
      : 0;
    s.turnLaunchOmega = Math.abs(drag.launchOmega);

    activePen.vx = drag.launchVx;
    activePen.vy = drag.launchVy;
    activePen.omega = drag.launchOmega;
    s.physicsAccum = 0;
    s.droppedThisTurn = [];
    s.turnPenClashes = 0;
    s.turnObstacleHits = [];
    s.prevPenPositions[activePen.player] = { x: activePen.x, y: activePen.y };

    gameAudio.playFlick(drag.power);
    onRecordFlick(drag.player);
    onTurnPhaseChange('simulating');
  };

  return (
    <div ref={containerRef} className="relative w-full h-full select-none">
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={() => {
          simRef.current.aimDrag = null;
          simRef.current.activePointerId = null;
        }}
        onContextMenu={(e) => e.preventDefault()}
        className={`block w-full h-full touch-none ${
          canHumanAim() ? 'cursor-crosshair' : 'cursor-default'
        }`}
      />
    </div>
  );
}

export type { MatchStats };
