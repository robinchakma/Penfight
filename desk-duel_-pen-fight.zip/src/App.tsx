import { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { GameHUD } from './components/GameHUD';
import { GameModals } from './components/GameModals';
import { PenFightArena } from './components/PenFightArena';
import { TitleScreen } from './components/TitleScreen';
import { TournamentBracket } from './components/TournamentBracket';
import {
  auth,
  formatFirebaseQuotaOrAuthMessage,
  signInWithGooglePopup,
  signOutFirebase,
} from './firebase';
import { AudioSettings, gameAudio } from './game/audio';
import {
  DEFAULT_P1_CUSTOM,
  DEFAULT_P2_CUSTOM,
  getWinsNeeded,
  loadUnlockedCustomClasses,
  pickRandomDeskGraffitiQuote,
  saveUnlockedCustomClasses,
} from './game/constants';
import {
  ensurePlayerLeaderboardProfile,
  LeaderboardEntry,
  MatchStatDelta,
  recordCompetitiveMatchStats,
} from './game/leaderboard';
import {
  createDefaultTournamentEntrants,
  createTournamentBracket,
  getNextReadyMatch,
  getTournamentEntrant,
  getTournamentMatchById,
  recordTournamentMatchResult,
  simulateAIMatchResult,
} from './game/tournament';
import {
  AchievementId,
  ArenaMode,
  DeskGraffitiNote,
  FanWindStatus,
  GameState,
  MatchConfig,
  MatchStats,
  PenClassId,
  PenTextureId,
  RoundEventType,
  RoundHistoryEntry,
  RoundSummary,
  TournamentBracketState,
  TurnPhase,
} from './game/types';

const INITIAL_STATS: MatchStats = {
  totalFlicks: 0,
  hardestImpact: 0,
  p1RingOuts: 0,
  p2RingOuts: 0,
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [config, setConfig] = useState<MatchConfig>({
    mode: 'ai',
    aiDifficulty: 'medium',
    arenaMode: 'obstacles',
    fanEnabled: true,
    totalRounds: 3,
    p1Pen: 'ballpoint',
    p2Pen: 'fountain',
    p1Custom: DEFAULT_P1_CUSTOM,
    p2Custom: DEFAULT_P2_CUSTOM,
    tournamentSize: 4,
    tournamentEntrants: createDefaultTournamentEntrants('ballpoint', DEFAULT_P1_CUSTOM),
  });
  const [fanStatus, setFanStatus] = useState<FanWindStatus>('idle');
  const [tournamentBracket, setTournamentBracket] = useState<TournamentBracketState | null>(null);
  const [lastTournamentMatchSummary, setLastTournamentMatchSummary] = useState<{
    matchId: string;
    stageLabel: string;
    winnerName: string;
    scoreLine: string;
  } | null>(null);

  const [unlockedCustomClasses, setUnlockedCustomClasses] = useState<Record<PenClassId, boolean>>(
    () => loadUnlockedCustomClasses()
  );

  const [roundNumber, setRoundNumber] = useState(1);
  const [roundToken, setRoundToken] = useState(1);
  const [replayToken, setReplayToken] = useState(0);
  const [replayReturnState, setReplayReturnState] = useState<
    'ROUND_END' | 'GAME_OVER' | 'TOURNAMENT_BRACKET'
  >('ROUND_END');
  const [lastShooter, setLastShooter] = useState<1 | 2 | null>(null);

  const [p1Wins, setP1Wins] = useState(0);
  const [p2Wins, setP2Wins] = useState(0);
  const [activeTurn, setActiveTurn] = useState<1 | 2>(1);
  const [turnPhase, setTurnPhase] = useState<TurnPhase>('aiming');
  const [roundSummary, setRoundSummary] = useState<RoundSummary | null>(null);
  const [deskGraffiti, setDeskGraffiti] = useState<DeskGraffitiNote | null>(null);
  const lastGraffitiQuoteRef = useRef<string | undefined>(undefined);
  const [matchHistory, setMatchHistory] = useState<RoundHistoryEntry[]>([]);
  const [earnedAchievements, setEarnedAchievements] = useState<AchievementId[]>([]);
  const [recentAchievement, setRecentAchievement] = useState<AchievementId | null>(null);
  const toastTimerRef = useRef<number | null>(null);
  const [stats, setStats] = useState<MatchStats>(INITIAL_STATS);
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(() =>
    gameAudio.getSettings()
  );

  const [authUser, setAuthUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [myLeaderboardEntry, setMyLeaderboardEntry] = useState<LeaderboardEntry | null>(null);
  const [leaderboardSyncNotice, setLeaderboardSyncNotice] = useState<string | null>(null);

  const p1PenRef = useRef<PenClassId>(config.p1Pen);
  p1PenRef.current = config.p1Pen;
  const statsRef = useRef<MatchStats>(stats);
  statsRef.current = stats;

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      setAuthUser(nextUser);
      setAuthReady(true);
      if (nextUser && nextUser.emailVerified) {
        try {
          const entry = await ensurePlayerLeaderboardProfile(nextUser, p1PenRef.current);
          setMyLeaderboardEntry(entry);
          setAuthError(null);
        } catch (err) {
          setAuthError(formatFirebaseQuotaOrAuthMessage(err));
        }
      } else {
        setMyLeaderboardEntry(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSignIn = useCallback(async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const cred = await signInWithGooglePopup();
      if (cred.user && cred.user.emailVerified) {
        const entry = await ensurePlayerLeaderboardProfile(cred.user, p1PenRef.current);
        setMyLeaderboardEntry(entry);
      }
    } catch (err) {
      setAuthError(formatFirebaseQuotaOrAuthMessage(err));
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const handleSignOut = useCallback(async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      await signOutFirebase();
      setMyLeaderboardEntry(null);
    } catch (err) {
      setAuthError(formatFirebaseQuotaOrAuthMessage(err));
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const submitCompetitiveStats = useCallback(
    async (delta: MatchStatDelta) => {
      if (!authUser || !authUser.emailVerified) {
        setLeaderboardSyncNotice(
          'Sign in with Google on the Title Menu to save wins to Global Leaderboards.'
        );
        return;
      }
      setLeaderboardSyncNotice('Saving match stats to Global Leaderboards...');
      try {
        const updated = await recordCompetitiveMatchStats(authUser, delta);
        setMyLeaderboardEntry(updated);
        setLeaderboardSyncNotice(
          delta.tournamentChampion
            ? `Tournament crown & match win saved (${updated.totalWins} total wins).`
            : delta.won
              ? `Match win recorded on Global Leaderboards (${updated.totalWins} total wins).`
              : `Match result recorded on Global Leaderboards (${updated.totalWins} total wins).`
        );
      } catch (err) {
        setLeaderboardSyncNotice(formatFirebaseQuotaOrAuthMessage(err));
      }
    },
    [authUser]
  );

  useEffect(() => {
    const unlock = () => {
      gameAudio.unlock();
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  const handleUnlockCustomClass = useCallback((penId: PenClassId) => {
    setUnlockedCustomClasses((prev) => {
      if (prev[penId]) return prev;
      const next = { ...prev, [penId]: true };
      saveUnlockedCustomClasses(next);
      return next;
    });
  }, []);

  const unlockAchievement = useCallback((id: AchievementId) => {
    setEarnedAchievements((prev) => {
      if (prev.includes(id)) return prev;
      setRecentAchievement(id);
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
      toastTimerRef.current = window.setTimeout(() => {
        setRecentAchievement(null);
        toastTimerRef.current = null;
      }, 2800);
      return [...prev, id];
    });
  }, []);

  const activeTournamentMatch =
    config.mode === 'tournament' && tournamentBracket
      ? getTournamentMatchById(tournamentBracket, tournamentBracket.activeMatchId)
      : null;
  const activeEntrantA =
    activeTournamentMatch && tournamentBracket
      ? getTournamentEntrant(tournamentBracket, activeTournamentMatch.entrantAId)
      : null;
  const activeEntrantB =
    activeTournamentMatch && tournamentBracket
      ? getTournamentEntrant(tournamentBracket, activeTournamentMatch.entrantBId)
      : null;

  const p1IsAI =
    config.mode === 'tournament' && activeEntrantA ? activeEntrantA.isAI : false;
  const p2IsAI =
    config.mode === 'tournament' && activeEntrantB
      ? activeEntrantB.isAI
      : config.mode === 'ai';
  const activeP1Name =
    config.mode === 'tournament' && activeEntrantA ? activeEntrantA.name : undefined;
  const activeP2Name =
    config.mode === 'tournament' && activeEntrantB ? activeEntrantB.name : undefined;
  const tournamentStageLabel =
    config.mode === 'tournament' && activeTournamentMatch
      ? activeTournamentMatch.stageLabel
      : null;

  const effectiveArenaConfig: MatchConfig =
    config.mode === 'tournament' && activeEntrantA && activeEntrantB
      ? {
          ...config,
          p1Pen: activeEntrantA.penClass,
          p2Pen: activeEntrantB.penClass,
          p1Custom: activeEntrantA.custom,
          p2Custom: activeEntrantB.custom,
        }
      : config;

  const startFreshMatch = useCallback(() => {
    setRoundNumber(1);
    setRoundToken((t) => t + 1);
    setLastShooter(null);
    setP1Wins(0);
    setP2Wins(0);
    setActiveTurn(1);
    setTurnPhase('aiming');
    setRoundSummary(null);
    setDeskGraffiti(null);
    setMatchHistory([]);
    setEarnedAchievements([]);
    setRecentAchievement(null);
    setLeaderboardSyncNotice(null);
    setStats(INITIAL_STATS);

    if (config.mode === 'tournament') {
      const sanitizedEntrants = config.tournamentEntrants.map((ent, idx) => ({
        ...ent,
        custom:
          idx === 0
            ? {
                ...config.p1Custom,
                styleMode: unlockedCustomClasses[ent.penClass]
                  ? config.p1Custom.styleMode
                  : 'standard',
              }
            : ent.custom,
      }));
      const bracket = createTournamentBracket(
        sanitizedEntrants,
        config.tournamentSize,
        config.totalRounds
      );
      setTournamentBracket(bracket);
      setLastTournamentMatchSummary(null);
      setGameState('TOURNAMENT_BRACKET');
      return;
    }

    setTournamentBracket(null);
    setLastTournamentMatchSummary(null);
    setGameState('PLAYING');
  }, [config, unlockedCustomClasses]);

  const handlePlayTournamentMatch = useCallback(
    (matchId: string) => {
      if (!tournamentBracket) return;
      const match = getTournamentMatchById(tournamentBracket, matchId);
      if (!match) return;
      const entrantA = getTournamentEntrant(tournamentBracket, match.entrantAId);
      const entrantB = getTournamentEntrant(tournamentBracket, match.entrantBId);
      if (!entrantA || !entrantB) return;

      setTournamentBracket((prev) => (prev ? { ...prev, activeMatchId: matchId } : prev));
      setRoundNumber(1);
      setRoundToken((t) => t + 1);
      setLastShooter(null);
      setP1Wins(0);
      setP2Wins(0);
      setActiveTurn(1);
      setTurnPhase(entrantA.isAI ? 'ai_thinking' : 'aiming');
      setRoundSummary(null);
      setDeskGraffiti(null);
      setMatchHistory([]);
      setLeaderboardSyncNotice(null);
      setStats(INITIAL_STATS);
      setGameState('PLAYING');
    },
    [tournamentBracket]
  );

  const handleSimulateTournamentMatch = useCallback(
    (matchId: string) => {
      setTournamentBracket((prev) => {
        if (!prev) return prev;
        const match = getTournamentMatchById(prev, matchId);
        if (!match || match.status !== 'ready') return prev;
        const entrantA = getTournamentEntrant(prev, match.entrantAId);
        const entrantB = getTournamentEntrant(prev, match.entrantBId);
        if (!entrantA || !entrantB) return prev;

        const sim = simulateAIMatchResult(entrantA, entrantB, prev.totalRoundsPerMatch);
        const winnerEntrant = sim.winnerSide === 1 ? entrantA : entrantB;
        setLastTournamentMatchSummary({
          matchId: match.id,
          stageLabel: match.stageLabel,
          winnerName: winnerEntrant.name,
          scoreLine: `${sim.scoreA}–${sim.scoreB}`,
        });
        const nextBracket = recordTournamentMatchResult(
          prev,
          match.id,
          sim.winnerSide,
          sim.scoreA,
          sim.scoreB,
          true,
          sim.summaryNote
        );
        if (nextBracket.championId) {
          gameAudio.playMatchWin();
        }
        return nextBracket;
      });
    },
    []
  );

  const handleAutoFinishTournament = useCallback(() => {
    setTournamentBracket((prev) => {
      if (!prev) return prev;
      let cur = prev;
      let lastSummary: {
        matchId: string;
        stageLabel: string;
        winnerName: string;
        scoreLine: string;
      } | null = null;
      let guard = 0;
      while (guard < 16) {
        guard++;
        const nextMatch = getNextReadyMatch(cur);
        if (!nextMatch) break;
        const entrantA = getTournamentEntrant(cur, nextMatch.entrantAId);
        const entrantB = getTournamentEntrant(cur, nextMatch.entrantBId);
        if (!entrantA || !entrantB) break;
        const sim = simulateAIMatchResult(entrantA, entrantB, cur.totalRoundsPerMatch);
        const winnerEntrant = sim.winnerSide === 1 ? entrantA : entrantB;
        lastSummary = {
          matchId: nextMatch.id,
          stageLabel: nextMatch.stageLabel,
          winnerName: winnerEntrant.name,
          scoreLine: `${sim.scoreA}–${sim.scoreB}`,
        };
        cur = recordTournamentMatchResult(
          cur,
          nextMatch.id,
          sim.winnerSide,
          sim.scoreA,
          sim.scoreB,
          true,
          sim.summaryNote
        );
      }
      if (lastSummary) {
        setLastTournamentMatchSummary(lastSummary);
      }
      if (cur.championId) {
        gameAudio.playMatchWin();
      }
      return cur;
    });
  }, []);

  const handleTurnAdvance = useCallback(
    (nextTurn: 1 | 2) => {
      setActiveTurn(nextTurn);
      const nextIsAI = nextTurn === 1 ? p1IsAI : p2IsAI;
      setTurnPhase(nextIsAI ? 'ai_thinking' : 'aiming');
    },
    [p1IsAI, p2IsAI]
  );

  const handleFreeplayChangePen = useCallback((player: 1 | 2, penId: PenClassId) => {
    setConfig((prev) =>
      player === 1 ? { ...prev, p1Pen: penId } : { ...prev, p2Pen: penId }
    );
  }, []);

  const handleFreeplayChangeFinish = useCallback(
    (player: 1 | 2, finish: 'standard' | PenTextureId) => {
      setConfig((prev) => {
        const key = player === 1 ? 'p1Custom' : 'p2Custom';
        const current = prev[key];
        const nextCustom =
          finish === 'standard'
            ? { ...current, styleMode: 'standard' as const }
            : { ...current, styleMode: 'custom' as const, texture: finish };
        return { ...prev, [key]: nextCustom };
      });
    },
    []
  );

  const handleFreeplayToggleArena = useCallback((arenaMode: ArenaMode) => {
    setConfig((prev) => ({ ...prev, arenaMode }));
  }, []);

  const handleFreeplayToggleFan = useCallback(() => {
    setConfig((prev) => ({ ...prev, fanEnabled: !prev.fanEnabled }));
  }, []);

  const handleFreeplayResetDesk = useCallback(() => {
    setRoundToken((t) => t + 1);
    setTurnPhase('aiming');
  }, []);

  const handleChangeConfigFromTitle = useCallback(
    (next: MatchConfig) => {
      if (next.mode !== 'freeplay') {
        const p1Style = unlockedCustomClasses[next.p1Pen] ? next.p1Custom.styleMode : 'standard';
        const p2Style = unlockedCustomClasses[next.p2Pen] ? next.p2Custom.styleMode : 'standard';
        setConfig({
          ...next,
          p1Custom: { ...next.p1Custom, styleMode: p1Style },
          p2Custom: { ...next.p2Custom, styleMode: p2Style },
        });
      } else {
        setConfig(next);
      }
    },
    [unlockedCustomClasses]
  );

  const handleRoundResolved = useCallback(
    (
      winner: 1 | 2 | 'draw',
      reason: string,
      eventType: RoundEventType,
      eventDetail: string
    ) => {
      const nextP1Wins = winner === 1 ? p1Wins + 1 : p1Wins;
      const nextP2Wins = winner === 2 ? p2Wins + 1 : p2Wins;

      if (winner === 1 && !p1IsAI) {
        handleUnlockCustomClass(effectiveArenaConfig.p1Pen);
      } else if (winner === 2 && !p2IsAI) {
        handleUnlockCustomClass(effectiveArenaConfig.p2Pen);
      }

      setP1Wins(nextP1Wins);
      setP2Wins(nextP2Wins);
      setMatchHistory((prev) => [
        ...prev,
        {
          id: prev.length + 1,
          roundNumber,
          winner,
          eventType,
          eventDetail,
          p1WinsAfter: nextP1Wins,
          p2WinsAfter: nextP2Wins,
        },
      ]);
      setStats((prev) => ({
        ...prev,
        p1RingOuts: prev.p1RingOuts + (winner === 1 ? 1 : 0),
        p2RingOuts: prev.p2RingOuts + (winner === 2 ? 1 : 0),
      }));
      setTurnPhase('resolving');

      const loserIsHuman =
        winner === 2 ? !p1IsAI : winner === 1 ? !p2IsAI : false;
      if (loserIsHuman) {
        const quote = pickRandomDeskGraffitiQuote(lastGraffitiQuoteRef.current);
        lastGraffitiQuoteRef.current = quote;
        const tilts = [-1.4, -0.8, 0.9, 1.4];
        const tiltDeg = tilts[Math.floor(Math.random() * tilts.length)] ?? -1;
        const loserLabel =
          winner === 2 ? (activeP1Name ?? 'Player 1') : (activeP2Name ?? 'Player 2');
        setDeskGraffiti({
          id: Date.now(),
          quote,
          loserLabel,
          roundNumber,
          tiltDeg,
        });
      } else {
        setDeskGraffiti(null);
      }

      const nextRingOutsP1 = statsRef.current.p1RingOuts + (winner === 1 ? 1 : 0);
      const nextRingOutsP2 = statsRef.current.p2RingOuts + (winner === 2 ? 1 : 0);
      const hardestImpact = statsRef.current.hardestImpact;

      const winsNeeded = getWinsNeeded(config.totalRounds);
      if (nextP1Wins >= winsNeeded || nextP2Wins >= winsNeeded) {
        if (
          winsNeeded >= 2 &&
          ((nextP1Wins === winsNeeded && nextP2Wins === 0) ||
            (nextP2Wins === winsNeeded && nextP1Wins === 0))
        ) {
          unlockAchievement('clean_sweep');
        }
        gameAudio.playMatchWin();
        setRoundSummary(null);

        if (config.mode === 'tournament' && tournamentBracket && activeTournamentMatch) {
          const winnerSide: 1 | 2 = nextP1Wins >= winsNeeded ? 1 : 2;
          const winnerEntrant =
            winnerSide === 1 ? activeEntrantA : activeEntrantB;
          setLastTournamentMatchSummary({
            matchId: activeTournamentMatch.id,
            stageLabel: activeTournamentMatch.stageLabel,
            winnerName: winnerEntrant?.name ?? (winnerSide === 1 ? 'Player 1' : 'Player 2'),
            scoreLine: `${nextP1Wins}–${nextP2Wins}`,
          });
          const nextBracket = recordTournamentMatchResult(
            tournamentBracket,
            activeTournamentMatch.id,
            winnerSide,
            nextP1Wins,
            nextP2Wins,
            false,
            eventDetail
          );
          setTournamentBracket(nextBracket);
          setGameState('TOURNAMENT_BRACKET');

          if (p1IsAI !== p2IsAI) {
            const humanSide: 1 | 2 = !p1IsAI ? 1 : 2;
            const humanEntrantId =
              humanSide === 1
                ? activeTournamentMatch.entrantAId
                : activeTournamentMatch.entrantBId;
            void submitCompetitiveStats({
              won: winnerSide === humanSide,
              roundsWon: humanSide === 1 ? nextP1Wins : nextP2Wins,
              ringOuts: humanSide === 1 ? nextRingOutsP1 : nextRingOutsP2,
              tournamentChampion: Boolean(
                humanEntrantId && nextBracket.championId === humanEntrantId
              ),
              hardestImpact,
              penClass:
                humanSide === 1
                  ? effectiveArenaConfig.p1Pen
                  : effectiveArenaConfig.p2Pen,
            });
          }
        } else {
          setGameState('GAME_OVER');
          if (config.mode === 'ai' && !p1IsAI && p2IsAI) {
            void submitCompetitiveStats({
              won: nextP1Wins >= winsNeeded,
              roundsWon: nextP1Wins,
              ringOuts: nextRingOutsP1,
              hardestImpact,
              penClass: effectiveArenaConfig.p1Pen,
            });
          }
        }
      } else {
        setRoundSummary({
          roundNumber,
          winner,
          reason,
          p1Wins: nextP1Wins,
          p2Wins: nextP2Wins,
        });
        setGameState('ROUND_END');
      }
    },
    [
      p1Wins,
      p2Wins,
      roundNumber,
      unlockAchievement,
      handleUnlockCustomClass,
      submitCompetitiveStats,
      config.mode,
      config.totalRounds,
      effectiveArenaConfig.p1Pen,
      effectiveArenaConfig.p2Pen,
      p1IsAI,
      p2IsAI,
      activeP1Name,
      activeP2Name,
      tournamentBracket,
      activeTournamentMatch,
      activeEntrantA,
      activeEntrantB,
    ]
  );

  const handleNextRound = useCallback(() => {
    const nextRound = roundSummary?.winner === 'draw' ? roundNumber : roundNumber + 1;
    const starter: 1 | 2 = nextRound % 2 === 1 ? 1 : 2;
    const starterIsAI = starter === 1 ? p1IsAI : p2IsAI;
    setRoundNumber(nextRound);
    setRoundToken((t) => t + 1);
    setLastShooter(null);
    setActiveTurn(starter);
    setTurnPhase(starterIsAI ? 'ai_thinking' : 'aiming');
    setRoundSummary(null);
    setDeskGraffiti(null);
    setGameState('PLAYING');
  }, [roundNumber, roundSummary, p1IsAI, p2IsAI]);

  const handleStartReplay = useCallback(() => {
    if (
      gameState !== 'ROUND_END' &&
      gameState !== 'GAME_OVER' &&
      gameState !== 'TOURNAMENT_BRACKET'
    ) {
      return;
    }
    setReplayReturnState(gameState);
    setReplayToken((t) => t + 1);
    setGameState('REPLAYING');
  }, [gameState]);

  const handleReplayComplete = useCallback(() => {
    setGameState(replayReturnState);
  }, [replayReturnState]);

  const handleToggleMute = useCallback(() => {
    gameAudio.toggleMute();
    setAudioSettings(gameAudio.getSettings());
  }, []);

  const handleUpdateAudioSettings = useCallback((patch: Partial<AudioSettings>) => {
    const next = gameAudio.updateSettings(patch);
    setAudioSettings(next);
  }, []);

  const handlePauseToggle = useCallback(() => {
    setGameState((prev) => {
      if (prev === 'PLAYING') return 'PAUSED';
      if (prev === 'PAUSED') return 'PLAYING';
      return prev;
    });
  }, []);

  const handleReturnToTitle = useCallback(() => {
    setRoundNumber(1);
    setRoundToken((t) => t + 1);
    setLastShooter(null);
    setP1Wins(0);
    setP2Wins(0);
    setActiveTurn(1);
    setTurnPhase('aiming');
    setRoundSummary(null);
    setDeskGraffiti(null);
    setTournamentBracket(null);
    setLastTournamentMatchSummary(null);
    setMatchHistory([]);
    setEarnedAchievements([]);
    setRecentAchievement(null);
    setStats(INITIAL_STATS);
    setConfig((prev) => ({
      ...prev,
      p1Custom: {
        ...prev.p1Custom,
        styleMode:
          prev.mode === 'freeplay' || unlockedCustomClasses[prev.p1Pen]
            ? prev.p1Custom.styleMode
            : 'standard',
      },
      p2Custom: {
        ...prev.p2Custom,
        styleMode:
          prev.mode === 'freeplay' || unlockedCustomClasses[prev.p2Pen]
            ? prev.p2Custom.styleMode
            : 'standard',
      },
    }));
    setGameState('TITLE_MENU');
  }, [unlockedCustomClasses]);

  const handleRestartFromPauseOrModal = useCallback(() => {
    if (config.mode === 'tournament' && tournamentBracket?.activeMatchId) {
      handlePlayTournamentMatch(tournamentBracket.activeMatchId);
      return;
    }
    startFreshMatch();
  }, [config.mode, tournamentBracket, handlePlayTournamentMatch, startFreshMatch]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (gameState === 'REPLAYING') {
        if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') {
          e.preventDefault();
          handleReplayComplete();
        }
        return;
      }
      if (e.key === 'Escape') {
        if (gameState === 'PLAYING' || gameState === 'PAUSED') {
          handlePauseToggle();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [gameState, handlePauseToggle, handleReplayComplete]);

  return (
    <main className="relative w-screen h-[100dvh] overflow-hidden bg-[#0E1318]">
      {/* Isolated 60fps Tabletop Canvas */}
      <PenFightArena
        gameState={gameState}
        config={effectiveArenaConfig}
        roundNumber={roundNumber}
        roundToken={roundToken}
        replayToken={replayToken}
        activeTurn={activeTurn}
        turnPhase={turnPhase}
        p1IsAI={p1IsAI}
        p2IsAI={p2IsAI}
        onTurnPhaseChange={setTurnPhase}
        onTurnAdvance={handleTurnAdvance}
        onRoundResolved={handleRoundResolved}
        onReplayComplete={handleReplayComplete}
        onRecordFlick={(shooter) => {
          setLastShooter(shooter);
          setStats((prev) => ({ ...prev, totalFlicks: prev.totalFlicks + 1 }));
        }}
        onRecordImpact={(impulse) =>
          setStats((prev) => ({
            ...prev,
            hardestImpact: Math.max(prev.hardestImpact, impulse),
          }))
        }
        onUnlockAchievement={unlockAchievement}
        onFanStatusChange={setFanStatus}
      />

      {/* Title Screen */}
      {gameState === 'TITLE_MENU' && (
        <TitleScreen
          config={config}
          audioSettings={audioSettings}
          unlockedCustomClasses={unlockedCustomClasses}
          user={authUser}
          authReady={authReady}
          authLoading={authLoading}
          authError={authError}
          myLeaderboardEntry={myLeaderboardEntry}
          onSignIn={() => void handleSignIn()}
          onSignOut={() => void handleSignOut()}
          onLeaderboardProfileUpdated={setMyLeaderboardEntry}
          onUnlockCustomClass={handleUnlockCustomClass}
          onUpdateAudioSettings={handleUpdateAudioSettings}
          onChangeConfig={handleChangeConfigFromTitle}
          onStartMatch={startFreshMatch}
        />
      )}

      {/* Tournament Bracket Overlay */}
      {gameState === 'TOURNAMENT_BRACKET' && tournamentBracket && (
        <TournamentBracket
          bracket={tournamentBracket}
          lastMatchSummary={lastTournamentMatchSummary}
          deskGraffiti={deskGraffiti}
          hasReplay={lastShooter !== null}
          leaderboardSyncNotice={leaderboardSyncNotice}
          onPlayMatch={handlePlayTournamentMatch}
          onSimulateMatch={handleSimulateTournamentMatch}
          onAutoFinishTournament={handleAutoFinishTournament}
          onReplayLastFlick={handleStartReplay}
          onRestartTournament={startFreshMatch}
          onReturnToTitle={handleReturnToTitle}
          onDismissGraffiti={() => setDeskGraffiti(null)}
        />
      )}

      {/* Low-Occlusion Perimeter HUD during Active Play & Replay */}
      {gameState !== 'TITLE_MENU' && gameState !== 'TOURNAMENT_BRACKET' && (
        <GameHUD
          gameState={gameState}
          mode={config.mode}
          arenaMode={config.arenaMode}
          fanEnabled={config.fanEnabled}
          fanStatus={fanStatus}
          roundNumber={roundNumber}
          totalRounds={config.totalRounds}
          p1Wins={p1Wins}
          p2Wins={p2Wins}
          p1Pen={effectiveArenaConfig.p1Pen}
          p2Pen={effectiveArenaConfig.p2Pen}
          p1Custom={effectiveArenaConfig.p1Custom}
          p2Custom={effectiveArenaConfig.p2Custom}
          p1Name={activeP1Name}
          p2Name={activeP2Name}
          tournamentStageLabel={tournamentStageLabel}
          activeTurn={activeTurn}
          turnPhase={turnPhase}
          lastShooter={lastShooter}
          recentAchievement={recentAchievement}
          muted={
            audioSettings.masterMuted ||
            (!audioSettings.musicEnabled && !audioSettings.sfxEnabled)
          }
          onToggleMute={handleToggleMute}
          onPause={handlePauseToggle}
          onSkipReplay={handleReplayComplete}
          onFreeplaySelectPen={setActiveTurn}
          onFreeplayChangePen={handleFreeplayChangePen}
          onFreeplayChangeFinish={handleFreeplayChangeFinish}
          onFreeplayToggleArena={handleFreeplayToggleArena}
          onFreeplayToggleFan={handleFreeplayToggleFan}
          onFreeplayResetDesk={handleFreeplayResetDesk}
        />
      )}

      {/* Pause, Round Summary & Game Over Modals */}
      <GameModals
        gameState={gameState}
        mode={config.mode}
        totalRounds={config.totalRounds}
        roundSummary={roundSummary}
        deskGraffiti={deskGraffiti}
        matchHistory={matchHistory}
        earnedAchievements={earnedAchievements}
        stats={stats}
        p1Wins={p1Wins}
        p2Wins={p2Wins}
        p1Name={activeP1Name}
        p2Name={activeP2Name}
        tournamentStageLabel={tournamentStageLabel}
        hasReplay={lastShooter !== null}
        leaderboardSyncNotice={leaderboardSyncNotice}
        audioSettings={audioSettings}
        onUpdateAudioSettings={handleUpdateAudioSettings}
        onResume={() => setGameState('PLAYING')}
        onNextRound={handleNextRound}
        onReplayLastFlick={handleStartReplay}
        onRestartMatch={handleRestartFromPauseOrModal}
        onReturnToTitle={handleReturnToTitle}
        onDismissGraffiti={() => setDeskGraffiti(null)}
      />
    </main>
  );
}
